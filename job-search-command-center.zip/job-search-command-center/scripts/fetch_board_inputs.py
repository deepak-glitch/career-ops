from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable
from urllib.parse import parse_qs, quote_plus, unquote, urlparse
from urllib.request import Request, urlopen


DEFAULT_BOARDS = ["linkedin", "indeed", "dice", "greenhouse", "lever", "ashby"]


@dataclass(slots=True)
class FetchStats:
    searched: int = 0
    urls_considered: int = 0
    pages_fetched: int = 0
    pages_written: int = 0
    blocked: int = 0


class _HTMLStripper(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []
        self._skip: int = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript"}:
            self._skip += 1
            return
        if tag in {"p", "br", "li", "h1", "h2", "h3", "h4", "ul", "ol"}:
            self._parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript"} and self._skip:
            self._skip -= 1
            return
        if tag in {"p", "li"}:
            self._parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._skip:
            return
        cleaned = " ".join(data.split()).strip()
        if cleaned:
            self._parts.append(cleaned)

    def text(self) -> str:
        blob = " ".join(self._parts)
        blob = re.sub(r"\s+\n", "\n", blob)
        blob = re.sub(r"\n\s+", "\n", blob)
        blob = re.sub(r"[ \t\f\v]+", " ", blob)
        blob = re.sub(r"\n{3,}", "\n\n", blob)
        return blob.strip()


def _fetch_url(url: str, *, timeout_s: int = 25) -> str:
    req = Request(
        url,
        headers={
            "User-Agent": "job-search-command-center/1.0 (+local automation)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(req, timeout=timeout_s) as resp:  # noqa: S310
        content_type = resp.headers.get("Content-Type", "")
        charset = "utf-8"
        if "charset=" in content_type:
            charset = content_type.split("charset=", 1)[1].split(";", 1)[0].strip()
        data = resp.read()
        return data.decode(charset, errors="replace")


def _clip(text: str, limit: int) -> str:
    cleaned = text.strip()
    if len(cleaned) <= limit:
        return cleaned
    return cleaned[:limit].rstrip() + "\n"


def _slug(text: str) -> str:
    lowered = text.lower()
    lowered = re.sub(r"[^a-z0-9]+", "-", lowered).strip("-")
    return re.sub(r"-{2,}", "-", lowered) or "role"


def _extract_jobposting_jsonld(html: str) -> dict | None:
    scripts = re.findall(r'<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>', html, flags=re.S | re.I)
    best: dict | None = None
    best_len = -1
    for raw in scripts:
        raw = raw.strip()
        try:
            data = json.loads(raw)
        except Exception:
            continue
        candidates = data if isinstance(data, list) else [data]
        for item in candidates:
            if not isinstance(item, dict):
                continue
            typ = item.get("@type")
            if typ == "JobPosting" or (isinstance(typ, list) and "JobPosting" in typ):
                desc = item.get("description") or ""
                if isinstance(desc, str) and len(desc) > best_len:
                    best = item
                    best_len = len(desc)
    return best


def _format_location(jobposting: dict) -> str | None:
    loc = jobposting.get("jobLocation")
    if isinstance(loc, list) and loc:
        loc = loc[0]
    if isinstance(loc, dict):
        addr = loc.get("address")
        if isinstance(addr, dict):
            parts = [addr.get("addressLocality"), addr.get("addressRegion"), addr.get("addressCountry")]
            parts = [p for p in parts if p]
            if parts:
                return ", ".join(parts)
    return None


def _strip_html(html_fragment: str) -> str:
    stripper = _HTMLStripper()
    stripper.feed(html_fragment)
    return stripper.text()


def _duckduckgo_search(query: str, *, max_results: int = 10, sleep_s: float = 0.6) -> list[str]:
    """
    Very lightweight HTML search. If blocked, returns empty.
    """
    url = f"https://duckduckgo.com/html/?q={quote_plus(query)}"
    try:
        html = _fetch_url(url, timeout_s=20)
    except Exception:
        return []
    time.sleep(sleep_s)

    urls: list[str] = []
    for href in re.findall(r'href="(https?://duckduckgo\.com/l/\?uddg=[^"]+)"', html, flags=re.I):
        try:
            parsed = urlparse(href)
            qs = parse_qs(parsed.query)
            target = qs.get("uddg", [None])[0]
            if not target:
                continue
            resolved = unquote(target)
            if resolved.startswith("http"):
                urls.append(resolved)
        except Exception:
            continue

    deduped: list[str] = []
    for u in urls:
        if u not in deduped:
            deduped.append(u)
        if len(deduped) >= max_results:
            break
    return deduped


def _board_domains(board: str) -> list[str]:
    return {
        "ashby": ["jobs.ashbyhq.com"],
        "lever": ["jobs.lever.co"],
        "greenhouse": ["boards.greenhouse.io", "boards-api.greenhouse.io"],
        "dice": ["dice.com"],
        "indeed": ["indeed.com"],
        "linkedin": ["linkedin.com"],
    }.get(board, [])


def _url_is_job_posting(board: str, url: str) -> bool:
    lowered = url.lower()
    if board == "ashby":
        return "jobs.ashbyhq.com/" in lowered and re.search(r"/[0-9a-f]{8}-[0-9a-f]{4}-", lowered) is not None
    if board == "lever":
        return "jobs.lever.co/" in lowered and re.search(r"/[0-9a-f]{8}-[0-9a-f]{4}-", lowered) is not None
    if board == "greenhouse":
        return "boards.greenhouse.io" in lowered and "/jobs/" in lowered
    if board == "indeed":
        return "indeed.com/viewjob" in lowered or "indeed.com/rc/clk" in lowered
    if board == "linkedin":
        return "linkedin.com/jobs/view" in lowered or "/jobs/view" in lowered
    if board == "dice":
        return "dice.com/job-detail" in lowered or "dice.com/jobs/detail" in lowered
    return True


def _discover_urls(board: str, phrases: list[str], *, limit: int) -> list[str]:
    domains = _board_domains(board)
    if not domains:
        return []
    seed_phrases = []
    for phrase in phrases:
        if phrase not in seed_phrases:
            seed_phrases.append(phrase)
        if len(seed_phrases) >= 6:
            break
    queries = [f'site:{domains[0]} "{phrase}" remote' for phrase in seed_phrases[:3]]
    queries.append(f'site:{domains[0]} "Applied AI" remote')

    found: list[str] = []
    for query in queries:
        for url in _duckduckgo_search(query, max_results=max(10, limit)):
            if any(domain in urlparse(url).netloc.lower() for domain in domains) and _url_is_job_posting(board, url):
                found.append(url)
            if len(found) >= limit * 2:
                break
        if len(found) >= limit * 2:
            break

    deduped: list[str] = []
    for u in found:
        if u not in deduped:
            deduped.append(u)
        if len(deduped) >= limit:
            break
    return deduped


def _write_job_markdown(
    out_dir: Path,
    *,
    company: str,
    title: str,
    location: str,
    employment_type: str,
    posted_at: str | None,
    source_url: str,
    jd_text: str,
    max_chars: int,
) -> Path:
    url_hash = hashlib.sha1(source_url.encode("utf-8"), usedforsecurity=False).hexdigest()[:10]
    filename = f"{_slug(company)}_{_slug(title)}_{url_hash}.md"
    path = out_dir / filename
    body = (
        f"Company: {company}\n"
        f"Title: {title}\n"
        f"Location: {location}\n"
        f"employment_type: {employment_type}\n"
        + (f"posted_at: {posted_at}\n" if posted_at else "")
        + f"Source URL: {source_url}\n\n"
        + "JD Extract:\n"
        + _clip(jd_text, max_chars)
        + "\n"
    )
    path.write_text(body, encoding="utf-8")
    return path


def _normalize_encoding(text: str) -> str:
    subs = {
        "â€“": "-",
        "â€”": "-",
        "â€™": "'",
        "â€œ": '"',
        "â€�": '"',
        "Â": "",
    }
    for k, v in subs.items():
        text = text.replace(k, v)
    return text


def _extract_jd(url: str, html: str) -> tuple[str, str, str, str, str | None, str]:
    """
    Returns (company, title, location, employment_type, posted_at, jd_text)
    """
    jobposting = _extract_jobposting_jsonld(html)
    company = urlparse(url).netloc.replace("www.", "").split(".")[0].replace("-", " ").title()
    title = "Imported Role"
    location = "Unknown"
    employment_type = "Unknown"
    posted_at: str | None = None
    jd_text = ""

    if jobposting:
        title = str(jobposting.get("title") or title).strip() or title
        org = jobposting.get("hiringOrganization")
        if isinstance(org, dict) and org.get("name"):
            company = str(org["name"]).strip() or company
        location = _format_location(jobposting) or location
        emp = jobposting.get("employmentType")
        if isinstance(emp, str) and emp.strip():
            employment_type = emp.strip()
        posted_at_raw = jobposting.get("datePosted")
        if isinstance(posted_at_raw, str) and posted_at_raw.strip():
            posted_at = posted_at_raw.strip()
        desc_html = jobposting.get("description") or ""
        if isinstance(desc_html, str) and desc_html.strip():
            jd_text = _strip_html(desc_html)

    if not jd_text:
        # Fallback: strip the whole HTML.
        jd_text = _strip_html(html)

    company = _normalize_encoding(company)
    title = _normalize_encoding(title)
    location = _normalize_encoding(location)
    employment_type = _normalize_encoding(employment_type)
    jd_text = _normalize_encoding(jd_text)
    return company, title, location, employment_type, posted_at, jd_text


def _read_search_phrases(root: Path) -> list[str]:
    prefs_path = root / "config" / "search_preferences.json"
    if not prefs_path.exists():
        return ["Applied AI Engineer", "Generative AI Engineer", "LLM Engineer"]
    prefs = json.loads(prefs_path.read_text(encoding="utf-8"))
    phrases = [str(item) for item in (prefs.get("search_phrases") or []) if str(item).strip()]
    if not phrases:
        phrases = ["Applied AI Engineer", "Generative AI Engineer", "LLM Engineer"]
    return phrases


def _iter_boards(value: str | None) -> list[str]:
    if not value:
        return list(DEFAULT_BOARDS)
    boards = [item.strip() for item in value.split(",") if item.strip()]
    return boards or list(DEFAULT_BOARDS)


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Fetch public job postings into data/board_inputs/<board>/ as local markdown fixtures.")
    parser.add_argument("--root", default=".", help="Project root directory")
    parser.add_argument("--boards", default=",".join(DEFAULT_BOARDS), help="Comma-separated board list")
    parser.add_argument("--limit-per-board", type=int, default=10)
    parser.add_argument("--max-chars", type=int, default=6500)
    parser.add_argument("--min-delay-s", type=float, default=0.6)
    parser.add_argument("--urls-json", help="Optional JSON file: {\"board\": [\"url\", ...]} to use instead of discovery.")
    args = parser.parse_args(argv)

    root = Path(args.root).resolve()
    phrases = _read_search_phrases(root)
    boards = _iter_boards(args.boards)

    blockers: dict[str, list[str]] = {}
    written_paths: dict[str, list[str]] = {}
    stats_by_board: dict[str, FetchStats] = {board: FetchStats() for board in boards}

    seed_urls: dict[str, list[str]] = {}
    if args.urls_json:
        seed_path = Path(args.urls_json)
        if seed_path.exists():
            raw = json.loads(seed_path.read_text(encoding="utf-8-sig"))
            if isinstance(raw, dict):
                for key, value in raw.items():
                    if isinstance(value, list):
                        seed_urls[str(key)] = [str(item) for item in value if str(item).strip()]

    def urls_for_board(board: str) -> list[str]:
        urls = seed_urls.get(board, [])
        if urls:
            return urls[: args.limit_per_board]
        return _discover_urls(board, phrases, limit=args.limit_per_board)

    def normalize_greenhouse_url(url: str) -> str:
        # Convert embedded job boards into the public boards API when possible.
        parsed = urlparse(url)
        if "boards.greenhouse.io" in parsed.netloc.lower() and "embed/job_board" in parsed.path:
            qs = parse_qs(parsed.query)
            board_name = qs.get("for", [None])[0]
            if board_name:
                return f"https://boards-api.greenhouse.io/v1/boards/{board_name}/jobs?content=true"
        return url

    for board in boards:
        out_dir = root / "data" / "board_inputs" / board
        _ensure_dir(out_dir)
        urls = urls_for_board(board)
        if board == "greenhouse":
            urls = [normalize_greenhouse_url(u) for u in urls]
        stats = stats_by_board[board]
        stats.searched += 1
        stats.urls_considered += len(urls)
        if not urls:
            blockers.setdefault(board, []).append("no_urls_discovered")
            continue

        for url in urls:
            try:
                html = _fetch_url(url)
                stats.pages_fetched += 1
            except Exception as exc:
                stats.blocked += 1
                blockers.setdefault(board, []).append(f"fetch_failed: {url} ({exc})")
                continue

            company, title, location, employment_type, posted_at, jd_text = _extract_jd(url, html)
            if not jd_text or len(jd_text) < 200:
                blockers.setdefault(board, []).append(f"jd_too_short: {url}")
                continue

            path = _write_job_markdown(
                out_dir,
                company=company,
                title=title,
                location=location,
                employment_type=employment_type,
                posted_at=posted_at,
                source_url=url,
                jd_text=jd_text,
                max_chars=args.max_chars,
            )
            written_paths.setdefault(board, []).append(str(path.relative_to(root)))
            stats.pages_written += 1
            time.sleep(max(0.0, float(args.min_delay_s)))

    summary = {
        "boards": boards,
        "written": written_paths,
        "blockers": blockers,
        "stats": {board: {"searched": stats.searched, "urls_considered": stats.urls_considered, "pages_fetched": stats.pages_fetched, "pages_written": stats.pages_written, "blocked": stats.blocked} for board, stats in stats_by_board.items()},
    }
    out_summary = root / "data" / "runs" / f"board_inputs_fetch_{int(time.time())}.json"
    _ensure_dir(out_summary.parent)
    out_summary.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"summary_path": str(out_summary)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
