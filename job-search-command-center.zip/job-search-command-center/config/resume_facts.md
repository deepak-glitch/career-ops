# Resume Facts

## Experience

### Progress Solutions Inc. | Jr. AI/ML Engineer Trainee | Jul 2025-Present
- Built healthcare-focused retrieval-augmented generation systems for documentation search, policy retrieval, and internal knowledge access.
- Designed agentic LLM workflows with structured reasoning, grounding rules, tool discipline, and evaluation-focused iteration.
- Developed predictive ML pipelines for patient no-show risk, care engagement scoring, and support prioritization using Python, scikit-learn, and XGBoost.
- Packaged AI inference services with Flask, FastAPI, logging, and Docker for production-style deployment and integration.

### Energy Solutions International (Emerson) | Database and DevOps Engineering Intern | Jun 2022-Apr 2023
- Improved SQL and stored procedure performance for enterprise oil and gas workflows, reducing latency and stabilizing reporting jobs.
- Supported CI/CD automation with Jenkins, deployment validation, rollback readiness, and observability dashboards.

### Suvidha Foundation | Machine Learning Engineer | Jan 2022-Mar 2022
- Built a transformer-based video summarization and highlight generation system using transcript processing, timestamp alignment, and automated clip extraction.
- Implemented document question answering and retrieval workflows to improve grounded answers and reduce hallucinated outputs.

## Core Skills

- Python, FastAPI, Flask, Docker, SQL, Jenkins, Grafana
- LLMs, RAG, agentic workflows, embeddings, vector search, evaluation pipelines, structured outputs
- scikit-learn, XGBoost, transformers, computer vision, multimodal systems