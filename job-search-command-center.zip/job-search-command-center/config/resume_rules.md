# Resume Rules

## Source Of Truth

- Do not rely on `resume_rules.md` alone when creating or updating resumes.
- Always use these three sources together:
- `config/resume_rules.md` for standing resume standards and workflow rules.
- `src/job_search_command_center/engine/reports.py` for company-specific content logic, keyword logic, summary logic, skills logic, experience tailoring, and project selection.
- `src/job_search_command_center/adapters/render/pdf.py` for PDF-safe layout, spacing, section rendering, alignment, and ATS-friendly formatting behavior.
- If there is any mismatch, preserve truthfulness first, ATS safety second, and keyword richness third, unless the user explicitly asks otherwise.

## Standing Rules

- Keep every resume truthful to Deepak's real background, work history, projects, skills, and dates.
- Keep every resume ATS-friendly with a clean single-column structure, standard section headings, and parseable text.
- Tailor every resume to the target company and role using role-relevant keywords across summary, skills, experience, and projects.
- When there is a tradeoff between originality and keyword richness, prefer keyword-rich wording.
- Match `PROFESSIONAL EXPERIENCE` and `PROJECTS` to the specific job description while staying grounded in real evidence from the resume facts and proof bank.
- Preserve the Honeywell-style formatting standard used in the approved template.

## Content Rules From `reports.py`

- Use company-specific overrides when they exist for high-priority resumes, especially for summary, skills, experience, and projects.
- Use the job description to infer target themes such as:
- `healthcare`
- `llm`
- `rag`
- `platform`
- `evaluation`
- `vision`
- `product`
- `cloud`
- Use job-description terms to derive ATS keywords and make sure important terms are deliberately included instead of appearing only by chance.
- Prefer explicit skill phrases when they are supported by the job description, such as, just examples:
- `LLM Application Development`
- `Retrieval-Augmented Generation`
- `Semantic Retrieval`
- `Embeddings`
- `Agentic Workflows`
- `Structured Outputs`
- `Evaluation Pipelines`
- `Model Observability`
- `Guardrails`
- `Healthcare AI`
- `HIPAA-Conscious Delivery`
- `AI Platforms`
- `Cloud Deployment`
- `MLOps`
- `LLMOps`
- `Secure Development`
- `Responsible AI`
- `Question Answering`
- `Data Extraction`
- `Process Outcome Prediction`
- `Multimodal AI`
- `RESTful APIs`
- `LangChain`
- `Hugging Face`
- `LlamaIndex`
- `PostgreSQL`
- `React`
- `TypeScript`
- Keep summaries concise, role-specific, and written like final resume copy rather than template filler.
- Make `SKILLS` company-specific instead of static when the role clearly emphasizes certain tools, domains, or systems.
- Re-rank `PROFESSIONAL EXPERIENCE` bullets by company skill targets rather than keeping a fixed order.
- Keep the most relevant and keyword-rich bullets first, especially in the most recent role.
- Keep `PROJECTS` real and grounded in actual workstreams. Prefer real projects such as:
- `Agentic Pixel Character Synthesis & Animation Engine`
- `Dream Decoder - AI-Powered Multimodal Creative Intelligence Platform`
- `Driver Drowsiness Detection System - Real-Time YOLOv8-Based Fatigue Monitoring`
- `Video Summarization and Highlight Generation System`
- `Document Question Answering and Retrieval Workflow`
- Match projects to the role. For example:
- RAG or question-answering roles should surface retrieval and document QA work.
- Multimodal roles should surface Dream Decoder or video summarization work.
- Platform roles should surface API, Docker, FastAPI, and orchestration-heavy projects.
- Computer vision roles should surface YOLOv8 or vision-heavy work.
- Agentic roles should surface orchestration, structured outputs, and iterative refinement work.

## Formatting Rules From `pdf.py`

- Keep the PDF single-column and ATS-safe.
- Keep page layout conservative and readable:
- `Times`-style serif fonts
- title at about `16 pt`
- body text at about `10 pt`
- bold section headings
- standard page size with stable margins
- Keep the name centered at the top, with centered contact details beneath it.
- Keep the role/title line left-aligned under the contact line.
- Keep section headings clearly separated with consistent spacing.
- Use hanging layout in the `SKILLS` section so the category label and body text do not collide.
- Wrap long skills lines instead of letting them crash into the next line.
- Keep experience and education heading lines aligned cleanly with dates on the right when space allows.
- If an experience title is too long, wrap the title and push the date line below rather than allowing overlap.
- Keep bullets readable with proper indenting and wrapped continuation lines.
- Avoid decorative layout elements, tables, sidebars, columns, icons, images, and dense visual formatting that can hurt ATS parsing.
- Keep PDF text selectable and text-based rather than image-based.

## Final Pass Rule

- After the latest jobs are searched and resumes are generated, always do one more pass on all of the resumes for those latest jobs.
- In that final pass, make the summary, skills, experience, and projects read more like hand-edited final versions rather than generator output.
- Do that final pass every time, even if the generated resumes already look good.
