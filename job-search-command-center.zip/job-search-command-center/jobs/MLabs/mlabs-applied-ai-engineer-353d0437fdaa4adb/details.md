# MLabs - Applied AI Engineer

- Job ID: `mlabs-applied-ai-engineer-353d0437fdaa4adb`
- Board: `local`
- Location: New York, NY (On-site, 5 days/week)
- Work mode: onsite
- Link: https://www.indeed.com/viewjob?jk=cdf03433f474dd6a
- Match: 71.9%
- Recommendation: `apply`
- Posted: unknown
- Sponsorship note: Visa sponsorship is available.

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
MLabs | Applied AI Engineer scored 71.87/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
