# Cohere - Applied AI Engineer – Agentic Workflows

- Job ID: `cohere-applied-ai-engineer-agentic-work-58d83cddda9a0047`
- Board: `ashby`
- Location: San Francisco, California, United States
- Work mode: remote
- Link: https://jobs.ashbyhq.com/cohere/1fa01a03-9253-4f62-8f10-0fe368b38cb9
- Match: 78.9%
- Recommendation: `apply`
- Posted: 2026-01-06

## Flags
- Listing is older than the default 24-hour freshness window.

## Rationale
Cohere | Applied AI Engineer – Agentic Workflows scored 78.93/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
