# Miracle Software Systems - Generative AI Engineer

- Job ID: `miracle-software-systems-generative-ai-engineer-52615aac8c720555`
- Board: `local`
- Location: Dearborn, MI
- Work mode: unknown
- Link: https://www.dice.com/jobs/q-%28%22AI%20Engineer%22%20OR%20%22Machine%20Learning%20Engineer%22%20OR%20%22-jobs
- Match: 76.7%
- Recommendation: `apply`
- Posted: unknown

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Miracle Software Systems | Generative AI Engineer scored 76.72/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
