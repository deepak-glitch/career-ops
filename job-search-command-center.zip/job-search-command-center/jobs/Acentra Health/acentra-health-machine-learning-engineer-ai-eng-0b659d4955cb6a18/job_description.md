Company: Acentra Health
Title: Machine Learning Engineer / AI Engineer
Location: Remote - United States
employment_type: Full-time
Source URL: https://www.indeed.com/viewjob?jk=938b987d0727ab49

Healthcare AI engineering role centered on LLMs, NLP, retrieval-augmented generation, AI platforms, and cloud deployment in a regulated environment. The job asks for strong Python, AI engineering, LLMOps or MLOps, secure development, healthcare or HIPAA-conscious delivery, and production system thinking. It also references model evaluation, collaboration with product and engineering, and responsible deployment in healthcare workflows.
