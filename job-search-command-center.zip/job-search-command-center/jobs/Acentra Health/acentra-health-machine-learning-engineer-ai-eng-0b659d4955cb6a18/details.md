# Acentra Health - Machine Learning Engineer / AI Engineer

- Job ID: `acentra-health-machine-learning-engineer-ai-eng-0b659d4955cb6a18`
- Board: `local`
- Location: Remote - United States
- Work mode: remote
- Link: https://www.indeed.com/viewjob?jk=938b987d0727ab49
- Match: 74.6%
- Recommendation: `apply`
- Posted: unknown

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Acentra Health | Machine Learning Engineer / AI Engineer scored 74.58/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
