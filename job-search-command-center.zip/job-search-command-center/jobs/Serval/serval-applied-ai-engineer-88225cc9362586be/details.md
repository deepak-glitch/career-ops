# Serval - Applied AI Engineer

- Job ID: `serval-applied-ai-engineer-88225cc9362586be`
- Board: `local`
- Location: San Francisco, CA
- Work mode: unknown
- Link: https://jobs.ashbyhq.com/Serval/2bfaede4-22b2-43b2-a14c-f45e5f398624/
- Match: 71.6%
- Recommendation: `apply`
- Posted: unknown

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Serval | Applied AI Engineer scored 71.57/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
