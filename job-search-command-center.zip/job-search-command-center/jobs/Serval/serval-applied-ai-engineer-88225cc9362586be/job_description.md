Company: Serval
Title: Applied AI Engineer
Location: San Francisco, CA
employment_type: Full-time
Source URL: https://jobs.ashbyhq.com/Serval/2bfaede4-22b2-43b2-a14c-f45e5f398624/

Applied AI Engineer role with strong emphasis on agentic AI, production deployment, platform thinking, and high-ownership applied machine learning work. Public listing context suggests an emphasis on evaluation, production systems, real-world impact, and fast-moving startup execution. This job is treated as a strong but lower-confidence fit because the full listing text was not fully accessible during review.
