# Epistemix - AI Engineer

- Job ID: `epistemix-ai-engineer-1c174c74f86df46d`
- Board: `generic`
- Location: Pittsburgh, Pennsylvania, United States
- Work mode: remote
- Link: https://jobs.ashbyhq.com/Epistemix/ba01bc54-7599-4f69-bda8-af69e62de222
- Match: 81.8%
- Recommendation: `apply`
- Posted: unknown
- Sponsorship note: Must be legally authorized to work in the United States and not require employer sponsorship now or in the future.

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Epistemix | AI Engineer scored 81.78/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
