Company: Epistemix
Title: AI Engineer
Location: Pittsburgh, Pennsylvania, United States
employment_type: FULL_TIME
Source URL: https://jobs.ashbyhq.com/Epistemix/ba01bc54-7599-4f69-bda8-af69e62de222

JD Extract:
The AI Engineer plays a critical role in making modeling and simulation accessible to non-data scientists. You will be designing, developing, and deploying AI-driven applications to make our software more accessible which will have a direct impact on the number of organizations we are able to serve. This position plays a critical role in our product roadmap and will directly contribute to the company's success and growth. Ideal candidates exhibit a high willingness to experiment and empathy for users.
About Epistemix
The most consequential decisions in public health, life sciences, insurance, and enterprise strategy share a common problem: they involve human behavior, network effects, and downstream effects that cannot be safely tested before action is taken. Traditional analytical techniques built on historical data were not built for this. Epistemix was.
We build simulation and data-driven modeling tools that let leaders visualize how strategies will unfold across populations and systems before they commit resources. By clarifying which variables drive outcomes, where leverage exists, and how they interact, we help organizations move from uncertainty to conviction. Getting these decisions right means faster interventions, better-allocated resources, and measurable improvements in human and economic outcomes. We exist to make that possible.
Our platform gives organizations access to realistic, high-resolution population data and the modeling infrastructure to run scenario planning at scale. Together, these capabilities let decision-makers stress-test strategies in a controlled environment before deploying them in the real world across healthcare, consumer industries, insurance, and government. We are approaching our Series B and actively building the team that will define what comes next.
Responsibilities
Craft clean, testable, and maintainable code to enable AI-generated agent-based models.
Own the software from requirements development through deployment and maintenance that enable decision makers to generate agent-based models that address critical business questions and data scientists to build agent-based models more quickly that answer the questions of decision makers.
Design, build, test, and deploy a scalable system architecture so that AI-generated models can be validated by data scientists and deliver results back to decision makers quickly.
Own the engineering solution and collaborate with internal teams to ensure alignment with company strategy.
Qualifications
Bachelor’s or Master’s degree in Computer Science, Artificial Intelligence, Data Science, or a related field (or equivalent experience).
3+ years of experience developing AI/ML applications in production environments.
Proven track record of working with LLMs, NLP models, or AI-driven systems.
Experience designing and optimizing high-performance, scalable APIs.
Strong problem-solving skills and ability to work in a fast-paced environment.
Must be legally authorized to work in the United States and not require employer sponsorship now or in the future.
Required Skills
Python – Advanced proficiency in writing clean, efficient, and scalable code.
Pydantic – Strong experience in data validation, serialization, and structured model definition.
LLM Evaluation – Ability to assess model performance, optimize outputs, and fine-tune AI behavior.
Prompt Optimization – Expertise in crafting, refining, and iterating prompts for optimal AI performance.
SQLAlchemy – Hands-on experience with database modeling, ORM techniques, and performance tuning.
FastAPI – Proven ability to develop and maintain APIs with FastAPI for AI-driven applications.
Nice to Have Experience
Experience with vector databases (e.g., Pinecone, Weaviate, FAISS) for efficient AI retrieval.
Familiarity with Docker & Kubernetes for containerized AI application deployment.
Knowledge of cloud platforms (AWS, GCP, or Azure) for scaling AI infrastructure.
Understanding of retrieval-augmented generation (RAG) techniques.
Background in MLOps practices for automating AI model deployment and monitoring.
Why Join Epistemix?
By joining Epistemix, you will become part of a collaborative and rapidly growing team that values curiosity and creativity. We are fully remote, with team members in the United States and Europe. Benefits include:
Equity & Incentives – Participation in our stock option program.
Flexible Time Off – Autonomy to manage your schedule and work-life balance.
Health, Welfare and 401(k) Programs – Eligibility for benefits (for U.S. employees).
Meaningful Impact – Apply your creative talents to revolutionize data-driven decision-making and make a real-world difference.
This is a remote position open to applicants located in the United States. Candidates must possess the legal right to work in their intended work location, as we are currently unable to sponsor or transfer employment visas for any country, including the United States.
