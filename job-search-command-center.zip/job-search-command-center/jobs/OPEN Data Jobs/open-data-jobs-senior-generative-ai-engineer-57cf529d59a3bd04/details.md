# OPEN Data Jobs - Senior Generative AI Engineer

- Job ID: `open-data-jobs-senior-generative-ai-engineer-57cf529d59a3bd04`
- Board: `dice`
- Location: Unknown
- Work mode: remote
- Link: https://www.dice.com/job-detail/b2222bde-732d-4c1e-af78-08ba96d861f9
- Match: 80.8%
- Recommendation: `apply`
- Posted: 2026-03-16T18:43:09.000Z

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
OPEN Data Jobs | Senior Generative AI Engineer scored 80.82/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
