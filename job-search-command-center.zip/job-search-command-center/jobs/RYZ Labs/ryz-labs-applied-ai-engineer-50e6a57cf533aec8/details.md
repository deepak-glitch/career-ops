# RYZ Labs - Applied AI Engineer

- Job ID: `ryz-labs-applied-ai-engineer-50e6a57cf533aec8`
- Board: `lever`
- Location: Argentina
- Work mode: remote
- Link: https://jobs.lever.co/RyzLabs/f15d2e8b-31b6-4cff-837b-38aeed6c9791
- Match: 78.2%
- Recommendation: `apply`
- Posted: 2026-03-16

## Flags
- Listing is older than the default 24-hour freshness window.

## Rationale
RYZ Labs | Applied AI Engineer scored 78.23/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
