# Unstructured Technologies Inc. - AI Engineer - Public Sector

- Job ID: `unstructured-technologie-ai-engineer-public-sector-0fbf5c67252838c0`
- Board: `generic`
- Location: Remote - United States
- Work mode: remote
- Link: https://jobs.ashbyhq.com/unstructured/9df95483-7177-4f98-850e-4abbdf530434
- Match: 78.1%
- Recommendation: `apply`
- Posted: unknown
- Sponsorship note: Role may require citizenship or clearance constraints.

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.
- Role may require citizenship or clearance constraints.

## Rationale
Unstructured Technologies Inc. | AI Engineer - Public Sector scored 78.11/100 with 2 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
