# Unstructured Technologies Inc. - AI Engineer - Public Sector

- Job ID: `unstructured-technologie-ai-engineer-public-sector-3afb94e3b77bf9cf`
- Board: `ashby`
- Location: Unknown
- Work mode: unknown
- Link: https://jobs.ashbyhq.com/unstructured/9df95483-7177-4f98-850e-4abbdf530434
- Match: 81.0%
- Recommendation: `apply`
- Posted: 2026-04-15
- Sponsorship note: Role may require citizenship or clearance constraints.

## Flags
- Role may require citizenship or clearance constraints.

## Rationale
Unstructured Technologies Inc. | AI Engineer - Public Sector scored 81.01/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
