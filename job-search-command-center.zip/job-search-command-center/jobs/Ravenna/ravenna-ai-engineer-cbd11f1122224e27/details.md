# Ravenna - AI Engineer

- Job ID: `ravenna-ai-engineer-cbd11f1122224e27`
- Board: `generic`
- Location: Seattle, Washington, United States
- Work mode: unknown
- Link: https://jobs.ashbyhq.com/ravenna/fdefabaf-0665-407d-a7ac-22b7ee67afaa
- Match: 79.2%
- Recommendation: `apply`
- Posted: unknown

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Ravenna | AI Engineer scored 79.15/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
