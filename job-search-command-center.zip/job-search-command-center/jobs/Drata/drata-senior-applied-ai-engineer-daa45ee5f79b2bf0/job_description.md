Company: Drata
Title: Senior Applied AI Engineer
Location: United States
employment_type: FULL_TIME
posted_at: 2026-02-25
Source URL: https://jobs.ashbyhq.com/drata/8528148b-9190-40c8-a1c4-2c7941428dde

JD Extract:
Our Mission & Values:
At Drata, we help companies earn and keep the trust of their users, customers, partners, and prospects. We’re the proof layer that shows great companies deserve the trust they aim to build.
We live our values every day. Built on Trust means consistency is everything. Act with Integrity by always doing the right thing. Being Customer-Obsessed keeps the people we serve at the center of our work. Competitive Fire drives us to push ourselves harder than anyone else. Diversity brings unique perspectives that lead to better solutions. Automation First ensures we save time and money by making efficiency a priority.
Our Culture & Work Style 🚀
At Drata, we’re not just building software - we’re building a mindset. Everything we do springs from:
Be a Driver (Owner‑Operator Mentality): Own your work. Improve relentlessly. Deliver results.
Move at Drata Speed (Precision & Velocity): Fast decisions. Quick learning. Immediate impact.
Stay Mission-Driven (Customer‑Obsessed): Challenge assumptions. Deliver value. Stay hungry.
While we’re ideally looking for someone who can join us in a hybrid capacity from our San Francisco office, we know great talent isn’t limited by zip code. We’ll consider remote candidates across the U.S. who are a strong match for the role.
If you thrive when you’re empowered, energized, and working with smart, mission-driven people where you’ll feel at home here.
Why Join The Drata Team?
The best way to understand the Driver’s Mindset is to see it in action. We’re an award-winning, mission-driven team of 600+ people worldwide , united by a culture that values trust, speed, and continuous growth.
See the Speed: Watch our CEO, Adam Markowitz, discuss the hyper-growth journey, from $0 to $100M ARR in just four years
Hear the Voice of the Team : Explore our "Life at Drata" page for employee testimonials on our collaborative and the growth opportunities available.
Experience the Impact : See why we are consistently recognized on Fortune's Best Workplaces lists.
Connect with Us on Socials: LinkedIn - follow us for company updates, employee stories, and career news.
Job Summary:
Drata, at the vanguard of compliance software innovation and renowned for its commitment to trust and security across the internet, is on an ambitious path to redefine how AI and General AI technologies bolster compliance automation.
Drata is seeking an Applied AI Engineer to drive the quality and effectiveness of our AI systems through rigorous research, experimentation, and evaluation. In this role, you will optimize retrieval strategies, build evaluation frameworks, and establish the scientific foundation that enables our AI features to deliver accurate, trustworthy results.
This is a research-focused role emphasizing experimentation and rigor over production engineering. You'll work closely with AI Engineers handing off validated approaches for them to productionize while owning the quality metrics and evaluation systems that ensure our AI delivers on its promises.
Drata's compliance platform is document-heavy: VRM Agent, AIQA, Trust Agent, policy-to-control mappers, and regulatory summarization all depend on retrieving the right information from large document sets. Your work will directly impact how well our AI understands and navigates compliance artifacts.
Location: While we’re ideally looking for someone who can join us in a hybrid capacity from our San Francisco office, we know great talent isn’t limited by zip code. We’ll consider remote candidates across the U.S. who are a strong match for the role.
What you'll do:
Design and evaluate information access + reasoning strategies across RAG, agents, and classic ML: chunking, embedding models, hybrid search, metadata filtering, structured retrieval, tool use, and multi-step workflows
Prototype GenAI workflows (including agentic systems) that map and reason over compliance objects (controls ↔ risks ↔ requirements)
Explore ML + probabilistic approaches where GenAI is not the best fit: classifiers, ranking models, graph/link prediction, calibration, and weak supervision
Build and maintain evaluation frameworks : golden datasets, automated quality metrics, regression detection
Implement and tune ranking/reranking systems : cross-encoders, LLM-based rerankers, learning-to-rank, custom scoring functions
Run experiments to validate hypotheses and quantify improvements before production rollout
Debug failure modes and build error taxonomies across retrieval, reasoning, and generation
Collaborate with AI and Software Engineers to hand off validated approaches for productionization
Stay current on applied research in RAG, agents, LLM evaluation, and relevance modeling; bring innovations into the product
What you'll bring:
6+ years of experience in applied research, data science, or ML with a focus on NLP, information retrieval, or knowledge systems
2+ years of hands-on experience building or contributing to production AI/ML systems
Strong foundation in information retrieval: dense and sparse retrieval, embedding models, search relevance
Experience with RAG systems: chunking strategies, vector databases, retrieval optimization
Proficiency in evaluation methodology: metrics design, golden dataset creation, A/B testing, statistical analysis
Strong Python skills and comfort with notebook-driven research workflows
Experience communicating research findings to engineering teams and translating insights into actionable recommendations
Bonus: Experience with compliance, legal, or document-heavy domains
Bonus: Publications or contributions in IR, NLP, or RAG evaluation
Your contributions at Drata will not only shape the future of compliance and security automation but also solidify our standing as an innovator in the space, driving forward our mission with cutting-edge technology.
How we support you:
At Drata, our people are our strongest advantage—and we prove it with support that exceeds industry standards. Our total rewards package is designed to power your well-being, accelerate your growth, and keep your work-life balance thriving.
Explore how we invest in your Life at Drata .
Shared Success : We provide stock equity to ensure that as the company grows, you share directly in that success. Equity gives every employee a sense of ownership and the opportunity to celebrate our wins together—because your contributions don’t just support our progress; they help drive our collective success.
Health & Wellness: Up to 100% employer-paid premiums f
