# Drata - Senior Applied AI Engineer

- Job ID: `drata-senior-applied-ai-engineer-daa45ee5f79b2bf0`
- Board: `ashby`
- Location: While we’re ideally looking for someone who can join us in a hybrid capacity from our San Francisco office, we know great talent isn’t limited by zip code. We’ll consider remote candidates across the U.S. who are a strong match for the role.
- Work mode: remote
- Link: https://jobs.ashbyhq.com/drata/8528148b-9190-40c8-a1c4-2c7941428dde
- Match: 77.8%
- Recommendation: `apply`
- Posted: 2026-02-25

## Flags
- Listing is older than the default 24-hour freshness window.

## Rationale
Drata | Senior Applied AI Engineer scored 77.8/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
