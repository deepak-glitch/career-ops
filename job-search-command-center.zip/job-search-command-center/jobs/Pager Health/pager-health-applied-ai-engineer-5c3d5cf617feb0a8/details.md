# Pager Health - Applied AI Engineer

- Job ID: `pager-health-applied-ai-engineer-5c3d5cf617feb0a8`
- Board: `local`
- Location: Remote - United States
- Work mode: remote
- Link: https://www.indeed.com/viewjob?jk=1f140484f5766fbb
- Match: 82.1%
- Recommendation: `apply`
- Posted: unknown

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Pager Health | Applied AI Engineer scored 82.11/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
