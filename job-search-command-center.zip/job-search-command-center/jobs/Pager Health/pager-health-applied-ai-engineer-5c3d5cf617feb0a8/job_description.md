Company: Pager Health
Title: Applied AI Engineer
Location: Remote - United States
employment_type: Full-time
Source URL: https://www.indeed.com/viewjob?jk=1f140484f5766fbb

Applied AI Engineer role focused on healthcare AI systems. The role emphasizes LLM-powered applications, agent orchestration, retrieval-augmented generation, evaluation pipelines, observability, and production deployment. The team is looking for strong Python engineering, API development, cloud deployment, guardrails, and healthcare-aware AI implementation. The environment values cross-functional collaboration, product impact, and practical responsible AI delivery.
