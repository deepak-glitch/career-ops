# Concentrate AI - AI Engineer

- Job ID: `concentrate-ai-ai-engineer-975cd5e32f292f78`
- Board: `generic`
- Location: United States, United States
- Work mode: remote
- Link: https://jobs.ashbyhq.com/Concentrate%20AI/42e613b8-8532-44f8-ab0e-de18e6fbc2e3
- Match: 76.8%
- Recommendation: `apply`
- Posted: unknown

## Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Rationale
Concentrate AI | AI Engineer scored 76.75/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
