# Rula - Staff AI Engineer - Applied AI (Remote)

- Job ID: `rula-staff-ai-engineer-applied-ai-rem-1e9ad9739bdea1d9`
- Board: `ashby`
- Location: Los Angeles, California , United States
- Work mode: remote
- Link: https://jobs.ashbyhq.com/rula/d477da0d-6d23-4166-8afd-6a6a334f4710
- Match: 78.3%
- Recommendation: `apply`
- Posted: 2026-03-31

## Flags
- Listing is older than the default 24-hour freshness window.

## Rationale
Rula | Staff AI Engineer - Applied AI (Remote) scored 78.3/100 with 1 red-flag signal(s).

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
