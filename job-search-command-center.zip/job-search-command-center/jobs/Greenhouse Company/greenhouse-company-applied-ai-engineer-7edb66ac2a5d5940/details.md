# Greenhouse Company - Applied AI Engineer

- Job ID: `greenhouse-company-applied-ai-engineer-7edb66ac2a5d5940`
- Board: `greenhouse`
- Location: Remote - US
- Work mode: unknown
- Link: https://job-boards.greenhouse.io/example/jobs/1001
- Match: 73.9%
- Recommendation: `apply`
- Posted: 2026-04-11T16:00:00Z

## Rationale
Greenhouse Company | Applied AI Engineer scored 73.91/100 with no blocking red flags.

## Outputs
- `resume.pdf` (tailored) 
- `resume.txt` (ATS text) 
- `job_description.md` (saved JD text)
- `candidacy.json` (scorecard + keywords)
