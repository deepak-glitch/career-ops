Build agentic workflow systems, evaluation pipelines, Python services, and partner closely with product.
