# Job Search Command Center

Local-first Python toolkit for resume-driven AI job search, job ranking, resume tailoring, application artifact generation, and pipeline tracking.

The project is designed around a simple idea: import a candidate profile, ingest job listings from supported boards or local fixtures, score each role against the candidate, generate company-specific resumes, and keep everything in a file-based workflow that is easy to inspect and version.

## What This Project Does

- imports a resume and personal-information DOCX into a structured candidate profile
- expands likely target titles such as `AI Engineer`, `Applied AI Engineer`, `LLM Engineer`, `RAG Engineer`, `Agentic AI Engineer`, and related roles
- ingests job listings from public board payloads or browser-assisted inputs
- scores jobs on a `0-100` match scale using title fit, keyword overlap, domain fit, seniority, sponsorship risk, freshness, and evidence strength
- deduplicates repeated listings across boards
- generates tailored resumes and cover-letter artifacts
- rebuilds tracker and summary projections from canonical offer files
- supports a lightweight terminal dashboard for browsing tracked jobs

## Main Workflow

1. Import a candidate profile from source documents.
2. Suggest target titles and search phrases.
3. Ingest jobs from supported boards or local fixture files.
4. Score and rank the jobs.
5. Generate tailored resumes, reports, and apply packs.
6. Track everything in markdown, JSON, CSV, and file-based artifacts.

## Quick Start

### 1. Requirements

- Python `3.11+`
- Windows PowerShell for the helper commands in this README
- Optional: Microsoft Word if you want to experiment with DOCX to PDF conversion outside the built-in renderer

### 2. Install

```powershell
cd C:\Users\deepa\OneDrive\Documents\New project\job-search-command-center
python -m pip install --upgrade pip
python -m pip install -e .
```

You can also run the project without installing it by using:

```powershell
python job_center.py --help
```

### 3. Import Candidate Data

```powershell
python job_center.py profile import `
  --resume-docx "C:\path\to\resume.docx" `
  --personal-docx "C:\path\to\personal-info.docx"
```

This generates or updates:

- `config/candidate_profile.json`
- `config/resume_facts.md`
- `config/proof_bank.md`
- `config/search_preferences.json`
- `data/generated/suggested_titles.json`
- `data/projections/suggested_titles.md`

### 4. Review Suggested Titles

```powershell
python job_center.py titles suggest
```

### 5. Run a Search

```powershell
python job_center.py search run `
  --boards linkedin,indeed,dice,greenhouse,lever,ashby `
  --min-match 70 `
  --posted-within-hours 24 `
  --limit-per-board 25
```

### 6. Evaluate a Specific Job

```powershell
python job_center.py evaluate fixtures\live_jobs_2026-04-13\pager_health_applied_ai_engineer.md
```

### 7. Build Resume and PDF Artifacts

```powershell
python job_center.py pdf build pager-health-applied-ai-engineer-5c3d5cf617feb0a8
```

### 8. Generate an Apply Pack

```powershell
python job_center.py apply-pack pager-health-applied-ai-engineer-5c3d5cf617feb0a8
```

### 9. Rebuild Projections and Check Integrity

```powershell
python job_center.py integrity rebuild
python job_center.py integrity check
```

### 10. Open the Tracker or TUI

```powershell
python job_center.py tracker
python job_center.py tui
```

## How To Run This Project End To End

For a fresh user workflow:

```powershell
python job_center.py profile import --resume-docx "C:\path\resume.docx" --personal-docx "C:\path\personal.docx"
python job_center.py titles suggest
python job_center.py search run --boards dice,greenhouse,lever,ashby --min-match 70 --posted-within-hours 24 --limit-per-board 25
python job_center.py batch run --parallel 4
python job_center.py tracker
```

For a fixture-driven local demo:

```powershell
python job_center.py evaluate fixtures\live_jobs_2026-04-13\acentra_health_ml_ai_engineer.md
python job_center.py pdf build acentra-health-machine-learning-engineer-ai-eng-0b659d4955cb6a18 --no-cover-letter
python job_center.py apply-pack acentra-health-machine-learning-engineer-ai-eng-0b659d4955cb6a18
```

For tests:

```powershell
python -m unittest discover -s tests -v
```

## Repository Structure

### Top Level

- `job_center.py`
  Lightweight launcher that adds `src/` to `PYTHONPATH` and delegates to the CLI.
- `pyproject.toml`
  Packaging metadata, Python version requirement, and console-script entry point.
- `README.md`
  Project overview, architecture, and run instructions.
- `.gitignore`
  Ignore rules for generated local artifacts and runtime state.

### `config/`

- `candidate_profile.json`
  Canonical structured candidate profile used by scoring and resume generation.
- `resume_facts.md`
  Extracted and normalized resume facts used as grounded evidence.
- `proof_bank.md`
  Quantified accomplishments and reusable evidence statements.
- `search_preferences.json`
  Search configuration, board input locations, and browser-assisted source preferences.
- `resume_rules.md`
  Standing rules for truthfulness, ATS formatting, keyword strategy, and final-pass resume polishing.

### `data/`

- `offers/`
  Canonical offer JSON files. Each file stores normalized job metadata, scorecard, recommendation, and artifact references.
- `artifacts/`
  Per-job generated files such as reports, resumes, cover letters, and apply packs.
- `generated/`
  Human-facing generated outputs such as custom resumes and suggested titles.
- `projections/`
  Rebuilt summary outputs such as rankings, top matches, fresh matches, and title summaries.
- `logs/events.jsonl`
  Event log for discoveries, evaluations, artifact creation, and failures.
- `runs/`
  Batch-run execution summaries.
- `tracker.md`
  Main markdown tracker of jobs and generated artifacts.
- `pipeline.md`
  Inbox, in-progress, and closed pipeline view.
- `scan-history.tsv`
  Flat historical record of discovered jobs.
- `daily-summary.md`
  Lightweight rollup of counts and match totals.

### `fixtures/`

- `greenhouse_jobs.json`
  Sample board fixture for local scans and tests.
- `live_jobs_2026-04-13/*.md`
  Local normalized job descriptions used for evaluation, ranking, and resume generation during development.

### `scripts/`

- `export_docx_to_pdf.ps1`
  Helper script for DOCX to PDF export experiments through Word automation.

### `src/job_search_command_center/`

#### Package Entry

- `__init__.py`
  Package marker.
- `__main__.py`
  Allows `python -m job_search_command_center` style execution.

#### `cli/`

- `main.py`
  Defines all CLI commands such as `profile import`, `search run`, `evaluate`, `pdf build`, `apply-pack`, `tracker`, and `integrity`.

#### `engine/`

- `candidate.py`
  Loads the candidate profile and source materials from `config/`.
- `ids.py`
  Generates job IDs, normalized text, and content fingerprints.
- `pipeline.py`
  Main orchestration layer for scanning, importing, searching, evaluating, batching, and artifact generation.
- `profile_import.py`
  DOCX ingestion and conversion into structured candidate data and derived config files.
- `projections.py`
  Builds markdown, TSV, JSON, and CSV projection outputs from canonical offers.
- `reports.py`
  Core resume and cover-letter writing logic, company-specific tailoring, keyword extraction, experience ranking, and project selection.
- `scoring.py`
  Match model and scoring logic for the `0-100` fit score.
- `store.py`
  File-backed persistence layer for offers, events, artifacts, and projection rebuilds.
- `types.py`
  Shared dataclasses, enums, schemas, and validation helpers.

#### `adapters/agents/`

- `base.py`
  Shared agent contract.
- `codex.py`
  Default agent adapter used for offer evaluation and resume-input generation.
- `mock.py`
  Testing adapter that reuses the Codex contract with lighter behavior.

#### `adapters/portals/`

- `base.py`
  Base portal adapter interface.
- `common.py`
  Shared normalization helpers such as keyword overlap and URL canonicalization.
- `generic.py`
  Generic portal reader for local files or URLs.
- `greenhouse.py`
  Greenhouse payload adapter.
- `lever.py`
  Lever payload adapter.
- `ashby.py`
  Ashby payload adapter.
- `linkedin.py`
  LinkedIn browser-assisted input adapter.
- `indeed.py`
  Indeed browser-assisted input adapter.
- `dice.py`
  Dice payload adapter.

#### `adapters/render/`

- `docx.py`
  DOCX renderer that uses the approved Word template structure and writes tailored resumes into DOCX form.
- `pdf.py`
  ATS-safe text-based PDF renderer with resume-aware layout rules for skills, headings, bullets, and spacing.

#### `integrity/`

- `checks.py`
  Integrity validation and projection rebuild helpers.

#### `tui/`

- `app.py`
  Minimal terminal dashboard for filtering and inspecting tracked offers.

### `tests/`

- `test_system.py`
  End-to-end test coverage for profile import, dedupe, search, scoring, PDF/apply-pack generation, integrity checks, and batch behavior.

## Resume Creation Rules

Resume generation in this project is based on all three of these files together:

- `config/resume_rules.md`
- `src/job_search_command_center/engine/reports.py`
- `src/job_search_command_center/adapters/render/pdf.py`

Do not treat any one of them as the only source of truth.

High-level resume rules:

- keep resumes truthful to real work history, projects, dates, and tools
- keep them ATS-friendly and single-column
- prefer keyword-rich wording when there is a tradeoff
- match summary, skills, experience, and projects to the target role
- always do one more final hand-edited pass on the newest generated resumes after job search results are produced

## Supported Job Input Modes

This project supports two practical input styles:

- local fixture or saved payload inputs
- browser-assisted board inputs for sites that are not friendly to direct scraping

Current board names supported by the CLI:

- `linkedin`
- `indeed`
- `dice`
- `greenhouse`
- `lever`
- `ashby`
- `generic`

## Output Files You Will Usually Care About

- `data/projections/match_rankings.json`
- `data/projections/match_rankings.csv`
- `data/projections/top_matches_70_plus.md`
- `data/projections/fresh_matches_24h.md`
- `data/projections/suggested_titles.md`
- `data/generated/custom_resumes_2026-04-13-docx/`
- `data/generated/custom_resumes_2026-04-13/`

## Privacy And GitHub Notes

This is a local-first toolkit. The repository structure is GitHub-ready, but personal candidate data and generated resumes are typically local runtime artifacts.

Before publishing publicly:

- replace personal config files with your own or with safe sample versions
- review generated resumes and job artifacts before committing them
- keep board input payloads and sensitive candidate documents out of the public repo

The `.gitignore` is set up to avoid committing most generated runtime outputs, but review your working tree before pushing.

## Recommended GitHub Description

Resume-driven local-first AI job search toolkit for importing a candidate profile, ranking jobs, generating tailored resumes, and tracking the application pipeline.

## License

MIT
