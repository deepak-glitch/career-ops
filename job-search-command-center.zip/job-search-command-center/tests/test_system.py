from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from job_search_command_center.adapters.agents.codex import CodexAgentAdapter
from job_search_command_center.adapters.agents.mock import MockAgentAdapter
from job_search_command_center.engine.candidate import load_candidate
from job_search_command_center.engine.pipeline import (
    build_apply_pack,
    build_pdf_artifacts,
    evaluate_offer,
    import_candidate_profile,
    run_batch,
    scan_source,
    search_jobs,
)
from job_search_command_center.engine.store import FileStore
from job_search_command_center.engine.types import OfferRecord, OfferState, SourceType, utc_now
from job_search_command_center.integrity.checks import rebuild_projections, run_integrity_check


def bootstrap_workspace() -> tuple[tempfile.TemporaryDirectory[str], Path]:
    temp_dir = tempfile.TemporaryDirectory()
    root = Path(temp_dir.name)
    for relative in [
        "config",
        "data/offers",
        "data/runs",
        "data/artifacts",
        "data/logs",
        "data/projections",
        "data/generated",
        "fixtures",
    ]:
        (root / relative).mkdir(parents=True, exist_ok=True)
    for filename in ["candidate_profile.json", "resume_facts.md", "proof_bank.md"]:
        shutil.copy(REPO_ROOT / "config" / filename, root / "config" / filename)
    shutil.copy(REPO_ROOT / "fixtures" / "greenhouse_jobs.json", root / "fixtures" / "greenhouse_jobs.json")
    return temp_dir, root


def write_docx(path: Path, text: str) -> None:
    document_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f'<w:body><w:p><w:r><w:t>{text}</w:t></w:r></w:p></w:body></w:document>'
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        "</Types>"
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>'
    )
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", rels)
        archive.writestr("word/document.xml", document_xml)


def make_offer(job_id: str, state: OfferState = OfferState.VERIFIED, note: str | None = None) -> OfferRecord:
    notes = [note] if note else []
    return OfferRecord(
        schema_version="2.0",
        job_id=job_id,
        company="Acme AI",
        title="Applied AI Engineer",
        source_url=f"https://example.com/jobs/{job_id}",
        source_type=SourceType.GENERIC,
        location="Remote - US",
        employment_type="Full-time",
        state=state,
        description="Build Python AI workflow systems, agentic automation, RAG, and evaluation pipelines with product partners.",
        content_fingerprint=job_id,
        discovered_at=utc_now(),
        verified_at=utc_now(),
        last_updated_at=utc_now(),
        posted_at=None,
        discovery_method="test",
        liveness_status="active",
        notes=notes,
    )


class SystemTests(unittest.TestCase):
    def test_profile_import_writes_candidate_artifacts(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)

        resume_docx = root / "fixtures" / "resume.docx"
        personal_docx = root / "fixtures" / "personal.docx"
        write_docx(
            resume_docx,
            "Name: Deepak Mallampati New Email: deepakmallampati00@gmail.com Total Experience( in number): 2.5 "
            "Targeted Roles: Applied AI Engineer, Generative AI Engineer, LLM Engineer Experiences - "
            "Industries: Healthcare Technology, Artificial Intelligence, SaaS At Progress Solutions "
            "Built RAG, FastAPI, Docker, Computer Vision, YOLO, Transformers systems.",
        )
        write_docx(
            personal_docx,
            "Full Name *: Deepak Mallampati Suffix (Optional): Contact Information "
            "Current Location (City, State, Country) *: Kent, OH, United States Address "
            "Are you currently authorized to work lawfully in the United States? *: Yes "
            "Your visa Status? *: F1 Opt Do you require visa sponsorship in future? *: Yes "
            "What is your preferred work arrangement? *: ( Onsite, Remote, Hybrid, Flexible ) : Flexible "
            "Target Compensation Range *: 85000- 150000 dollars Are you open to relocation? *: Yes "
            "Current Company (if applicable): Progress Solutions Demographics",
        )

        summary = import_candidate_profile(root, str(resume_docx), str(personal_docx))
        candidate = load_candidate(root)

        self.assertTrue((root / summary.candidate_profile_path).exists())
        self.assertIn("Agentic AI Engineer", candidate.expanded_target_roles)
        self.assertIn("evaluation pipelines", candidate.professional_keywords)
        self.assertGreaterEqual(len(candidate.search_phrases), 6)
        self.assertTrue((root / summary.suggested_titles_path).exists())

    def test_scan_deduplicates_same_source(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)
        source = str(root / "fixtures" / "greenhouse_jobs.json")

        first = scan_source(root, source, "greenhouse")
        second = scan_source(root, source, "greenhouse")
        store = FileStore(root)
        offers = store.list_offers()

        self.assertEqual(first.discovered, 2)
        self.assertEqual(second.duplicates, 2)
        self.assertEqual(len(offers), 2)
        active = [offer for offer in offers if offer.liveness_status == "active"]
        self.assertEqual(len(active), 1)

    def test_search_run_dedupes_cross_board_and_builds_fresh_outputs(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)

        dice_dir = root / "data" / "board_inputs" / "dice"
        greenhouse_dir = root / "data" / "board_inputs" / "greenhouse"
        dice_dir.mkdir(parents=True, exist_ok=True)
        greenhouse_dir.mkdir(parents=True, exist_ok=True)

        (dice_dir / "jobs.json").write_text(
            json.dumps(
                {
                    "jobs": [
                        {
                            "jobTitle": "Applied AI Engineer",
                            "detailUrl": "https://www.dice.com/job-detail/job-1?utm_source=test",
                            "companyName": "Bright Ops",
                            "jobLocation": "Remote - US",
                            "employmentType": "Full-time",
                            "datePosted": "2 hours ago",
                            "jobDescription": "Build LLM application development, retrieval-augmented generation, agentic workflows, FastAPI, Docker, and model observability.",
                        },
                        {
                            "jobTitle": "Backend Java Engineer",
                            "detailUrl": "https://www.dice.com/job-detail/job-2",
                            "companyName": "Legacy Stack",
                            "jobLocation": "Onsite",
                            "employmentType": "Full-time",
                            "datePosted": "26 hours ago",
                            "jobDescription": "Pure Java backend maintenance role with Spring and SQL.",
                        },
                    ]
                }
            ),
            encoding="utf-8",
        )
        (greenhouse_dir / "jobs.json").write_text(
            json.dumps(
                {
                    "jobs": [
                        {
                            "title": "Applied AI Engineer",
                            "absolute_url": "https://www.dice.com/job-detail/job-1?utm_source=greenhouse-copy",
                            "location": {"name": "Remote - US"},
                            "updated_at": "2026-04-13T10:00:00+0000",
                            "content": "Build LLM application development, retrieval-augmented generation, agentic workflows, FastAPI, Docker, and model observability.",
                            "metadata": [{"name": "employment_type", "value": "Full-time"}],
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )

        summary = search_jobs(root, boards=["dice", "greenhouse"], min_match=70, posted_within_hours=24, limit_per_board=10)
        store = FileStore(root)
        offers = store.list_offers()

        self.assertGreaterEqual(summary.discovered, 2)
        self.assertEqual(len(offers), 2)
        top_offer = max(offers, key=lambda item: item.match_score_pct or 0.0)
        stale_offer = min(offers, key=lambda item: item.match_score_pct or 0.0)
        self.assertGreaterEqual(top_offer.match_score_pct or 0.0, 70.0)
        self.assertLess(stale_offer.posted_age_hours or 999.0, 30.0)
        fresh_md = store.fresh_matches_path.read_text(encoding="utf-8")
        self.assertIn("Bright Ops", fresh_md)
        self.assertNotIn("Legacy Stack", fresh_md)
        rankings_json = json.loads(store.match_rankings_json_path.read_text(encoding="utf-8"))
        self.assertEqual(len(rankings_json), 2)
        self.assertEqual(len([row for row in rankings_json if row["company"] == "Bright Ops"]), 1)

    def test_batch_is_resumable_and_skips_completed_work(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)
        store = FileStore(root)
        for index in range(10):
            note = "force_fail" if index == 3 else None
            store.save_offer(make_offer(f"job-{index}", note=note))
        rebuild_projections(root)

        first = run_batch(root, parallel=4)
        offers_after_first = store.list_offers()
        self.assertEqual(len(first.completed), 9)
        self.assertEqual(len(first.failed), 1)
        self.assertEqual(len([offer for offer in offers_after_first if offer.state == OfferState.PACKET_READY]), 9)

        second = run_batch(root, parallel=4)
        self.assertEqual(len(second.completed), 0)
        self.assertEqual(len(second.failed), 1)

    def test_scorecard_known_jd_produces_apply_band_and_unrelated_role_is_low(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)
        strong_jd = root / "fixtures" / "strong_jd.md"
        strong_jd.write_text(
            "Company: Bright Ops\n"
            "Title: Applied AI Engineer\n"
            "Location: Remote - US\n"
            "employment_type: Full-time\n\n"
            "Build LLM application development, retrieval-augmented generation, agentic workflows, evaluation pipelines, "
            "FastAPI, Docker, vector search, structured outputs, and product integrations.",
            encoding="utf-8",
        )
        unrelated_jd = root / "fixtures" / "unrelated_jd.md"
        unrelated_jd.write_text(
            "Company: Legacy Stack\n"
            "Title: Payroll Accountant\n"
            "Location: Onsite\n"
            "employment_type: Full-time\n\n"
            "Handle payroll reconciliations, bookkeeping, GL close, and finance reporting.",
            encoding="utf-8",
        )

        strong_offer = evaluate_offer(root, str(strong_jd), "codex")
        unrelated_offer = evaluate_offer(root, str(unrelated_jd), "codex")

        self.assertGreaterEqual(strong_offer.match_score_pct or 0.0, 70.0)
        self.assertIn(strong_offer.recommendation.value, {"apply", "strong_apply"})
        self.assertLess(unrelated_offer.match_score_pct or 100.0, 55.0)
        self.assertEqual(unrelated_offer.recommendation.value, "no_apply")

    def test_pdf_and_apply_pack_are_generated_from_local_sources(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)
        jd_path = root / "fixtures" / "artifact_jd.md"
        jd_path.write_text(
            "Company: Signal Forge\n"
            "Title: Applied AI Engineer\n"
            "Location: Remote - US\n"
            "employment_type: Full-time\n\n"
            "Build Python AI workflow systems, retrieval-augmented generation, automation, and developer tooling with strong collaboration habits.",
            encoding="utf-8",
        )

        offer = evaluate_offer(root, str(jd_path), "codex")
        offer = build_pdf_artifacts(root, offer.job_id, "codex")
        offer = build_apply_pack(root, offer.job_id, "codex")

        store = FileStore(root)
        saved = store.ensure_offer_exists(offer.job_id)
        resume_pdf = root / saved.artifact_manifest.get(next(item.kind for item in saved.artifact_manifest.items if item.kind.value == "resume_pdf")).path
        resume_pdf_bytes = resume_pdf.read_bytes()
        self.assertTrue(resume_pdf_bytes.startswith(b"%PDF"))
        self.assertIn(b"Deepak Mallampati", resume_pdf_bytes)
        self.assertIn(b"/BaseFont /Times-Bold", resume_pdf_bytes)

        apply_pack_json = root / saved.artifact_manifest.get(next(item.kind for item in saved.artifact_manifest.items if item.kind.value == "apply_pack_json")).path
        apply_pack = json.loads(apply_pack_json.read_text(encoding="utf-8"))
        self.assertIn("config/candidate_profile.json", apply_pack["source_citations"])

    def test_integrity_check_catches_corrupt_offer_file(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)
        bad_path = root / "data" / "offers" / "broken.json"
        bad_path.write_text("{not json", encoding="utf-8")

        issues = run_integrity_check(root)
        self.assertTrue(any("Malformed offer file" in issue for issue in issues))

    def test_codex_and_mock_adapters_share_worker_contract(self) -> None:
        temp_dir, root = bootstrap_workspace()
        self.addCleanup(temp_dir.cleanup)
        candidate = load_candidate(root)
        offer = make_offer("contract-test")

        codex_result = CodexAgentAdapter().evaluate_offer(candidate, offer)
        mock_result = MockAgentAdapter().evaluate_offer(candidate, offer)

        for result in [codex_result, mock_result]:
            self.assertIn("company", result.normalized_jd_metadata)
            self.assertEqual(len(result.scorecard.dimensions), 10)
            self.assertIsInstance(result.report_body, str)
            self.assertIsInstance(result.source_citations, list)
        self.assertEqual(codex_result.scorecard.recommendation.value, mock_result.scorecard.recommendation.value)


if __name__ == "__main__":
    unittest.main()
