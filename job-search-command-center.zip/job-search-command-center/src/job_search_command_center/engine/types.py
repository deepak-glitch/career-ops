from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Iterable


class ValidationError(ValueError):
    """Raised when persisted data does not match the schema."""


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class OfferState(StrEnum):
    DISCOVERED = "discovered"
    VERIFIED = "verified"
    QUEUED = "queued"
    EVALUATED = "evaluated"
    PACKET_READY = "packet_ready"
    APPLIED = "applied"
    RESPONDED = "responded"
    INTERVIEW = "interview"
    OFFER = "offer"
    REJECTED = "rejected"
    ARCHIVED = "archived"


class Recommendation(StrEnum):
    STRONG_APPLY = "strong_apply"
    APPLY = "apply"
    SELECTIVE = "selective"
    NO_APPLY = "no_apply"


class EventType(StrEnum):
    DISCOVERED = "discovered"
    VERIFIED = "verified"
    STATE_CHANGED = "state_changed"
    EVALUATED = "evaluated"
    ARTIFACT_CREATED = "artifact_created"
    BATCH_RUN = "batch_run"
    FAILED = "failed"


class SourceType(StrEnum):
    GREENHOUSE = "greenhouse"
    ASHBY = "ashby"
    LEVER = "lever"
    LINKEDIN = "linkedin"
    INDEED = "indeed"
    DICE = "dice"
    GENERIC = "generic"
    LOCAL = "local"


class ArtifactKind(StrEnum):
    REPORT_MD = "report_md"
    RESUME_PDF = "resume_pdf"
    COVER_LETTER_PDF = "cover_letter_pdf"
    APPLY_PACK_JSON = "apply_pack_json"
    APPLY_PACK_MD = "apply_pack_md"


def _require_keys(data: dict[str, Any], keys: Iterable[str], type_name: str) -> None:
    missing = [key for key in keys if key not in data]
    if missing:
        raise ValidationError(f"{type_name} missing required keys: {', '.join(missing)}")


def _ensure_enum(value: Any, enum_type: type[StrEnum], field_name: str) -> StrEnum:
    try:
        return enum_type(value)
    except Exception as exc:
        raise ValidationError(f"invalid {field_name}: {value}") from exc


@dataclass(slots=True)
class ScoreDimension:
    key: str
    label: str
    weight: float
    score: float
    evidence: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScoreDimension":
        _require_keys(data, ("key", "label", "weight", "score", "evidence"), "ScoreDimension")
        return cls(
            key=str(data["key"]),
            label=str(data["label"]),
            weight=float(data["weight"]),
            score=float(data["score"]),
            evidence=str(data["evidence"]),
        )


@dataclass(slots=True)
class Scorecard:
    version: str
    dimensions: list[ScoreDimension]
    weighted_score: float
    red_flags: list[str]
    recommendation: Recommendation
    rationale: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Scorecard":
        _require_keys(
            data,
            ("version", "dimensions", "weighted_score", "red_flags", "recommendation", "rationale"),
            "Scorecard",
        )
        return cls(
            version=str(data["version"]),
            dimensions=[ScoreDimension.from_dict(item) for item in data["dimensions"]],
            weighted_score=float(data["weighted_score"]),
            red_flags=[str(item) for item in data["red_flags"]],
            recommendation=_ensure_enum(data["recommendation"], Recommendation, "recommendation"),
            rationale=str(data["rationale"]),
        )


@dataclass(slots=True)
class ArtifactRef:
    kind: ArtifactKind
    path: str
    format: str
    created_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ArtifactRef":
        _require_keys(data, ("kind", "path", "format", "created_at"), "ArtifactRef")
        return cls(
            kind=_ensure_enum(data["kind"], ArtifactKind, "kind"),
            path=str(data["path"]),
            format=str(data["format"]),
            created_at=str(data["created_at"]),
        )


@dataclass(slots=True)
class ArtifactManifest:
    items: list[ArtifactRef] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ArtifactManifest":
        _require_keys(data, ("items",), "ArtifactManifest")
        return cls(items=[ArtifactRef.from_dict(item) for item in data["items"]])

    def get(self, kind: ArtifactKind) -> ArtifactRef | None:
        for item in self.items:
            if item.kind == kind:
                return item
        return None


@dataclass(slots=True)
class ApplyPack:
    version: str
    job_id: str
    generated_at: str
    checklist: list[str]
    answers: dict[str, str]
    source_citations: list[str]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ApplyPack":
        _require_keys(data, ("version", "job_id", "generated_at", "checklist", "answers", "source_citations"), "ApplyPack")
        return cls(
            version=str(data["version"]),
            job_id=str(data["job_id"]),
            generated_at=str(data["generated_at"]),
            checklist=[str(item) for item in data["checklist"]],
            answers={str(k): str(v) for k, v in data["answers"].items()},
            source_citations=[str(item) for item in data["source_citations"]],
        )


@dataclass(slots=True)
class PortalResult:
    source_type: SourceType
    source_url: str
    company: str
    title: str
    location: str
    employment_type: str
    posted_at: str | None
    description: str
    discovered_at: str
    discovery_method: str
    content_fingerprint: str
    liveness_status: str = "unknown"
    board_name: str | None = None
    search_query: str | None = None
    posted_at_raw: str | None = None
    posted_age_hours: float | None = None
    salary_text: str | None = None
    work_mode: str | None = None
    sponsorship_text: str | None = None
    matched_keywords: list[str] = field(default_factory=list)
    missing_keywords: list[str] = field(default_factory=list)
    freshness_unknown: bool = False
    duplicate_group_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PortalResult":
        _require_keys(
            data,
            (
                "source_type",
                "source_url",
                "company",
                "title",
                "location",
                "employment_type",
                "posted_at",
                "description",
                "discovered_at",
                "discovery_method",
                "content_fingerprint",
                "liveness_status",
            ),
            "PortalResult",
        )
        return cls(
            source_type=_ensure_enum(data["source_type"], SourceType, "source_type"),
            source_url=str(data["source_url"]),
            company=str(data["company"]),
            title=str(data["title"]),
            location=str(data["location"]),
            employment_type=str(data["employment_type"]),
            posted_at=str(data["posted_at"]) if data["posted_at"] is not None else None,
            description=str(data["description"]),
            discovered_at=str(data["discovered_at"]),
            discovery_method=str(data["discovery_method"]),
            content_fingerprint=str(data["content_fingerprint"]),
            liveness_status=str(data["liveness_status"]),
            board_name=str(data["board_name"]) if data.get("board_name") is not None else None,
            search_query=str(data["search_query"]) if data.get("search_query") is not None else None,
            posted_at_raw=str(data["posted_at_raw"]) if data.get("posted_at_raw") is not None else None,
            posted_age_hours=float(data["posted_age_hours"]) if data.get("posted_age_hours") is not None else None,
            salary_text=str(data["salary_text"]) if data.get("salary_text") is not None else None,
            work_mode=str(data["work_mode"]) if data.get("work_mode") is not None else None,
            sponsorship_text=str(data["sponsorship_text"]) if data.get("sponsorship_text") is not None else None,
            matched_keywords=[str(item) for item in data.get("matched_keywords", [])],
            missing_keywords=[str(item) for item in data.get("missing_keywords", [])],
            freshness_unknown=bool(data.get("freshness_unknown", False)),
            duplicate_group_id=str(data["duplicate_group_id"]) if data.get("duplicate_group_id") is not None else None,
        )


@dataclass(slots=True)
class OfferRecord:
    schema_version: str
    job_id: str
    company: str
    title: str
    source_url: str
    source_type: SourceType
    location: str
    employment_type: str
    state: OfferState
    description: str
    content_fingerprint: str
    discovered_at: str
    verified_at: str | None
    last_updated_at: str
    posted_at: str | None
    discovery_method: str
    liveness_status: str
    scorecard: Scorecard | None = None
    recommendation: Recommendation | None = None
    artifact_manifest: ArtifactManifest = field(default_factory=ArtifactManifest)
    source_citations: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    match_score_pct: float | None = None
    work_mode: str | None = None
    salary_text: str | None = None
    sponsorship_note: str | None = None
    matched_keywords: list[str] = field(default_factory=list)
    missing_keywords: list[str] = field(default_factory=list)
    board_name: str | None = None
    search_query: str | None = None
    posted_at_raw: str | None = None
    posted_age_hours: float | None = None
    freshness_unknown: bool = False
    duplicate_group_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OfferRecord":
        _require_keys(
            data,
            (
                "schema_version",
                "job_id",
                "company",
                "title",
                "source_url",
                "source_type",
                "location",
                "employment_type",
                "state",
                "description",
                "content_fingerprint",
                "discovered_at",
                "verified_at",
                "last_updated_at",
                "posted_at",
                "discovery_method",
                "liveness_status",
                "artifact_manifest",
            ),
            "OfferRecord",
        )
        scorecard_data = data.get("scorecard")
        recommendation_value = data.get("recommendation")
        return cls(
            schema_version=str(data["schema_version"]),
            job_id=str(data["job_id"]),
            company=str(data["company"]),
            title=str(data["title"]),
            source_url=str(data["source_url"]),
            source_type=_ensure_enum(data["source_type"], SourceType, "source_type"),
            location=str(data["location"]),
            employment_type=str(data["employment_type"]),
            state=_ensure_enum(data["state"], OfferState, "state"),
            description=str(data["description"]),
            content_fingerprint=str(data["content_fingerprint"]),
            discovered_at=str(data["discovered_at"]),
            verified_at=str(data["verified_at"]) if data["verified_at"] is not None else None,
            last_updated_at=str(data["last_updated_at"]),
            posted_at=str(data["posted_at"]) if data["posted_at"] is not None else None,
            discovery_method=str(data["discovery_method"]),
            liveness_status=str(data["liveness_status"]),
            scorecard=Scorecard.from_dict(scorecard_data) if scorecard_data else None,
            recommendation=_ensure_enum(recommendation_value, Recommendation, "recommendation")
            if recommendation_value is not None
            else None,
            artifact_manifest=ArtifactManifest.from_dict(data["artifact_manifest"]),
            source_citations=[str(item) for item in data.get("source_citations", [])],
            notes=[str(item) for item in data.get("notes", [])],
            match_score_pct=float(data["match_score_pct"]) if data.get("match_score_pct") is not None else None,
            work_mode=str(data["work_mode"]) if data.get("work_mode") is not None else None,
            salary_text=str(data["salary_text"]) if data.get("salary_text") is not None else None,
            sponsorship_note=str(data["sponsorship_note"]) if data.get("sponsorship_note") is not None else None,
            matched_keywords=[str(item) for item in data.get("matched_keywords", [])],
            missing_keywords=[str(item) for item in data.get("missing_keywords", [])],
            board_name=str(data["board_name"]) if data.get("board_name") is not None else None,
            search_query=str(data["search_query"]) if data.get("search_query") is not None else None,
            posted_at_raw=str(data["posted_at_raw"]) if data.get("posted_at_raw") is not None else None,
            posted_age_hours=float(data["posted_age_hours"]) if data.get("posted_age_hours") is not None else None,
            freshness_unknown=bool(data.get("freshness_unknown", False)),
            duplicate_group_id=str(data["duplicate_group_id"]) if data.get("duplicate_group_id") is not None else None,
        )


@dataclass(slots=True)
class OfferEvent:
    event_id: str
    job_id: str
    event_type: EventType
    timestamp: str
    payload: dict[str, Any]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OfferEvent":
        _require_keys(data, ("event_id", "job_id", "event_type", "timestamp", "payload"), "OfferEvent")
        return cls(
            event_id=str(data["event_id"]),
            job_id=str(data["job_id"]),
            event_type=_ensure_enum(data["event_type"], EventType, "event_type"),
            timestamp=str(data["timestamp"]),
            payload=dict(data["payload"]),
        )


@dataclass(slots=True)
class WorkerResult:
    normalized_jd_metadata: dict[str, str]
    scorecard: Scorecard
    recommendation: Recommendation
    report_body: str
    artifact_manifest: ArtifactManifest
    source_citations: list[str]


@dataclass(slots=True)
class CandidateProfile:
    name: str
    email: str
    target_roles: list[str]
    preferred_domains: list[str]
    work_authorization: str
    remote_only: bool
    compensation_floor_usd: int
    summary: str
    resume_facts: str
    proof_bank: str
    source_citations: list[str]
    linkedin: str = ""
    phone: str = ""
    current_location: str = ""
    preferred_work_modes: list[str] = field(default_factory=list)
    open_to_relocation: bool = False
    salary_min_usd: int = 0
    salary_max_usd: int = 0
    work_auth_now: str = ""
    requires_future_sponsorship: bool = False
    years_experience: float = 0.0
    industries: list[str] = field(default_factory=list)
    core_skills: list[str] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)
    target_role_seeds: list[str] = field(default_factory=list)
    expanded_target_roles: list[str] = field(default_factory=list)
    professional_keywords: list[str] = field(default_factory=list)
    search_phrases: list[str] = field(default_factory=list)


def dataclass_to_dict(value: Any) -> Any:
    if isinstance(value, StrEnum):
        return value.value
    if is_dataclass(value):
        return {key: dataclass_to_dict(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: dataclass_to_dict(item) for key, item in value.items()}
    if isinstance(value, list):
        return [dataclass_to_dict(item) for item in value]
    return value


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
