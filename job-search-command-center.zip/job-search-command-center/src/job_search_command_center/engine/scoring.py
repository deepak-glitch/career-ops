from __future__ import annotations

import re
from dataclasses import dataclass

from job_search_command_center.engine.types import CandidateProfile, Recommendation, ScoreDimension, Scorecard


WEIGHTS: list[tuple[str, str, float]] = [
    ("title_alignment", "Title Alignment", 0.16),
    ("professional_keyword_overlap", "Professional Keyword Overlap", 0.13),
    ("agentic_llm_rag_relevance", "Agentic / LLM / RAG Relevance", 0.14),
    ("domain_relevance", "Domain Relevance", 0.08),
    ("seniority_fit", "Seniority Fit", 0.08),
    ("location_work_mode_fit", "Location / Work Mode Fit", 0.08),
    ("compensation_fit", "Compensation Fit", 0.06),
    ("sponsorship_risk", "Sponsorship Risk", 0.09),
    ("evidence_strength", "Evidence Strength", 0.12),
    ("freshness_bonus", "Freshness Bonus", 0.06),
]

AGENTIC_TERMS = [
    "agent",
    "agentic",
    "llm",
    "rag",
    "retrieval-augmented generation",
    "retrieval augmented generation",
    "prompt",
    "vector",
    "embedding",
    "evaluation",
    "guardrail",
    "observability",
    "structured output",
    "tool use",
    "tool calling",
]

JUNIOR_TERMS = ["intern", "internship", "junior", "new grad", "entry level"]
SENIOR_TERMS = ["senior", "staff", "lead", "principal", "architect"]


@dataclass(slots=True)
class ScoreContext:
    company: str
    title: str
    description: str
    location: str
    work_mode: str | None = None
    salary_text: str | None = None
    sponsorship_text: str | None = None
    posted_age_hours: float | None = None
    freshness_unknown: bool = False


def _normalize(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _contains_any(text: str, phrases: list[str]) -> int:
    lowered = _normalize(text)
    return sum(1 for phrase in phrases if _normalize(phrase) in lowered)


def _score_ratio(hits: int, total: int, floor: float = 0.0) -> float:
    if total <= 0:
        return floor
    return max(floor, min(1.0, hits / total))


def _percent(value: float) -> float:
    return round(max(0.0, min(100.0, value)), 2)


def _recommendation_for(score: float, red_flags: list[str]) -> Recommendation:
    if red_flags and score < 70:
        return Recommendation.NO_APPLY
    if score >= 85:
        return Recommendation.STRONG_APPLY
    if score >= 70:
        return Recommendation.APPLY
    if score >= 55:
        return Recommendation.SELECTIVE
    return Recommendation.NO_APPLY


def evaluate_scorecard(candidate: CandidateProfile, context: ScoreContext) -> Scorecard:
    title_text = _normalize(context.title)
    desc = _normalize(context.description)
    location_blob = _normalize(" ".join(part for part in [context.location, context.work_mode or ""] if part))
    sponsorship_blob = _normalize(context.sponsorship_text or context.description)
    salary_blob = _normalize(context.salary_text or context.description)

    expanded_roles = candidate.expanded_target_roles or candidate.target_roles
    exact_title_hit = any(_normalize(role) in title_text for role in expanded_roles)
    title_hits = _contains_any(title_text, expanded_roles)
    title_ratio = _score_ratio(title_hits, max(1, min(4, len(expanded_roles))), floor=0.1)
    title_score = _percent(100.0 if exact_title_hit else 40 + (title_ratio * 60))

    keyword_hits = _contains_any(desc, candidate.professional_keywords)
    keyword_ratio = _score_ratio(keyword_hits, max(6, min(12, len(candidate.professional_keywords))), floor=0.05)
    keyword_score = _percent(35 + (keyword_ratio * 65))

    agentic_hits = _contains_any(desc, AGENTIC_TERMS)
    agentic_ratio = _score_ratio(agentic_hits, 6, floor=0.0)
    agentic_score = _percent(35 + (agentic_ratio * 65))

    domain_hits = _contains_any(desc, candidate.domains or candidate.preferred_domains or candidate.industries)
    domain_score = _percent(35 + (_score_ratio(domain_hits, max(1, len(candidate.domains or candidate.preferred_domains or candidate.industries)), floor=0.0) * 65))

    years_score = 75.0 if candidate.years_experience >= 2 else 55.0
    seniority_penalty = 0.0
    if any(term in title_text for term in JUNIOR_TERMS):
        seniority_penalty = 45.0
    elif any(term in title_text for term in SENIOR_TERMS) and candidate.years_experience < 4:
        seniority_penalty = 10.0
    seniority_score = _percent(years_score - seniority_penalty)

    work_mode_score = 55.0
    preferred_modes = {_normalize(item) for item in candidate.preferred_work_modes}
    if "remote" in location_blob:
        work_mode_score = 95.0
    elif "hybrid" in location_blob:
        work_mode_score = 82.0
    elif "onsite" in location_blob:
        work_mode_score = 70.0 if candidate.open_to_relocation else 48.0
    elif preferred_modes:
        work_mode_score = 75.0
    location_work_mode_score = _percent(work_mode_score)

    compensation_score = 60.0
    if "$" in salary_blob or "salary" in salary_blob or "compensation" in salary_blob:
        compensation_score = 78.0
    if candidate.salary_min_usd and re.search(rf"\b({candidate.salary_min_usd//1000}|{candidate.salary_min_usd})\b", salary_blob):
        compensation_score = 88.0

    sponsorship_score = 90.0
    sponsorship_flags: list[str] = []
    if "no sponsorship" in sponsorship_blob and candidate.requires_future_sponsorship:
        sponsorship_score = 35.0
        sponsorship_flags.append("Role signals no sponsorship support, which may conflict with future needs.")
    if "must be us citizen" in sponsorship_blob or "security clearance" in sponsorship_blob:
        sponsorship_score = min(sponsorship_score, 45.0)
        sponsorship_flags.append("Role may require citizenship or clearance constraints.")

    evidence_hits = _contains_any(candidate.resume_facts + "\n" + candidate.proof_bank, candidate.professional_keywords + (candidate.expanded_target_roles or candidate.target_roles))
    evidence_score = _percent(45 + (_score_ratio(evidence_hits, 10, floor=0.0) * 55))

    if context.freshness_unknown:
        freshness_score = 25.0
    elif context.posted_age_hours is None:
        freshness_score = 40.0
    elif context.posted_age_hours <= 24:
        freshness_score = 100.0
    elif context.posted_age_hours <= 72:
        freshness_score = 40.0
    else:
        freshness_score = 10.0

    scores: dict[str, tuple[float, str]] = {
        "title_alignment": (
            title_score,
            "Scored from overlap between the role title and expanded AI, LLM, agentic, platform, and multimodal target titles.",
        ),
        "professional_keyword_overlap": (
            keyword_score,
            "Measures overlap with professional market language such as RAG, observability, guardrails, vector search, and production deployment.",
        ),
        "agentic_llm_rag_relevance": (
            agentic_score,
            "Rewards explicit references to agentic workflows, LLM application work, retrieval, structured outputs, and evaluation.",
        ),
        "domain_relevance": (
            domain_score,
            "Looks for healthcare, applied AI, SaaS, consulting, and related domain signals from the candidate profile.",
        ),
        "seniority_fit": (
            seniority_score,
            "Balances target scope against current years of experience while strongly discounting junior or internship roles.",
        ),
        "location_work_mode_fit": (
            location_work_mode_score,
            "Scores remote, hybrid, and relocation-compatible roles higher than ambiguous or restrictive setups.",
        ),
        "compensation_fit": (
            compensation_score,
            "Uses visible compensation language as a soft quality signal rather than inventing missing salary data.",
        ),
        "sponsorship_risk": (
            sponsorship_score,
            "Penalizes roles that explicitly reject sponsorship or impose work-authorization constraints.",
        ),
        "evidence_strength": (
            evidence_score,
            "Estimates how strongly the resume facts and proof bank support claims needed for the role.",
        ),
        "freshness_bonus": (
            freshness_score,
            "Boosts listings posted within the last 24 hours and discounts stale or ambiguous postings.",
        ),
    }

    red_flags: list[str] = []
    if any(term in title_text for term in JUNIOR_TERMS):
        red_flags.append("Role seniority is below the target level.")
    if title_score < 45:
        red_flags.append("Role title is weakly aligned with the target AI job family.")
    if context.posted_age_hours is not None and context.posted_age_hours > 24:
        red_flags.append("Listing is older than the default 24-hour freshness window.")
    if context.freshness_unknown:
        red_flags.append("Listing freshness is ambiguous, so it should not appear in fresh-only views.")
    red_flags.extend(sponsorship_flags)

    dimensions: list[ScoreDimension] = []
    weighted_total = 0.0
    for key, label, weight in WEIGHTS:
        score, evidence = scores[key]
        dimensions.append(ScoreDimension(key=key, label=label, weight=weight, score=score, evidence=evidence))
        weighted_total += score * weight

    if title_hits == 0:
        weighted_total -= 12
    elif title_score < 45:
        weighted_total -= 8
    if agentic_score < 35:
        weighted_total -= 4

    weighted_score = _percent(weighted_total)
    recommendation = _recommendation_for(weighted_score, red_flags)
    rationale = (
        f"{context.company} | {context.title} scored {weighted_score}/100 with "
        f"{'no blocking red flags' if not red_flags else f'{len(red_flags)} red-flag signal(s)'}."
    )
    return Scorecard(
        version="2.0",
        dimensions=dimensions,
        weighted_score=weighted_score,
        red_flags=red_flags,
        recommendation=recommendation,
        rationale=rationale,
    )
