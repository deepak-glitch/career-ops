from __future__ import annotations

import json
import os
from pathlib import Path
from threading import Lock
from typing import Iterable
from uuid import uuid4

from job_search_command_center.engine.projections import (
    build_daily_summary,
    build_match_rankings_csv,
    build_match_rankings_json,
    build_pipeline_md,
    build_scan_history_tsv,
    build_threshold_matches_md,
    build_tracker_md,
)
from job_search_command_center.engine.types import (
    ArtifactKind,
    ArtifactManifest,
    ArtifactRef,
    EventType,
    OfferEvent,
    OfferRecord,
    OfferState,
    ValidationError,
    dataclass_to_dict,
    ensure_parent,
    utc_now,
)

_PROJECTIONS_LOCK = Lock()
_OFFERS_LOCK = Lock()


def _atomic_write_text(path: Path, text: str, *, encoding: str = "utf-8") -> None:
    ensure_parent(path)
    tmp_path = path.with_name(f".{path.name}.{uuid4()}.tmp")
    tmp_path.write_text(text, encoding=encoding)
    os.replace(tmp_path, path)


def _atomic_write_bytes(path: Path, content: bytes) -> None:
    ensure_parent(path)
    tmp_path = path.with_name(f".{path.name}.{uuid4()}.tmp")
    tmp_path.write_bytes(content)
    os.replace(tmp_path, path)


class FileStore:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.data_dir = root / "data"
        self.offers_dir = self.data_dir / "offers"
        self.runs_dir = self.data_dir / "runs"
        self.artifacts_dir = self.data_dir / "artifacts"
        self.logs_dir = self.data_dir / "logs"
        self.projections_dir = self.data_dir / "projections"
        self.events_path = self.logs_dir / "events.jsonl"
        self.tracker_path = self.data_dir / "tracker.md"
        self.pipeline_path = self.data_dir / "pipeline.md"
        self.scan_history_path = self.data_dir / "scan-history.tsv"
        self.daily_summary_path = self.data_dir / "daily-summary.md"
        self.match_rankings_json_path = self.projections_dir / "match_rankings.json"
        self.match_rankings_csv_path = self.projections_dir / "match_rankings.csv"
        self.top_matches_path = self.projections_dir / "top_matches_70_plus.md"
        self.fresh_matches_path = self.projections_dir / "fresh_matches_24h.md"
        self.suggested_titles_path = self.projections_dir / "suggested_titles.md"
        self.ensure_layout()

    def ensure_layout(self) -> None:
        for path in (self.offers_dir, self.runs_dir, self.artifacts_dir, self.logs_dir, self.projections_dir):
            path.mkdir(parents=True, exist_ok=True)

    def offer_path(self, job_id: str) -> Path:
        return self.offers_dir / f"{job_id}.json"

    def save_offer(self, offer: OfferRecord) -> None:
        path = self.offer_path(offer.job_id)
        with _OFFERS_LOCK:
            _atomic_write_text(path, json.dumps(dataclass_to_dict(offer), indent=2), encoding="utf-8")

    def load_offer(self, job_id: str) -> OfferRecord:
        with _OFFERS_LOCK:
            data = json.loads(self.offer_path(job_id).read_text(encoding="utf-8"))
        return OfferRecord.from_dict(data)

    def list_offers(self) -> list[OfferRecord]:
        with _OFFERS_LOCK:
            offers: list[OfferRecord] = []
            for path in sorted(self.offers_dir.glob("*.json")):
                data = json.loads(path.read_text(encoding="utf-8"))
                offers.append(OfferRecord.from_dict(data))
            return offers

    def append_event(self, job_id: str, event_type: EventType, payload: dict[str, object]) -> OfferEvent:
        event = OfferEvent(
            event_id=str(uuid4()),
            job_id=job_id,
            event_type=event_type,
            timestamp=utc_now(),
            payload=payload,
        )
        ensure_parent(self.events_path)
        with self.events_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(dataclass_to_dict(event)) + "\n")
        return event

    def list_events(self) -> list[OfferEvent]:
        if not self.events_path.exists():
            return []
        events: list[OfferEvent] = []
        for line in self.events_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                events.append(OfferEvent.from_dict(json.loads(line)))
        return events

    def save_text_artifact(self, job_id: str, name: str, kind: ArtifactKind, text: str, suffix: str) -> ArtifactRef:
        path = self.artifacts_dir / job_id / f"{name}.{suffix.lstrip('.')}"
        _atomic_write_text(path, text, encoding="utf-8")
        return ArtifactRef(kind=kind, path=path.relative_to(self.root).as_posix(), format=suffix.lstrip("."), created_at=utc_now())

    def save_binary_artifact(self, job_id: str, name: str, kind: ArtifactKind, content: bytes, suffix: str) -> ArtifactRef:
        path = self.artifacts_dir / job_id / f"{name}.{suffix.lstrip('.')}"
        _atomic_write_bytes(path, content)
        return ArtifactRef(kind=kind, path=path.relative_to(self.root).as_posix(), format=suffix.lstrip("."), created_at=utc_now())

    def update_offer_artifacts(self, offer: OfferRecord, artifacts: Iterable[ArtifactRef]) -> OfferRecord:
        by_kind = {item.kind: item for item in offer.artifact_manifest.items}
        for artifact in artifacts:
            by_kind[artifact.kind] = artifact
        offer.artifact_manifest = ArtifactManifest(items=list(by_kind.values()))
        offer.last_updated_at = utc_now()
        return offer

    def set_offer_state(self, offer: OfferRecord, state: OfferState, note: str | None = None) -> OfferRecord:
        offer.state = state
        offer.last_updated_at = utc_now()
        if note:
            offer.notes.append(note)
        return offer

    def rebuild_projections(self) -> None:
        # Guard against concurrent batch threads rebuilding projections on Windows.
        with _PROJECTIONS_LOCK:
            offers = self.list_offers()
            self.tracker_path.write_text(build_tracker_md(self.root, offers), encoding="utf-8")
            self.pipeline_path.write_text(build_pipeline_md(offers), encoding="utf-8")
            self.scan_history_path.write_text(build_scan_history_tsv(offers), encoding="utf-8")
            self.daily_summary_path.write_text(build_daily_summary(offers), encoding="utf-8")
            self.match_rankings_json_path.write_text(build_match_rankings_json(offers), encoding="utf-8")

            csv_body = build_match_rankings_csv(offers)
            try:
                self.match_rankings_csv_path.write_text(csv_body, encoding="utf-8")
            except PermissionError:
                # Common on Windows when the CSV is open in Excel/Numbers; keep the run going.
                timestamp = utc_now().replace(":", "-")
                fallback = self.match_rankings_csv_path.with_name(
                    f"{self.match_rankings_csv_path.stem}__locked__{timestamp}{self.match_rankings_csv_path.suffix}"
                )
                fallback.write_text(csv_body, encoding="utf-8")

            self.top_matches_path.write_text(build_threshold_matches_md(offers, threshold=70.0), encoding="utf-8")
            self.fresh_matches_path.write_text(build_threshold_matches_md(offers, fresh_only=True), encoding="utf-8")

    def ensure_offer_exists(self, job_id: str) -> OfferRecord:
        path = self.offer_path(job_id)
        if not path.exists():
            raise ValidationError(f"offer not found: {job_id}")
        return self.load_offer(job_id)
