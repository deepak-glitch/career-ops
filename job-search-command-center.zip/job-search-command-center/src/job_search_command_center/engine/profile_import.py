from __future__ import annotations

import json
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path

from job_search_command_center.engine.candidate import DEFAULT_EXPANDED_TITLES, DEFAULT_PROFESSIONAL_KEYWORDS
from job_search_command_center.engine.types import ensure_parent


@dataclass(slots=True)
class ImportedProfile:
    candidate_profile: dict[str, object]
    resume_facts: str
    proof_bank: str
    search_preferences: dict[str, object]
    suggested_titles: list[str]


def _extract_docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        xml = archive.read("word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", " ", xml)
    text = text.replace("&amp;", "&")
    text = text.replace("â€“", "-").replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", text).strip()


def _find_text(pattern: str, text: str, default: str = "") -> str:
    match = re.search(pattern, text, re.IGNORECASE)
    return match.group(1).strip() if match else default


def _parse_list(value: str) -> list[str]:
    if not value:
        return []
    cleaned = value.replace("â€“", "-").replace("–", "-").replace("—", "-")
    return [item.strip() for item in re.split(r",|/|\|", cleaned) if item.strip()]


def _extract_roles(resume_text: str) -> list[str]:
    roles = _parse_list(_find_text(r"Targeted Roles:\s*(.+?)\s+Experiences\s*-", resume_text))
    return roles or DEFAULT_EXPANDED_TITLES[:4]


def _extract_email(text: str) -> str:
    return _find_text(r"([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})", text)


def _extract_phone(text: str) -> str:
    return _find_text(r"Phone\s*\*?\s*:\s*([+\d()\-\s]+)", text)


def _extract_years_experience(text: str) -> float:
    raw = _find_text(r"Total Experience\( in number\):\s*([0-9.]+)", text)
    try:
        return float(raw)
    except ValueError:
        return 0.0


def _extract_target_compensation(text: str) -> tuple[int, int]:
    raw = _find_text(r"Target Compensation Range\s*\*?\s*:\s*([0-9,\-\s]+)", text)
    numbers = [int(item.replace(",", "").strip()) for item in re.findall(r"\d[\d,]*", raw)]
    if len(numbers) >= 2:
        return numbers[0], numbers[1]
    if len(numbers) == 1:
        return numbers[0], numbers[0]
    return 85000, 150000


def _extract_current_location(text: str) -> str:
    return _find_text(r"Current Location \(City, State, Country\)\s*\*?\s*:\s*(.+?)\s+Address", text)


def _extract_work_modes(text: str) -> list[str]:
    raw = _find_text(r"preferred work arrangement\?\s*\*?\s*:\s*\([^)]*\)\s*:\s*(.+?)\s+Target Compensation Range", text)
    modes = _parse_list(raw)
    if not modes and raw:
        modes = [raw.strip()]
    return modes or ["Remote", "Hybrid", "Onsite"]


def _extract_linkedin(resume_text: str, personal_text: str) -> str:
    linkedin_url = _find_text(r"(https?://(?:www\.)?linkedin\.com/[^\s]+)", personal_text)
    if linkedin_url:
        return linkedin_url
    linkedin_url = _find_text(r"Linkedin\s*:\s*(https?://[^\s]+)", resume_text)
    if linkedin_url:
        return linkedin_url
    return "linkedin.com/in/deepak-mallampati"


def _extract_bool(pattern: str, text: str, default: bool = False) -> bool:
    value = _find_text(pattern, text)
    if not value:
        return default
    return value.strip().lower().startswith("y")


def _extract_industries(text: str) -> list[str]:
    industries = re.findall(r"Industries:\s*(.+?)\s+(?:At|My|One of)", text)
    flattened: list[str] = []
    for block in industries:
        flattened.extend(_parse_list(block))
    deduped: list[str] = []
    for item in flattened:
        if item not in deduped:
            deduped.append(item)
    return deduped


def _extract_core_skills(text: str) -> list[str]:
    skills = [
        "Python",
        "Pandas",
        "NumPy",
        "scikit-learn",
        "XGBoost",
        "FastAPI",
        "Flask",
        "Docker",
        "RAG",
        "LLM",
        "Agentic workflows",
        "Vector databases",
        "Embeddings",
        "Transformers",
        "Computer vision",
        "YOLO",
        "SQL",
        "Jenkins",
        "Grafana",
        "CI/CD",
    ]
    lowered = text.lower()
    return [skill for skill in skills if skill.lower().replace("/", " ") in lowered]


def suggest_titles(seed_roles: list[str], resume_text: str) -> list[str]:
    titles = list(dict.fromkeys(seed_roles + DEFAULT_EXPANDED_TITLES))
    lowered = resume_text.lower()
    if "computer vision" in lowered or "yolo" in lowered:
        titles.extend(["Computer Vision Engineer", "Multimodal AI Engineer"])
    if "platform" in lowered or "deployment" in lowered or "docker" in lowered:
        titles.append("AI Platform Engineer")
    if "healthcare" in lowered:
        titles.append("Healthcare AI Engineer")
    return list(dict.fromkeys(titles))


def build_search_phrases(titles: list[str], professional_keywords: list[str]) -> list[str]:
    phrases: list[str] = []
    keyword_pairs = professional_keywords[:8]
    for title in titles[:8]:
        phrases.append(title)
        for keyword in keyword_pairs[:3]:
            phrases.append(f"{title} {keyword}")
    return list(dict.fromkeys(phrases))[:24]


def import_profile(root: Path, resume_docx: str, personal_docx: str) -> ImportedProfile:
    resume_path = Path(resume_docx)
    personal_path = Path(personal_docx)
    resume_text = _extract_docx_text(resume_path)
    personal_text = _extract_docx_text(personal_path)

    seed_roles = _extract_roles(resume_text)
    suggested = suggest_titles(seed_roles, resume_text)
    salary_min, salary_max = _extract_target_compensation(personal_text)
    current_location = _extract_current_location(personal_text)
    preferred_work_modes = _extract_work_modes(personal_text)
    current_company = _find_text(r"Current Company \(if applicable\):\s*(.+?)\s+Demographics", personal_text, "Current Company")
    target_roles = list(dict.fromkeys(seed_roles + suggested[:4]))
    domains = ["Healthcare AI", "Applied AI", "SaaS", "Health Informatics", "Enterprise AI", "Computer Vision"]
    industries = _extract_industries(resume_text)
    core_skills = _extract_core_skills(resume_text)
    search_phrases = build_search_phrases(suggested, DEFAULT_PROFESSIONAL_KEYWORDS)

    candidate_profile = {
        "name": _find_text(r"Full Name \*:\s*(.+?)\s+Suffix", personal_text) or _find_text(r"Name:\s*(.+?)\s+New Email", resume_text),
        "email": _extract_email(resume_text) or _extract_email(personal_text),
        "linkedin": _extract_linkedin(resume_text, personal_text),
        "phone": _extract_phone(personal_text),
        "current_location": current_location,
        "target_roles": target_roles,
        "preferred_domains": ["Healthcare AI", "Applied AI systems", "Workflow automation", "Enterprise AI"],
        "domains": domains,
        "preferred_work_modes": preferred_work_modes,
        "work_authorization": "F-1 OPT, authorized to work in the United States now, future sponsorship required",
        "work_auth_now": "F-1 OPT",
        "remote_only": False,
        "open_to_relocation": _extract_bool(r"open to relocation\?\s*\*?\s*:\s*Yes/ No\s*:\s*(Yes|No)", personal_text, True),
        "requires_future_sponsorship": _extract_bool(r"future\?\s*\*?\s*:\s*Yes/ No\s*:\s*(Yes|No)", personal_text, True),
        "compensation_floor_usd": salary_min,
        "salary_min_usd": salary_min,
        "salary_max_usd": salary_max,
        "years_experience": _extract_years_experience(resume_text),
        "industries": industries,
        "core_skills": core_skills,
        "target_role_seeds": seed_roles,
        "expanded_target_roles": suggested,
        "professional_keywords": DEFAULT_PROFESSIONAL_KEYWORDS,
        "search_phrases": search_phrases,
        "summary": (
            f"Applied AI engineer with experience building RAG systems, agentic workflows, predictive ML pipelines, "
            f"and production-ready APIs across healthcare, enterprise, and multimodal use cases. Currently at {current_company}."
        ),
    }

    resume_facts = "\n".join(
        [
            "# Resume Facts",
            "",
            "## Experience",
            "",
            "### Progress Solutions Inc. | Jr. AI/ML Engineer Trainee | Jul 2025-Present",
            "- Built healthcare-focused retrieval-augmented generation systems for documentation search, policy retrieval, and internal knowledge access.",
            "- Designed agentic LLM workflows with structured reasoning, grounding rules, tool discipline, and evaluation-focused iteration.",
            "- Developed predictive ML pipelines for patient no-show risk, care engagement scoring, and support prioritization using Python, scikit-learn, and XGBoost.",
            "- Packaged AI inference services with Flask, FastAPI, logging, and Docker for production-style deployment and integration.",
            "",
            "### Energy Solutions International (Emerson) | Database and DevOps Engineering Intern | Jun 2022-Apr 2023",
            "- Improved SQL and stored procedure performance for enterprise oil and gas workflows, reducing latency and stabilizing reporting jobs.",
            "- Supported CI/CD automation with Jenkins, deployment validation, rollback readiness, and observability dashboards.",
            "",
            "### Suvidha Foundation | Machine Learning Engineer | Jan 2022-Mar 2022",
            "- Built a transformer-based video summarization and highlight generation system using transcript processing, timestamp alignment, and automated clip extraction.",
            "- Implemented document question answering and retrieval workflows to improve grounded answers and reduce hallucinated outputs.",
            "",
            "## Core Skills",
            "",
            "- Python, FastAPI, Flask, Docker, SQL, Jenkins, Grafana",
            "- LLMs, RAG, agentic workflows, embeddings, vector search, evaluation pipelines, structured outputs",
            "- scikit-learn, XGBoost, transformers, computer vision, multimodal systems",
        ]
    )
    proof_bank = "\n".join(
        [
            "# Proof Bank",
            "",
            "## Quantified Impact",
            "",
            "- Improved contextual retrieval precision by roughly 30-35% in healthcare RAG workflows.",
            "- Reduced hallucinated output scenarios by over 30% during evaluation cycles through better retrieval ranking and grounding controls.",
            "- Improved recall for high-risk predictive categories by 15-20% while maintaining strong precision.",
            "- Reduced post-deployment defects by around 30% with better API integration testing, packaging, and logging.",
            "- Reduced manual review time by 60-70% through AI-driven video summarization and highlight extraction.",
            "",
            "## Relevant Strengths",
            "",
            "- Practical applied AI engineering in regulated healthcare environments.",
            "- Agentic reasoning systems with structured outputs, traceability, and evaluation-driven refinement.",
            "- Cloud-ready API delivery with FastAPI, Flask, Docker, and production integration patterns.",
            "- Multimodal and computer vision work spanning video, monitoring, and AI-assisted automation.",
        ]
    )
    search_preferences = {
        "boards": ["linkedin", "indeed", "dice", "greenhouse", "lever", "ashby"],
        "min_match": 70,
        "posted_within_hours": 24,
        "dedupe": True,
        "browser_assisted_inputs": {
            "linkedin": "data/browser_inputs/linkedin",
            "indeed": "data/browser_inputs/indeed",
        },
        "search_phrases": search_phrases,
    }
    return ImportedProfile(
        candidate_profile=candidate_profile,
        resume_facts=resume_facts,
        proof_bank=proof_bank,
        search_preferences=search_preferences,
        suggested_titles=suggested,
    )


def write_imported_profile(root: Path, imported: ImportedProfile) -> None:
    config_dir = root / "config"
    generated_dir = root / "data" / "generated"
    projections_dir = root / "data" / "projections"
    suggested_titles_md = "# Suggested Titles\n\n" + "\n".join(f"- {title}" for title in imported.suggested_titles) + "\n"
    files = {
        config_dir / "candidate_profile.json": json.dumps(imported.candidate_profile, indent=2),
        config_dir / "resume_facts.md": imported.resume_facts,
        config_dir / "proof_bank.md": imported.proof_bank,
        config_dir / "search_preferences.json": json.dumps(imported.search_preferences, indent=2),
        generated_dir / "suggested_titles.json": json.dumps(imported.suggested_titles, indent=2),
        generated_dir / "suggested_titles.md": suggested_titles_md,
        projections_dir / "suggested_titles.md": suggested_titles_md,
    }
    for path, content in files.items():
        ensure_parent(path)
        path.write_text(content, encoding="utf-8")
