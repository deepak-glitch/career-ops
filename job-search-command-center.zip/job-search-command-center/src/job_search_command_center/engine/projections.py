from __future__ import annotations

import csv
import io
import json
from collections import Counter
from pathlib import Path

from job_search_command_center.engine.types import ArtifactKind, OfferRecord, OfferState


TRACKER_HEADER = (
    "| Job ID | Company | Role | Board | Location | Work Mode | Posted | Age Hours | Match % | "
    "Recommendation | Sponsorship | Duplicate Group | Resume PDF | Report |"
)
TRACKER_DIVIDER = "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"


def _sorted_offers(offers: list[OfferRecord]) -> list[OfferRecord]:
    return sorted(
        offers,
        key=lambda item: (
            item.freshness_unknown,
            item.posted_age_hours if item.posted_age_hours is not None else 999999,
            -(item.match_score_pct or 0.0),
            item.last_updated_at,
        ),
    )


def build_tracker_md(root: Path, offers: list[OfferRecord]) -> str:
    rows = [TRACKER_HEADER, TRACKER_DIVIDER]
    for offer in _sorted_offers(offers):
        report = offer.artifact_manifest.get(ArtifactKind.REPORT_MD)
        pdf = offer.artifact_manifest.get(ArtifactKind.RESUME_PDF)
        match_score = f"{offer.match_score_pct:.1f}" if offer.match_score_pct is not None else "-"
        recommendation = offer.recommendation.value if offer.recommendation else "-"
        posted = offer.posted_at_raw or offer.posted_at or "-"
        age_hours = f"{offer.posted_age_hours:.1f}" if offer.posted_age_hours is not None else "-"
        rows.append(
            f"| {offer.job_id} | {offer.company} | {offer.title} | {offer.board_name or offer.source_type.value} | "
            f"{offer.location} | {offer.work_mode or '-'} | {posted} | {age_hours} | {match_score} | {recommendation} | "
            f"{offer.sponsorship_note or '-'} | {offer.duplicate_group_id or '-'} | {pdf.path if pdf else '-'} | {report.path if report else '-'} |"
        )
    if len(rows) == 2:
        rows.append("| - | - | - | - | - | - | - | - | - | - | - | - | - | - |")
    return "# Tracker\n\n" + "\n".join(rows) + "\n"


def build_pipeline_md(offers: list[OfferRecord]) -> str:
    pending_states = {OfferState.VERIFIED, OfferState.QUEUED}
    active_states = {OfferState.EVALUATED, OfferState.PACKET_READY}
    closed_states = {OfferState.APPLIED, OfferState.RESPONDED, OfferState.INTERVIEW, OfferState.OFFER, OfferState.REJECTED, OfferState.ARCHIVED}

    def lines_for(states: set[OfferState]) -> list[str]:
        matching = [offer for offer in _sorted_offers(offers) if offer.state in states]
        if not matching:
            return ["- None"]
        return [
            f"- {offer.job_id} | {offer.company} | {offer.title} | {offer.state.value} | {offer.match_score_pct or '-'}%"
            for offer in matching
        ]

    return (
        "# Pipeline\n\n"
        "## Inbox\n"
        + "\n".join(lines_for(pending_states))
        + "\n\n## In Progress\n"
        + "\n".join(lines_for(active_states))
        + "\n\n## Closed\n"
        + "\n".join(lines_for(closed_states))
        + "\n"
    )


def build_scan_history_tsv(offers: list[OfferRecord]) -> str:
    rows = ["job_id\tdiscovered_at\tcompany\ttitle\tboard\tposted_at_raw\tposted_age_hours\tsource_type\tliveness_status\tstate\tduplicate_group"]
    for offer in sorted(offers, key=lambda item: item.discovered_at):
        rows.append(
            f"{offer.job_id}\t{offer.discovered_at}\t{offer.company}\t{offer.title}\t"
            f"{offer.board_name or offer.source_type.value}\t{offer.posted_at_raw or ''}\t"
            f"{offer.posted_age_hours if offer.posted_age_hours is not None else ''}\t"
            f"{offer.source_type.value}\t{offer.liveness_status}\t{offer.state.value}\t{offer.duplicate_group_id or ''}"
        )
    return "\n".join(rows) + "\n"


def build_daily_summary(offers: list[OfferRecord]) -> str:
    counts = Counter(offer.state.value for offer in offers)
    fresh = len([offer for offer in offers if offer.posted_age_hours is not None and offer.posted_age_hours <= 24 and not offer.freshness_unknown])
    strong = len([offer for offer in offers if (offer.match_score_pct or 0) >= 70])
    lines = ["# Daily Summary", "", f"- fresh_24h: {fresh}", f"- strong_matches_70_plus: {strong}"]
    for state, count in sorted(counts.items()):
        lines.append(f"- {state}: {count}")
    if len(lines) == 4:
        lines.append("- no offers yet")
    return "\n".join(lines) + "\n"


def match_rankings_payload(offers: list[OfferRecord]) -> list[dict[str, object]]:
    payload: list[dict[str, object]] = []
    for offer in _sorted_offers(offers):
        payload.append(
            {
                "job_id": offer.job_id,
                "company": offer.company,
                "title": offer.title,
                "board": offer.board_name or offer.source_type.value,
                "location": offer.location,
                "work_mode": offer.work_mode,
                "posted_at_raw": offer.posted_at_raw,
                "posted_age_hours": offer.posted_age_hours,
                "match_score_pct": offer.match_score_pct,
                "recommendation": offer.recommendation.value if offer.recommendation else None,
                "sponsorship_note": offer.sponsorship_note,
                "matched_keywords": offer.matched_keywords,
                "missing_keywords": offer.missing_keywords,
                "source_url": offer.source_url,
                "duplicate_group_id": offer.duplicate_group_id,
            }
        )
    return payload


def build_match_rankings_json(offers: list[OfferRecord]) -> str:
    return json.dumps(match_rankings_payload(offers), indent=2)


def build_match_rankings_csv(offers: list[OfferRecord]) -> str:
    output = io.StringIO()
    writer = csv.DictWriter(
        output,
        fieldnames=[
            "job_id",
            "company",
            "title",
            "board",
            "location",
            "work_mode",
            "posted_at_raw",
            "posted_age_hours",
            "match_score_pct",
            "recommendation",
            "sponsorship_note",
            "matched_keywords",
            "missing_keywords",
            "source_url",
            "duplicate_group_id",
        ],
    )
    writer.writeheader()
    for row in match_rankings_payload(offers):
        row = dict(row)
        row["matched_keywords"] = ", ".join(row["matched_keywords"] or [])
        row["missing_keywords"] = ", ".join(row["missing_keywords"] or [])
        writer.writerow(row)
    return output.getvalue()


def build_threshold_matches_md(offers: list[OfferRecord], *, threshold: float = 70.0, fresh_only: bool = False) -> str:
    if fresh_only:
        title = "# Fresh Matches (24h)"
        filtered = [
            offer
            for offer in _sorted_offers(offers)
            if not offer.freshness_unknown and offer.posted_age_hours is not None and offer.posted_age_hours <= 24
        ]
    else:
        title = f"# Matches ({threshold:.0f}%+)"
        filtered = [offer for offer in _sorted_offers(offers) if (offer.match_score_pct or 0.0) >= threshold]

    lines = [title, ""]
    if not filtered:
        lines.append("- No matching jobs found.")
        return "\n".join(lines) + "\n"

    for offer in filtered:
        lines.append(
            f"- {offer.company} | {offer.title} | {offer.board_name or offer.source_type.value} | "
            f"{offer.match_score_pct or 0:.1f}% | {offer.posted_at_raw or 'unknown posted time'} | {offer.source_url}"
        )
    return "\n".join(lines) + "\n"
