"""Core engine package."""
