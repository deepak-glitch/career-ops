from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from job_search_command_center.engine.candidate import load_candidate
from job_search_command_center.engine.reports import resume_text
from job_search_command_center.engine.types import ArtifactKind, OfferRecord, ensure_parent


INVALID_WIN_CHARS = r'<>:"/\\|?*'


def _normalize_encoding(text: str) -> str:
    subs = {
        "â€“": "-",
        "â€”": "-",
        "â€™": "'",
        "â€œ": '"',
        "â€�": '"',
        "Â": "",
    }
    for k, v in subs.items():
        text = text.replace(k, v)
    return text


def _safe_dir_name(name: str) -> str:
    cleaned = _normalize_encoding(name)
    cleaned = "".join(" " if ch in INVALID_WIN_CHARS else ch for ch in cleaned).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = cleaned.rstrip(". ")
    return cleaned or "Unknown Company"


def _best_job_link(offer: OfferRecord) -> str:
    if offer.source_url.startswith("http://") or offer.source_url.startswith("https://"):
        return offer.source_url
    for line in offer.description.splitlines():
        lowered = line.lower().strip()
        if lowered.startswith("source url:"):
            candidate = line.split(":", 1)[1].strip()
            if candidate.startswith("http://") or candidate.startswith("https://"):
                return candidate
    return offer.source_url


def job_folder_for(root: Path, offer: OfferRecord) -> Path:
    return root / "jobs" / _safe_dir_name(offer.company) / offer.job_id


def export_job_folder(root: Path, offer: OfferRecord, *, force: bool = False) -> Path:
    """
    Export a human-facing job folder under `jobs/<Company>/<job_id>/`.

    Expected to be called after PDFs are built so the folder can include `resume.pdf`.
    """
    job_dir = job_folder_for(root, offer)
    job_dir.mkdir(parents=True, exist_ok=True)

    store_paths: dict[str, str] = {}
    for kind in (ArtifactKind.RESUME_PDF, ArtifactKind.COVER_LETTER_PDF, ArtifactKind.REPORT_MD, ArtifactKind.APPLY_PACK_MD, ArtifactKind.APPLY_PACK_JSON):
        ref = offer.artifact_manifest.get(kind)
        if ref:
            store_paths[kind.value] = ref.path

    def copy_artifact(kind: ArtifactKind, filename: str) -> None:
        ref = offer.artifact_manifest.get(kind)
        if not ref:
            return
        src = root / Path(ref.path)
        if not src.exists():
            return
        dest = job_dir / filename
        if dest.exists() and not force:
            return
        ensure_parent(dest)
        shutil.copyfile(src, dest)

    copy_artifact(ArtifactKind.RESUME_PDF, "resume.pdf")
    copy_artifact(ArtifactKind.COVER_LETTER_PDF, "cover-letter.pdf")
    copy_artifact(ArtifactKind.REPORT_MD, "report.md")
    copy_artifact(ArtifactKind.APPLY_PACK_MD, "apply-pack.md")
    copy_artifact(ArtifactKind.APPLY_PACK_JSON, "apply-pack.json")

    job_link = _best_job_link(offer)
    (job_dir / "job_link.txt").write_text(job_link + "\n", encoding="utf-8")
    (job_dir / "job_description.md").write_text(offer.description.strip() + "\n", encoding="utf-8")

    candidate = load_candidate(root)
    if offer.scorecard:
        rendered = resume_text(candidate, offer, offer.scorecard)
        (job_dir / "resume.txt").write_text(rendered, encoding="utf-8")

    candidacy = {
        "job_id": offer.job_id,
        "company": offer.company,
        "title": offer.title,
        "board": offer.board_name or offer.source_type.value,
        "location": offer.location,
        "work_mode": offer.work_mode,
        "source_url": offer.source_url,
        "job_link": job_link,
        "match_score_pct": offer.match_score_pct,
        "recommendation": offer.recommendation.value if offer.recommendation else None,
        "rationale": offer.scorecard.rationale if offer.scorecard else None,
        "red_flags": offer.scorecard.red_flags if offer.scorecard else [],
        "matched_keywords": offer.matched_keywords,
        "missing_keywords": offer.missing_keywords,
        "sponsorship_note": offer.sponsorship_note,
        "salary_text": offer.salary_text,
        "posted_at_raw": offer.posted_at_raw,
        "posted_age_hours": offer.posted_age_hours,
        "freshness_unknown": offer.freshness_unknown,
        "liveness_status": offer.liveness_status,
        "artifacts": store_paths,
    }
    (job_dir / "candidacy.json").write_text(json.dumps(candidacy, indent=2), encoding="utf-8")

    company = _normalize_encoding(offer.company)
    title = _normalize_encoding(offer.title)
    md_lines = [
        f"# {company} - {title}",
        "",
        f"- Job ID: `{offer.job_id}`",
        f"- Board: `{offer.board_name or offer.source_type.value}`",
        f"- Location: {offer.location}",
        f"- Work mode: {offer.work_mode or 'unknown'}",
        f"- Link: {job_link}",
        f"- Match: {offer.match_score_pct:.1f}%" if offer.match_score_pct is not None else "- Match: -",
        f"- Recommendation: `{offer.recommendation.value}`" if offer.recommendation else "- Recommendation: -",
        f"- Posted: {offer.posted_at_raw or offer.posted_at or 'unknown'}",
    ]
    if offer.sponsorship_note:
        md_lines.append(f"- Sponsorship note: {offer.sponsorship_note}")
    if offer.scorecard and offer.scorecard.red_flags:
        md_lines.extend(["", "## Flags"] + [f"- {flag}" for flag in offer.scorecard.red_flags])
    if offer.scorecard:
        md_lines.extend(["", "## Rationale", offer.scorecard.rationale])
    md_lines.extend(
        [
            "",
            "## Outputs",
            f"- `resume.pdf` (tailored) {'(missing)' if not (job_dir / 'resume.pdf').exists() else ''}",
            f"- `resume.txt` (ATS text) {'(missing)' if not (job_dir / 'resume.txt').exists() else ''}",
            "- `job_description.md` (saved JD text)",
            "- `candidacy.json` (scorecard + keywords)",
        ]
    )
    (job_dir / "details.md").write_text("\n".join(md_lines).strip() + "\n", encoding="utf-8")
    return job_dir
