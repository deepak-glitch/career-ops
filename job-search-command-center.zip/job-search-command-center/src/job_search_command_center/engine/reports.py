from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

from job_search_command_center.engine.types import ApplyPack, CandidateProfile, OfferRecord, Recommendation, Scorecard


def recommendation_label(recommendation: Recommendation) -> str:
    return recommendation.value.replace("_", " ").title()


def _normalize(text: str) -> str:
    return " ".join(text.lower().split())


def _offer_blob(offer: OfferRecord) -> str:
    return _normalize(" ".join([offer.title, offer.description, offer.location, offer.work_mode or "", offer.sponsorship_note or ""]))


def _company_slug(offer: OfferRecord) -> str:
    return _normalize(offer.company)


def _theme_tags(offer: OfferRecord) -> set[str]:
    blob = _offer_blob(offer)
    tags: set[str] = set()
    if any(term in blob for term in ["healthcare", "clinical", "patient", "hipaa", "health"]):
        tags.add("healthcare")
    if any(term in blob for term in ["llm", "large language", "generative", "prompt", "agent", "agentic"]):
        tags.add("llm")
    if any(term in blob for term in ["rag", "retrieval", "vector", "embedding", "semantic search"]):
        tags.add("rag")
    if any(term in blob for term in ["api", "docker", "deployment", "platform", "inference", "fastapi", "flask"]):
        tags.add("platform")
    if any(term in blob for term in ["evaluation", "guardrail", "observability", "reliability", "monitoring"]):
        tags.add("evaluation")
    if any(term in blob for term in ["computer vision", "yolo", "multimodal", "video", "image"]):
        tags.add("vision")
    if any(term in blob for term in ["startup", "product", "customer", "ownership", "0-1", "founding"]):
        tags.add("product")
    if any(term in blob for term in ["aws", "azure", "kubernetes", "cloud", "mlops", "llmops", "cicd", "ci/cd"]):
        tags.add("cloud")
    if not tags:
        tags.add("applied_ai")
    return tags


def render_report(candidate: CandidateProfile, offer: OfferRecord, scorecard: Scorecard) -> str:
    top_dimensions = "\n".join(
        f"- {dimension.label}: {dimension.score}/100 ({dimension.weight:.0%}) - {dimension.evidence}"
        for dimension in scorecard.dimensions
    )
    red_flags = "\n".join(f"- {flag}" for flag in scorecard.red_flags) or "- None"
    citations = "\n".join(f"- {citation}" for citation in candidate.source_citations)
    keywords = ", ".join(offer.matched_keywords[:12]) if offer.matched_keywords else "No high-signal keyword overlap extracted yet."
    return (
        f"# Offer Evaluation\n\n"
        f"**Company:** {offer.company}\n"
        f"**Title:** {offer.title}\n"
        f"**URL:** {offer.source_url}\n"
        f"**Recommendation:** {recommendation_label(scorecard.recommendation)}\n"
        f"**Match Score:** {scorecard.weighted_score}/100\n\n"
        f"## A. Role Summary\n"
        f"{offer.title} at {offer.company} is evaluated against the candidate's applied AI profile and local constraints.\n\n"
        f"## B. Match And Evidence\n"
        f"The strongest evidence comes from these local candidate sources:\n"
        f"{citations}\n\n"
        f"Matched keywords: {keywords}\n\n"
        f"## C. Level And Growth Strategy\n"
        f"The role is assessed for ownership, seniority fit, and room for expansion.\n\n"
        f"## D. Compensation And Logistics\n"
        f"Remote and compensation signals are folded into the weighted model without inventing missing numbers.\n\n"
        f"## E. Personalization And Company Fit\n"
        f"Candidate summary: {candidate.summary}\n\n"
        f"## F. Recommendation\n"
        f"{scorecard.rationale}\n\n"
        f"### Red Flags\n"
        f"{red_flags}\n\n"
        f"## Score Appendix\n"
        f"{top_dimensions}\n"
    )


def render_apply_pack_markdown(offer: OfferRecord, apply_pack: ApplyPack) -> str:
    checklist = "\n".join(f"- {item}" for item in apply_pack.checklist)
    answers = "\n".join(f"### {question}\n{answer}\n" for question, answer in apply_pack.answers.items())
    citations = "\n".join(f"- {item}" for item in apply_pack.source_citations)
    return (
        f"# Apply Pack\n\n"
        f"**Job ID:** {offer.job_id}\n"
        f"**Company:** {offer.company}\n"
        f"**Title:** {offer.title}\n\n"
        f"## Checklist\n"
        f"{checklist}\n\n"
        f"## Suggested Answers\n"
        f"{answers}\n"
        f"## Source Citations\n"
        f"{citations}\n"
    )


def _linkedin_display(candidate: CandidateProfile) -> str:
    linkedin = candidate.linkedin.strip()
    if not linkedin:
        return "Linkedin/Deepak Mallampati"
    if linkedin.startswith("http"):
        parsed = urlparse(linkedin)
        slug = parsed.path.strip("/").split("/")[-1].replace("-", " ").title()
        return f"Linkedin/{slug}"
    return linkedin


def _top_keywords(candidate: CandidateProfile, offer: OfferRecord) -> list[str]:
    preferred = list(dict.fromkeys((offer.matched_keywords or []) + candidate.core_skills + candidate.professional_keywords))
    return preferred[:14]


def _offer_has(offer: OfferRecord, *terms: str) -> bool:
    blob = _offer_blob(offer)
    return any(term in blob for term in terms)


def _ats_keywords(offer: OfferRecord) -> list[str]:
    keywords: list[str] = []

    def add(*items: str) -> None:
        for item in items:
            if item not in keywords:
                keywords.append(item)

    if _offer_has(offer, "python"):
        add("Python")
    if _offer_has(offer, "llm", "large language"):
        add("LLM Application Development")
    if _offer_has(offer, "nlp", "natural language processing"):
        add("NLP")
    if _offer_has(offer, "retrieval-augmented generation", "rag", "retrieval"):
        add("Retrieval-Augmented Generation", "Semantic Retrieval", "Embeddings")
    if _offer_has(offer, "agentic", "agent ", "agents", "multi-agent"):
        add("Agentic Workflows", "Multi-Agent Systems")
    if _offer_has(offer, "tool calling", "tool use"):
        add("Tool Calling")
    if _offer_has(offer, "structured outputs", "schema-aware outputs"):
        add("Structured Outputs")
    if _offer_has(offer, "evaluation", "observability", "guardrail", "monitoring"):
        add("Evaluation Pipelines", "Model Observability")
    if _offer_has(offer, "guardrail", "guardrails"):
        add("Guardrails")
    if _offer_has(offer, "healthcare", "clinical", "patient", "hipaa", "regulated"):
        add("Healthcare AI", "Regulated AI Workflows")
    if _offer_has(offer, "hipaa"):
        add("HIPAA-Conscious Delivery")
    if _offer_has(offer, "platform", "ai platform", "ai platforms"):
        add("AI Platforms")
    if _offer_has(offer, "cloud", "cloud deployment", "cloud-native"):
        add("Cloud Deployment")
    if _offer_has(offer, "mlops"):
        add("MLOps")
    if _offer_has(offer, "llmops"):
        add("LLMOps")
    if _offer_has(offer, "secure development", "security", "secure"):
        add("Secure Development")
    if _offer_has(offer, "responsible ai", "responsible deployment"):
        add("Responsible AI")
    if _offer_has(offer, "question answering", "reference-based search"):
        add("Question Answering")
    if _offer_has(offer, "data extraction"):
        add("Data Extraction")
    if _offer_has(offer, "process outcome prediction", "outcome prediction"):
        add("Process Outcome Prediction")
    if _offer_has(offer, "multimodal", "multi-modal", "model-powered bots", "bots and agents"):
        add("Multimodal AI", "Model-Powered Agents")
    if _offer_has(offer, "api", "restful", "fastapi", "flask"):
        add("RESTful APIs")
    if _offer_has(offer, "docker"):
        add("Docker")
    if _offer_has(offer, "langchain"):
        add("LangChain")
    if _offer_has(offer, "hugging face"):
        add("Hugging Face")
    if _offer_has(offer, "llamaindex"):
        add("LlamaIndex")
    if _offer_has(offer, "postgresql"):
        add("PostgreSQL")
    if _offer_has(offer, "react"):
        add("React")
    if _offer_has(offer, "typescript"):
        add("TypeScript")
    return keywords


def _offer_skill_targets(offer: OfferRecord) -> set[str]:
    blob = _offer_blob(offer)
    targets: set[str] = set()
    mapping = {
        "rag": ["rag", "retrieval", "semantic retrieval", "reference-based search", "question answering", "qa"],
        "llm": ["llm", "large language", "generative ai", "prompt engineering", "prompt"],
        "nlp": ["nlp", "natural language", "summarization", "speech-to-text", "transcript"],
        "agentic": ["agentic", "agent orchestration", "multi-agent", "bots and agents", "tool calling", "tool use"],
        "evaluation": ["evaluation", "experimentation", "model evaluation"],
        "observability": ["observability", "monitoring", "grafana"],
        "guardrails": ["guardrails", "grounding", "hallucination", "traceability"],
        "healthcare": ["healthcare", "clinical", "patient", "hipaa", "regulated", "compliance"],
        "prediction": ["prediction", "predictive", "outcome prediction"],
        "cloud": ["cloud", "cloud-native", "cloud deployment", "aws", "azure", "kubernetes"],
        "platform": ["platform", "ai platform", "ai platforms", "developer platform", "inference services"],
        "api": ["api", "apis", "restful", "integration", "integrations", "fastapi", "flask"],
        "mlops": ["mlops", "llmops", "ci/cd", "cicd", "deployment"],
        "secure": ["secure development", "security", "responsible ai", "responsible deployment"],
        "multimodal": ["multi-modal", "multimodal", "video", "image"],
        "automation": ["automation", "workflow orchestration", "orchestration", "process"],
        "product": ["product", "cross-functional", "ownership", "real-world impact"],
        "startup": ["startup", "fast-moving", "0-1"],
        "frontend": ["react", "typescript"],
        "data": ["postgresql", "sql", "data extraction"],
        "frameworks": ["langchain", "hugging face", "llamaindex", "transformers"],
    }
    for target, terms in mapping.items():
        if any(term in blob for term in terms):
            targets.add(target)
    return targets


def _tailored_summary(candidate: CandidateProfile, offer: OfferRecord) -> str:
    company = _company_slug(offer)
    if company == "pager health":
        return (
            "Applied AI engineer building healthcare LLM applications and retrieval-augmented generation (RAG) systems with agentic workflows, "
            "evaluation pipelines, guardrails, and observability. Delivers production APIs in Python (FastAPI/Flask) with Docker and cloud-ready "
            "deployment practices for reliable, measurable workflow impact."
        )
    if company == "acentra health":
        return (
            "AI engineer building healthcare and regulated-environment AI systems across NLP, retrieval-augmented generation (RAG), document question "
            "answering, and predictive modeling. Strong in production API delivery, cloud deployment, evaluation pipelines, AI platform integration, "
            "and responsible AI practices including secure, HIPAA-conscious delivery."
        )
    if company == "mlabs":
        return (
            "Applied AI engineer delivering end-to-end automation and AI product features across LLM applications, data extraction, summarization, "
            "question answering, process outcome prediction, and multimodal workflows. Strong hands-on Python delivery with experimentation, "
            "evaluation, API-first integration, and cross-functional execution."
        )

    tags = _theme_tags(offer)
    focus: list[str] = []
    if "llm" in tags:
        focus.append("LLM application development")
    if "rag" in tags:
        focus.append("retrieval-augmented generation (RAG)")
    if "evaluation" in tags:
        focus.append("evaluation pipelines, guardrails, and observability")
    if "vision" in tags:
        focus.append("multimodal and computer vision workflows")

    domain = "healthcare and regulated" if "healthcare" in tags else "applied AI"
    if not focus:
        focus = ["production machine learning and applied AI systems"]

    delivery: list[str] = ["Python", "FastAPI/Flask", "Docker"]
    if "cloud" in tags or "platform" in tags:
        delivery.extend(["cloud deployment", "RESTful APIs"])

    summary = (
        f"Applied AI engineer building {', '.join(focus[:3])} for {domain} use cases. "
        f"Delivers API-first systems with {', '.join(delivery[:4])} and a focus on ATS-friendly, measurable outcomes."
    )
    return summary


def _dedupe_preserve_order(items: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for item in items:
        cleaned = " ".join(item.split()).strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        deduped.append(cleaned)
    return deduped


def _format_skill_line(label: str, items: list[str]) -> str:
    cleaned = _dedupe_preserve_order(items)
    return f"{label}: {', '.join(cleaned)}"


def _skills_section(candidate: CandidateProfile, offer: OfferRecord) -> str:
    company = _company_slug(offer)
    if company == "pager health":
        return "\n".join(
            [
                "SKILLS",
                _format_skill_line("Programming Languages", ["Python", "SQL", "T-SQL", "C++"]),
                _format_skill_line("AI Frameworks", ["PyTorch", "scikit-learn", "XGBoost", "transformers"]),
                _format_skill_line(
                    "Machine Learning Techniques",
                    ["LLM Application Development", "Retrieval-Augmented Generation", "Semantic Retrieval", "Embeddings", "Prompt Engineering", "Model Evaluation", "Evaluation Pipelines"],
                ),
                _format_skill_line(
                    "AI Systems and Orchestration",
                    ["Agentic Workflows", "Agent Orchestration", "Structured Outputs", "Guardrails", "Model Observability", "Responsible AI", "Healthcare AI"],
                ),
                _format_skill_line(
                    "Data Processing and Deployment",
                    ["FastAPI", "Flask", "RESTful APIs", "Docker", "AWS", "Azure", "Kubernetes", "CI/CD", "Pandas", "NumPy"],
                ),
            ]
        )
    if company == "acentra health":
        return "\n".join(
            [
                "SKILLS",
                _format_skill_line("Programming Languages", ["Python", "SQL", "T-SQL", "C++"]),
                _format_skill_line("AI Frameworks", ["PyTorch", "scikit-learn", "XGBoost", "transformers"]),
                _format_skill_line(
                    "Machine Learning Techniques",
                    ["NLP", "LLM Application Development", "Retrieval-Augmented Generation", "Semantic Retrieval", "Embeddings", "Prompt Engineering", "Hyperparameter Tuning", "Model Evaluation"],
                ),
                _format_skill_line(
                    "AI Systems and Governance",
                    ["Healthcare AI", "HIPAA-Conscious Delivery", "AI Platforms", "Evaluation Pipelines", "Model Observability", "Responsible AI", "Secure Development"],
                ),
                _format_skill_line(
                    "Data Processing and Deployment",
                    ["FastAPI", "Flask", "RESTful APIs", "Docker", "Cloud Deployment", "AWS", "Azure", "Kubernetes", "MLOps", "LLMOps", "CI/CD", "Pandas", "NumPy"],
                ),
            ]
        )
    if company == "mlabs":
        return "\n".join(
            [
                "SKILLS",
                _format_skill_line("Programming Languages", ["Python", "SQL", "T-SQL", "C++", "TypeScript"]),
                _format_skill_line("AI Frameworks", ["PyTorch", "scikit-learn", "XGBoost", "transformers"]),
                _format_skill_line(
                    "Machine Learning Techniques",
                    ["LLM Application Development", "Data Extraction", "Summarization", "Question Answering", "Process Outcome Prediction", "Multimodal AI", "Experimentation", "Model Evaluation"],
                ),
                _format_skill_line(
                    "AI Systems and Product Delivery",
                    ["Agentic Workflows", "Model-Powered Agents", "Reference-Based Search", "Cross-Functional Product Delivery", "Strong Ownership", "Healthcare and Life Sciences AI"],
                ),
                _format_skill_line(
                    "Data Processing and Deployment",
                    ["FastAPI", "Flask", "RESTful APIs", "Docker", "Kubernetes", "PostgreSQL", "React", "CI/CD", "Pandas", "NumPy"],
                ),
            ]
        )
    tags = _theme_tags(offer)
    ats_keywords = _ats_keywords(offer)
    frameworks = ["TensorFlow", "PyTorch", "scikit-learn", "XGBoost"]
    if "llm" in tags or "rag" in tags:
        frameworks.append("transformers")
    if "vision" in tags:
        frameworks.append("YOLOv8")

    ml_techniques = ["Supervised Learning", "Classification", "Regression", "Hyperparameter Tuning", "Model Evaluation", "Cross-Validation"]
    if "llm" in tags:
        ml_techniques.extend(["Prompt Engineering", "LLM Application Development"])
    if "rag" in tags:
        ml_techniques.extend(["Retrieval-Augmented Generation", "Embeddings", "Semantic Retrieval"])
    if "vision" in tags:
        ml_techniques.extend(["Computer Vision", "Real-Time Inference"])

    deployment = ["Data Analysis", "Data Visualization", "Pandas", "NumPy", "Docker", "RESTful APIs", "CI/CD", "Agile Methodology"]
    if "cloud" in tags:
        deployment.extend(["AWS", "Azure", "Kubernetes"])
    if "platform" in tags:
        deployment.extend(["FastAPI", "Flask"])

    role_keywords: list[str] = []
    for keyword in ats_keywords:
        if keyword not in {"Python", "RESTful APIs", "Docker"}:
            role_keywords.append(keyword)

    return "\n".join(
        [
            "SKILLS",
            _format_skill_line("Programming Languages", ["Python", "SQL", "T-SQL", "C++"]),
            _format_skill_line("AI Frameworks", _dedupe_preserve_order(frameworks)),
            _format_skill_line("Machine Learning Techniques", _dedupe_preserve_order(ml_techniques)),
            _format_skill_line("Data Processing and Deployment", _dedupe_preserve_order(deployment)),
            _format_skill_line(
                "AI Systems and Domain Keywords",
                _dedupe_preserve_order(role_keywords) if role_keywords else ["Applied AI Systems", "Production AI Delivery"],
            ),
        ]
    )


def _scored_selection(items: list[tuple[str, set[str]]], targets: set[str], tags: set[str], limit: int) -> list[str]:
    scored = sorted(
        items,
        key=lambda item: (
            len(item[1] & targets),
            len(item[1] & tags),
            len(item[1]),
        ),
        reverse=True,
    )
    chosen: list[str] = []
    for text, _item_tags in scored:
        if text not in chosen:
            chosen.append(text)
        if len(chosen) >= limit:
            break
    return chosen


def _experience_sections(offer: OfferRecord) -> list[tuple[str, str, list[str]]]:
    company = _company_slug(offer)
    if company == "pager health":
        return [
            (
                "Jr. AI/ML Engineer Trainee, Progress Solutions Inc.",
                "Jul 2025 - Present | Remote",
                [
                    "Improved production AI workflows by tightening retrieval grounding, structured outputs, guardrails, observability, and evaluation feedback loops for healthcare-oriented document intelligence use cases.",
                    "Implemented Retrieval-Augmented Generation algorithms with Python to improve document retrieval precision by 35%, strengthening grounded AI responses and healthcare-oriented question answering workflows.",
                    "Packaged AI inference services into RESTful APIs with Python and Docker, enabling cloud-ready deployment and smoother platform integration while reducing deployment defects by 30%.",
                    "Analyzed model performance trends to reduce hallucination risk and cut erroneous outputs by over 30%, reinforcing responsible AI delivery in regulated healthcare workflows.",
                    "Collaborated with cross-functional partners to translate operational needs into production-ready AI services that improved predictive reliability by 15% across healthcare-focused workflows.",
                ],
            ),
            (
                "Database & DevOps Performance Engineer (Intern), Energy Solutions International (Emerson)",
                "Jun 2022 - Apr 2023 | Remote",
                [
                    "Automated CI/CD pipelines using Jenkins to streamline deployments, cut release cycle time by 35%, and reduce deployment errors by 30% across production workflows.",
                    "Monitored backend performance through Grafana dashboards, improving observability and helping reduce recurring incidents by 25%.",
                    "Partnered with developers on release reliability and backend performance tuning to improve production system stability under operational demand.",
                    "Optimized SQL queries on high-volume transactional pipelines, reducing execution time by 20% and improving system responsiveness.",
                ],
            ),
            (
                "Machine Learning Engineer, Suvidha Foundation",
                "Jan 2022 - Mar 2022 | Remote",
                [
                    "Deployed Flask-based RESTful APIs for AI summarization and highlight generation, reducing manual video editing time by 70% and improving workflow orchestration.",
                    "Constructed speech-to-text and transcript-processing pipelines with Python, improving summarization stability and downstream data quality for long-form media.",
                    "Supported model-driven content workflows that improved extraction quality and downstream usability for production-oriented AI features.",
                ],
            ),
        ]
    if company == "acentra health":
        return [
            (
                "Jr. AI/ML Engineer Trainee, Progress Solutions Inc.",
                "Jul 2025 - Present | Remote",
                [
                    "Implemented Retrieval-Augmented Generation workflows with Python to improve document retrieval precision by 35%, supporting grounded question answering, NLP-oriented processing, and healthcare-focused knowledge access.",
                    "Built production-ready AI services with FastAPI, Flask, Docker, and RESTful APIs, enabling cloud deployment, AI platform integration, and MLOps or LLMOps-aligned delivery patterns.",
                    "Improved production AI quality by tightening structured outputs, retrieval grounding, observability, and evaluation feedback loops across regulated document intelligence workflows.",
                    "Developed predictive machine learning models on operational datasets, improving predictive accuracy by 18% and strengthening process outcome prediction in regulated environments.",
                    "Supported secure, HIPAA-conscious AI workflow expectations through better traceability, grounding quality, and responsible AI execution in healthcare-oriented use cases.",
                ],
            ),
            (
                "Database & DevOps Performance Engineer (Intern), Energy Solutions International (Emerson)",
                "Jun 2022 - Apr 2023 | Remote",
                [
                    "Automated CI/CD pipelines using Jenkins to streamline schema deployments, reducing release cycle time by 35% and deployment errors by 30% across production systems.",
                    "Monitored backend performance with Grafana dashboards to improve observability and proactively reduce recurring incidents by 25%.",
                    "Partnered with developers on release reliability and backend performance tuning, helping enterprise systems scale more smoothly under high-volume demand.",
                    "Optimized SQL queries and stored procedures to improve data retrieval efficiency and reduce latency by up to 25% in enterprise reporting workflows.",
                ],
            ),
            (
                "Machine Learning Engineer, Suvidha Foundation",
                "Jan 2022 - Mar 2022 | Remote",
                [
                    "Built transcript-processing and speech-to-text pipelines with Python to improve NLP-oriented preprocessing, data extraction quality, and summarization stability for large video datasets.",
                    "Deployed Flask-based RESTful APIs for AI summarization workflows, improving integration readiness and reducing manual editing effort by 70%.",
                    "Implemented transformer-based summarization models that improved contextual continuity by 25% across long-form content processing tasks.",
                ],
            ),
        ]
    if company == "mlabs":
        return [
            (
                "Jr. AI/ML Engineer Trainee, Progress Solutions Inc.",
                "Jul 2025 - Present | Remote",
                [
                    "Implemented Retrieval-Augmented Generation workflows that improved document retrieval precision by 35%, strengthening reference-based search, question answering, and AI automation use cases.",
                    "Developed predictive machine learning models on operational datasets, improving predictive accuracy by 18% and supporting process outcome prediction in regulated environments.",
                    "Optimized machine learning models through hyperparameter tuning and evaluation, increasing recall by 20% and improving predictive stability across multi-source datasets.",
                    "Collaborated with cross-functional partners to translate business needs into production-ready AI services, improving operational prediction reliability by 15% across end-to-end automation workflows.",
                    "Improved production AI quality through structured outputs, evaluation feedback loops, and retrieval grounding for practical applied AI systems.",
                ],
            ),
            (
                "Database & DevOps Performance Engineer (Intern), Energy Solutions International (Emerson)",
                "Jun 2022 - Apr 2023 | Remote",
                [
                    "Optimized SQL queries and data retrieval workflows on high-volume pipelines, reducing execution time by 20% and improving backend responsiveness.",
                    "Automated CI/CD pipelines using Jenkins to streamline deployments, reducing release cycle time by 35% and deployment errors by 30%.",
                    "Monitored system performance with Grafana dashboards, improving observability and reducing recurring incidents by 25%.",
                    "Partnered with developers on backend reliability and performance tuning to improve production system stability under operational demand.",
                ],
            ),
            (
                "Machine Learning Engineer, Suvidha Foundation",
                "Jan 2022 - Mar 2022 | Remote",
                [
                    "Built transcript-processing pipelines that improved data extraction quality, summarization stability, and downstream usability for large video datasets.",
                    "Built multimodal AI workflows that combined transcript processing and highlight generation to accelerate content extraction, review, and model-powered automation.",
                    "Supported Python-based content workflows for summarization and highlight generation, reducing manual editing time by 70% and improving delivery speed.",
                ],
            ),
        ]
    tags = _theme_tags(offer)
    targets = _offer_skill_targets(offer)
    progress_bank = [
        ("Implemented Retrieval-Augmented Generation algorithms with Python and data analysis to enhance document retrieval precision by 35%, improving AI response relevance, reference-based search quality, and question answering performance in compliance-driven environments.", {"rag", "llm", "nlp", "healthcare", "automation"}),
        ("Analyzed model performance and data trends through scikit-learn and visualization tools, resolving hallucination risks and decreasing erroneous outputs by over 30% while reinforcing responsible AI evaluation, observability, and guardrail practices.", {"evaluation", "observability", "guardrails", "secure"}),
        ("Optimized machine learning models via hyperparameter tuning using scikit-learn, increasing recall by 20% and boosting predictive stability across multi-source clinical datasets.", {"healthcare", "evaluation", "prediction"}),
        ("Packaged AI inference systems into RESTful APIs with Python and Docker, supporting cloud deployment, AI platform integration, API integrations, and MLOps or LLMOps-oriented production delivery while reducing deployment defects by 30%.", {"platform", "cloud", "api", "mlops"}),
        ("Developed AI models using Python and machine learning to analyze operational datasets, collaborating with teams to improve predictive accuracy by 18% in regulated data workflows and strengthen process outcome prediction.", {"healthcare", "prediction", "product", "automation"}),
        ("Supported HIPAA-conscious, secure development expectations in regulated AI workflows by improving traceability, grounding quality, and operational reliability across healthcare-focused use cases.", {"healthcare", "secure", "guardrails"}),
        ("Improved production AI workflows by tightening retrieval grounding, structured outputs, guardrails, observability, and evaluation feedback loops for healthcare-oriented document intelligence use cases.", {"rag", "evaluation", "platform", "automation", "guardrails", "observability"}),
        ("Collaborated with cross-functional partners to translate business requirements into production-ready AI services, improving operational prediction reliability by 15% across regulated workflows and end-to-end AI automation efforts.", {"product", "platform", "prediction", "automation"}),
    ]
    emerson_bank = [
        ("Automated CI/CD pipelines using Jenkins to streamline database schema deployments, cutting release cycle time by 35% and reducing deployment errors by 30% across production platform workflows.", {"mlops", "platform", "cloud"}),
        ("Monitored database performance with Grafana dashboards and data analysis, proactively identifying bottlenecks that decreased incident recurrence by 25% and improved observability for engineering teams.", {"observability", "platform", "evaluation"}),
        ("Optimized SQL queries and applied query optimization techniques in collaboration with developers, reducing execution time by 20% on high-volume transactional pipelines.", {"platform", "data", "product"}),
        ("Refined T-SQL stored procedures to improve data retrieval efficiency, decreasing latency by 25% during critical financial reconciliation processes.", {"platform", "data"}),
        ("Partnered with developers on release reliability and backend performance tuning, helping production systems scale more smoothly under high-volume operational demand.", {"platform", "cloud", "product"}),
    ]
    suvidha_bank = [
        ("Constructed speech-to-text transcript pipelines with Python, collaborating to reduce irrelevant token density by 30%, improving summarization stability and data extraction quality for large video datasets.", {"llm", "nlp", "multimodal", "data"}),
        ("Implemented transformer-based models in Python for abstractive summarization, achieving 25% better contextual continuity in long-form content processing.", {"llm", "nlp", "frameworks"}),
        ("Deployed Flask-based RESTful APIs to integrate AI summarization and video highlight generation, reducing manual video editing time by 70% for outreach teams and improving workflow orchestration.", {"platform", "api", "nlp", "automation"}),
        ("Built video-focused multimodal AI workflows that combined transcript processing and highlight generation to accelerate content extraction and review through model-powered automation.", {"multimodal", "automation", "nlp", "data"}),
        ("Supported model-driven content workflows with Python-based processing pipelines that improved extraction quality and downstream usability for long-form media.", {"automation", "data", "product"}),
    ]
    return [
        (
            "Jr. AI/ML Engineer Trainee, Progress Solutions Inc.",
            "Jul 2025 - Present | Remote",
            _scored_selection(progress_bank, targets, tags, 5),
        ),
        (
            "Database & DevOps Performance Engineer (Intern), Energy Solutions International (Emerson)",
            "Jun 2022 - Apr 2023 | Remote",
            _scored_selection(emerson_bank, targets, tags, 4),
        ),
        (
            "Machine Learning Engineer, Suvidha Foundation",
            "Jan 2022 - Mar 2022 | Remote",
            _scored_selection(suvidha_bank, targets, tags, 3),
        ),
    ]


def _projects_section(offer: OfferRecord) -> str:
    company = _company_slug(offer)
    if company == "pager health":
        return "\n".join(
            [
                "PROJECTS",
                "Document Question Answering and Retrieval Workflow",
                "- Implemented document question answering and retrieval workflows to improve grounded answers, semantic retrieval quality, and hallucination reduction for healthcare-oriented information access.",
                "- Used embeddings, reference-based search, and retrieval-augmented generation patterns to support practical question answering over internal content.",
                "Dream Decoder - AI-Powered Multimodal Creative Intelligence Platform",
                "- Applied agentic workflow design patterns to coordinate prompt engineering, output refinement, and production-style AI feature delivery.",
                "- Orchestrated layered prompt transformation, structured outputs, and evaluation-aware refinement to improve end-to-end workflow quality.",
                "Agentic Pixel Character Synthesis & Animation Engine",
                "- Architected a modular FastAPI and Docker backend to support scalable generation workflows, API delivery, and production-style orchestration.",
                "- Structured the system around agentic workflow steps for controlled generation, iterative refinement, and reliable AI feature execution.",
            ]
        )
    if company == "acentra health":
        return "\n".join(
            [
                "PROJECTS",
                "Document Question Answering and Retrieval Workflow",
                "- Implemented document question answering and retrieval workflows to improve grounded answers, semantic retrieval quality, and hallucination reduction in healthcare-oriented content access scenarios.",
                "- Used embeddings, reference-based search, and retrieval-augmented generation patterns to support practical question answering over internal content.",
                "Video Summarization and Highlight Generation System",
                "- Built a transformer-based summarization workflow using transcript processing, timestamp alignment, and automated clip extraction for long-form video content.",
                "- Improved transcript quality, NLP-oriented preprocessing, and evaluation-aware refinement to strengthen downstream summarization reliability.",
                "Dream Decoder - AI-Powered Multimodal Creative Intelligence Platform",
                "- Developed a structured AI pipeline with Python and FastAPI to interpret user input and generate multimodal outputs with production-style orchestration.",
                "- Improved workflow quality through structured outputs, layered prompt transformation, and practical API-based AI delivery patterns.",
            ]
        )
    if company == "mlabs":
        return "\n".join(
            [
                "PROJECTS",
                "Dream Decoder - AI-Powered Multimodal Creative Intelligence Platform",
                "- Built a structured AI pipeline with Python and FastAPI to generate multimodal outputs from user input and support model-powered automation workflows.",
                "- Applied agentic workflow design patterns to coordinate prompt transformation, output refinement, and practical AI feature delivery.",
                "Video Summarization and Highlight Generation System",
                "- Built a transformer-based summarization workflow using transcript processing, timestamp alignment, and automated clip extraction for long-form video content.",
                "- Improved data extraction quality, summarization stability, and downstream usability through NLP-oriented preprocessing and evaluation-aware refinement.",
                "Document Question Answering and Retrieval Workflow",
                "- Used embeddings, reference-based search, and retrieval-augmented generation patterns to support practical question answering over internal content.",
                "- Improved grounded answer quality and retrieval relevance for production-style AI automation use cases.",
            ]
        )
    tags = _theme_tags(offer)
    targets = _offer_skill_targets(offer)
    project_bank = [
        (
            "Agentic Pixel Character Synthesis & Animation Engine",
            [
                ("Designed an identity-consistent pixel character synthesis system using Python and PyTorch, combining generative modeling with controllable sprite and pose outputs.", {"llm", "vision", "multimodal"}),
                ("Architected a modular FastAPI and Docker backend to support scalable generation workflows, API delivery, and production-style orchestration.", {"platform", "api", "cloud", "automation"}),
                ("Structured the system around agentic workflow steps for prompt transformation, controlled generation, and iterative refinement of visual outputs.", {"agentic", "automation", "llm"}),
            ],
        ),
        (
            "Dream Decoder - AI-Powered Multimodal Creative Intelligence Platform",
            [
                ("Developed a structured AI pipeline with Python and FastAPI to interpret user input and generate multimodal creative outputs.", {"platform", "api", "llm", "multimodal"}),
                ("Orchestrated layered prompt transformation and data analysis to improve multimodal output alignment, structured outputs, and workflow quality.", {"llm", "multimodal", "automation", "evaluation"}),
                ("Applied agentic workflow design patterns to coordinate prompt engineering, output refinement, and production-style AI feature delivery.", {"agentic", "automation", "llm", "product"}),
            ],
        ),
        (
            "Driver Drowsiness Detection System - Real-Time YOLOv8-Based Fatigue Monitoring",
            [
                ("Implemented a real-time driver state detection system using Python and YOLOv8 to classify drowsiness from facial features and live video inputs.", {"vision", "multimodal", "prediction"}),
                ("Optimized the inference pipeline with OpenCV-based analysis to reduce false alerts and improve detection reliability in real-time conditions.", {"vision", "evaluation", "prediction"}),
                ("Packaged computer vision inference logic into a practical ML workflow emphasizing robustness, operational usability, and performance monitoring.", {"vision", "platform", "evaluation"}),
            ],
        ),
        (
            "Video Summarization and Highlight Generation System",
            [
                ("Built a transformer-based summarization workflow using transcript processing, timestamp alignment, and automated clip extraction for long-form video content.", {"llm", "nlp", "multimodal", "automation"}),
                ("Integrated RESTful API endpoints for summarization and highlight generation, reducing manual editing effort and improving delivery speed.", {"platform", "api", "automation"}),
                ("Improved transcript quality and downstream summarization reliability through speech-to-text cleanup, NLP-oriented preprocessing, and evaluation-aware refinement.", {"nlp", "evaluation", "data"}),
            ],
        ),
        (
            "Document Question Answering and Retrieval Workflow",
            [
                ("Implemented document question answering and retrieval workflows to improve grounded answers, semantic retrieval quality, and hallucination reduction.", {"rag", "llm", "evaluation", "guardrails"}),
                ("Used embeddings, reference-based search, and retrieval-augmented generation patterns to support practical question answering over internal content.", {"rag", "llm", "data", "automation"}),
                ("Focused on grounded outputs, evaluation feedback loops, and production-oriented workflow design for reliable AI-assisted information access.", {"evaluation", "guardrails", "platform"}),
            ],
        ),
    ]
    scored_projects: list[tuple[int, int, int, str, list[str]]] = []
    for title, bullets in project_bank:
        chosen = _scored_selection(bullets, targets, tags, 2)
        if not chosen:
            continue
        bullet_tags = [item_tags for bullet_text, item_tags in bullets if bullet_text in chosen]
        target_score = sum(len(item_tags & targets) for item_tags in bullet_tags)
        tag_score = sum(len(item_tags & tags) for item_tags in bullet_tags)
        richness = sum(len(item_tags) for item_tags in bullet_tags)
        scored_projects.append((target_score, tag_score, richness, title, chosen))

    scored_projects.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)

    lines: list[str] = ["PROJECTS"]
    for _target_score, _tag_score, _richness, title, chosen in scored_projects[:3]:
        lines.append(title)
        for bullet in chosen:
            lines.append(f"- {bullet}")
    return "\n".join(lines)


def _education_and_certifications() -> str:
    certs = [
        "Developing AI Applications with Python and Flask",
        "Introduction to Containers w/ Docker, Kubernetes & OpenShift",
        "Continuous Integration and Continuous Delivery (CI/CD)",
        "Monitoring and Observability for Development and DevOps",
        "Machine Learning with Python",
    ]
    return (
        "EDUCATION\n"
        "Masters, Kent State University(CGPA: 3.73)\n"
        "Aug 2023 - May 2025 | OH, US\n\n"
        "CERTIFICATIONS\n"
        + "\n".join(f"- {cert}" for cert in certs)
    )


def resume_text(candidate: CandidateProfile, offer: OfferRecord, scorecard: Scorecard) -> str:
    linkedin = _linkedin_display(candidate)
    phone = candidate.phone or "3305540770"
    lines = [
        f"# {candidate.name}",
        f"{phone}\t{candidate.email}  {linkedin}",
        offer.title,
        _tailored_summary(candidate, offer),
        "",
        _skills_section(candidate, offer),
        "",
        "PROFESSIONAL EXPERIENCE",
    ]
    for heading, meta, bullets in _experience_sections(offer):
        lines.append(heading)
        lines.append(meta)
        for bullet in bullets:
            lines.append(f"- {bullet}")
        lines.append("")
    lines.append(_projects_section(offer))
    lines.append("")
    lines.append(_education_and_certifications())
    return _final_pass_resume_text("\n".join(lines).strip() + "\n")


def _final_pass_resume_text(text: str) -> str:
    """
    Final-pass polish pass for resumes after the latest jobs are searched.

    Goals:
    - keep truthfulness and ATS-friendly single-column structure
    - make summary/skills/bullets read hand-edited (spacing, punctuation, redundancy)
    - avoid breaking the section parser in adapters/render/pdf.py
    """
    raw_lines = [line.rstrip() for line in text.splitlines()]
    if not raw_lines:
        return text

    polished: list[str] = []
    current_section = ""
    saw_section = False
    for index, line in enumerate(raw_lines):
        if not line:
            polished.append("")
            continue

        if line.isupper() and len(line) <= 40:
            current_section = line
            saw_section = True
            polished.append(line)
            continue

        # Summary block: between role line and the first SECTION heading.
        if not saw_section and index >= 3:
            cleaned = " ".join(line.split())
            cleaned = cleaned.replace("Experienced AI engineer", "Applied AI engineer")
            polished.append(cleaned)
            continue

        if current_section == "SKILLS" and ":" in line:
            label, rest = line.split(":", 1)
            cleaned = f"{label.strip()}: {' '.join(rest.split()).strip()}"
            cleaned = cleaned.rstrip(".")
            polished.append(cleaned)
            continue

        if line.startswith("- "):
            cleaned = " ".join(line.split())
            polished.append(cleaned)
            continue

        polished.append(" ".join(line.split()))

    return "\n".join(polished).strip() + "\n"


def cover_letter_text(candidate: CandidateProfile, offer: OfferRecord, scorecard: Scorecard) -> str:
    return (
        f"Dear {offer.company} team,\n\n"
        f"I am excited about the {offer.title} role because it aligns with my background in applied AI systems, workflow automation, "
        f"and shipping user-facing tooling. The evaluation for this role came in at {scorecard.weighted_score}/100, driven by overlap in "
        f"ownership expectations, Python-based delivery, and product-minded collaboration.\n\n"
        f"My recent work centers on building practical AI systems that reduce manual effort, improve quality, and move quickly from "
        f"prototype to production. I would bring that same execution bias to {offer.company}.\n\n"
        f"Sincerely,\n{candidate.name}\n"
    )


def relative_path_text(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()
