from __future__ import annotations

import hashlib
import re


def normalize_text(value: str) -> str:
    lowered = value.strip().lower()
    lowered = re.sub(r"[^a-z0-9]+", "-", lowered)
    return re.sub(r"-+", "-", lowered).strip("-")


def content_fingerprint(*parts: str) -> str:
    joined = "\n".join(part.strip() for part in parts if part)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:16]


def job_id_for(company: str, title: str, source_url: str, description: str) -> str:
    company_slug = normalize_text(company)[:24]
    title_slug = normalize_text(title)[:32]
    fingerprint = content_fingerprint(company, title, source_url, description)
    return f"{company_slug}-{title_slug}-{fingerprint}"
