from __future__ import annotations

import json
from pathlib import Path

from job_search_command_center.engine.types import CandidateProfile


DEFAULT_EXPANDED_TITLES = [
    "AI Engineer",
    "Applied AI Engineer",
    "Agentic AI Engineer",
    "Generative AI Engineer",
    "LLM Engineer",
    "RAG Engineer",
    "Machine Learning Engineer",
    "AI Solutions Engineer",
    "AI Platform Engineer",
    "AI Software Engineer",
    "Computer Vision Engineer",
    "Multimodal AI Engineer",
]

DEFAULT_PROFESSIONAL_KEYWORDS = [
    "LLM application development",
    "large language models",
    "retrieval-augmented generation",
    "agentic workflows",
    "multi-agent systems",
    "tool use",
    "structured outputs",
    "prompt engineering",
    "evaluation pipelines",
    "model observability",
    "guardrails",
    "responsible AI",
    "vector search",
    "embeddings",
    "semantic retrieval",
    "inference services",
    "production deployment",
    "cloud-native AI",
    "MLOps",
    "FastAPI",
    "Flask",
    "Docker",
    "Kubernetes",
    "AWS",
    "Azure",
    "SageMaker",
    "Python",
    "transformers",
    "computer vision",
]


def _read_optional_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_candidate(root: Path) -> CandidateProfile:
    config_dir = root / "config"
    profile_path = config_dir / "candidate_profile.json"
    resume_path = config_dir / "resume_facts.md"
    proof_path = config_dir / "proof_bank.md"
    search_path = config_dir / "search_preferences.json"

    profile_data = json.loads(profile_path.read_text(encoding="utf-8"))
    resume_facts = resume_path.read_text(encoding="utf-8").strip()
    proof_bank = proof_path.read_text(encoding="utf-8").strip()
    search_data = _read_optional_json(search_path)

    target_roles = [str(item) for item in profile_data.get("target_roles", [])]
    preferred_domains = [str(item) for item in profile_data.get("preferred_domains", profile_data.get("domains", []))]
    preferred_work_modes = [str(item) for item in profile_data.get("preferred_work_modes", [])]
    target_role_seeds = [str(item) for item in profile_data.get("target_role_seeds", target_roles)]
    expanded_target_roles = [str(item) for item in profile_data.get("expanded_target_roles", DEFAULT_EXPANDED_TITLES)]
    professional_keywords = [str(item) for item in profile_data.get("professional_keywords", DEFAULT_PROFESSIONAL_KEYWORDS)]
    search_phrases = [str(item) for item in search_data.get("search_phrases", profile_data.get("search_phrases", []))]
    if not search_phrases:
        search_phrases = [f"{title} {keyword}" for title in expanded_target_roles[:6] for keyword in professional_keywords[:4]][:12]

    return CandidateProfile(
        name=str(profile_data["name"]),
        email=str(profile_data["email"]),
        target_roles=target_roles,
        preferred_domains=preferred_domains,
        work_authorization=str(profile_data.get("work_authorization", "")),
        remote_only=bool(profile_data.get("remote_only", False)),
        compensation_floor_usd=int(profile_data.get("compensation_floor_usd", profile_data.get("salary_min_usd", 0))),
        summary=str(profile_data["summary"]),
        resume_facts=resume_facts,
        proof_bank=proof_bank,
        source_citations=[
            profile_path.relative_to(root).as_posix(),
            resume_path.relative_to(root).as_posix(),
            proof_path.relative_to(root).as_posix(),
        ]
        + ([search_path.relative_to(root).as_posix()] if search_path.exists() else []),
        linkedin=str(profile_data.get("linkedin", "")),
        phone=str(profile_data.get("phone", "")),
        current_location=str(profile_data.get("current_location", "")),
        preferred_work_modes=preferred_work_modes,
        open_to_relocation=bool(profile_data.get("open_to_relocation", False)),
        salary_min_usd=int(profile_data.get("salary_min_usd", profile_data.get("compensation_floor_usd", 0))),
        salary_max_usd=int(profile_data.get("salary_max_usd", 0)),
        work_auth_now=str(profile_data.get("work_auth_now", "")),
        requires_future_sponsorship=bool(profile_data.get("requires_future_sponsorship", False)),
        years_experience=float(profile_data.get("years_experience", 0.0)),
        industries=[str(item) for item in profile_data.get("industries", [])],
        core_skills=[str(item) for item in profile_data.get("core_skills", [])],
        domains=[str(item) for item in profile_data.get("domains", preferred_domains)],
        target_role_seeds=target_role_seeds,
        expanded_target_roles=expanded_target_roles,
        professional_keywords=professional_keywords,
        search_phrases=search_phrases,
    )
