from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path

from job_search_command_center.adapters.agents.base import AgentAdapter
from job_search_command_center.adapters.agents.codex import CodexAgentAdapter
from job_search_command_center.adapters.agents.mock import MockAgentAdapter
from job_search_command_center.adapters.portals.ashby import AshbyAdapter
from job_search_command_center.adapters.portals.base import PortalAdapter
from job_search_command_center.adapters.portals.common import canonicalize_url, keyword_overlap
from job_search_command_center.adapters.portals.dice import DiceAdapter
from job_search_command_center.adapters.portals.generic import GenericPortalAdapter
from job_search_command_center.adapters.portals.greenhouse import GreenhouseAdapter
from job_search_command_center.adapters.portals.indeed import IndeedAdapter
from job_search_command_center.adapters.portals.lever import LeverAdapter
from job_search_command_center.adapters.portals.linkedin import LinkedInAdapter
from job_search_command_center.adapters.render.pdf import build_resume_pdf, build_text_pdf
from job_search_command_center.engine.candidate import load_candidate
from job_search_command_center.engine.job_folders import export_job_folder
from job_search_command_center.engine.ids import content_fingerprint, job_id_for, normalize_text
from job_search_command_center.engine.profile_import import import_profile, write_imported_profile
from job_search_command_center.engine.reports import relative_path_text, render_apply_pack_markdown
from job_search_command_center.engine.scoring import ScoreContext
from job_search_command_center.engine.store import FileStore
from job_search_command_center.engine.types import (
    ApplyPack,
    ArtifactKind,
    EventType,
    OfferRecord,
    OfferState,
    PortalResult,
    Recommendation,
    SourceType,
    ValidationError,
    dataclass_to_dict,
    utc_now,
)


PORTAL_ADAPTERS: dict[str, PortalAdapter] = {
    "greenhouse": GreenhouseAdapter(),
    "ashby": AshbyAdapter(),
    "lever": LeverAdapter(),
    "linkedin": LinkedInAdapter(),
    "indeed": IndeedAdapter(),
    "dice": DiceAdapter(),
    "generic": GenericPortalAdapter(),
}

AGENT_ADAPTERS: dict[str, AgentAdapter] = {
    "codex": CodexAgentAdapter(),
    "mock": MockAgentAdapter(),
}


@dataclass(slots=True)
class ScanSummary:
    discovered: int
    verified: int
    duplicates: int
    expired: int


@dataclass(slots=True)
class BatchSummary:
    run_id: str
    completed: list[str]
    failed: dict[str, str]
    skipped: list[str]


@dataclass(slots=True)
class ProfileImportSummary:
    candidate_profile_path: str
    search_preferences_path: str
    suggested_titles_path: str
    suggested_titles: list[str]


@dataclass(slots=True)
class SearchSummary:
    boards: list[str]
    discovered: int
    unique: int
    fresh_matches: int
    strong_matches: int
    tracker_path: str


@dataclass(slots=True)
class JobsExportSummary:
    exported: list[str]
    skipped: list[str]
    jobs_root: str


def _adapter_for_portal(name: str) -> PortalAdapter:
    try:
        return PORTAL_ADAPTERS[name]
    except KeyError as exc:
        raise ValidationError(f"unsupported portal: {name}") from exc


def _agent_for(name: str) -> AgentAdapter:
    try:
        return AGENT_ADAPTERS[name]
    except KeyError as exc:
        raise ValidationError(f"unsupported agent: {name}") from exc


def _read_search_preferences(root: Path) -> dict:
    path = root / "config" / "search_preferences.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _offer_from_result(result: PortalResult) -> OfferRecord:
    is_fresh = not result.freshness_unknown and result.posted_age_hours is not None and result.posted_age_hours <= 24
    state = OfferState.VERIFIED if result.liveness_status == "active" and is_fresh else OfferState.DISCOVERED
    verified_at = utc_now() if state == OfferState.VERIFIED else None
    return OfferRecord(
        schema_version="2.0",
        job_id=job_id_for(result.company, result.title, result.source_url, result.description),
        company=result.company,
        title=result.title,
        source_url=canonicalize_url(result.source_url),
        source_type=result.source_type,
        location=result.location,
        employment_type=result.employment_type,
        state=state,
        description=result.description,
        content_fingerprint=result.content_fingerprint,
        discovered_at=result.discovered_at,
        verified_at=verified_at,
        last_updated_at=utc_now(),
        posted_at=result.posted_at,
        discovery_method=result.discovery_method,
        liveness_status=result.liveness_status,
        match_score_pct=None,
        work_mode=result.work_mode,
        salary_text=result.salary_text,
        sponsorship_note=result.sponsorship_text,
        matched_keywords=list(result.matched_keywords),
        missing_keywords=list(result.missing_keywords),
        board_name=result.board_name,
        search_query=result.search_query,
        posted_at_raw=result.posted_at_raw,
        posted_age_hours=result.posted_age_hours,
        freshness_unknown=result.freshness_unknown,
        duplicate_group_id=result.duplicate_group_id,
    )


def _duplicate_group_for(existing: list[OfferRecord], candidate: OfferRecord) -> str | None:
    candidate_signature = (
        normalize_text(candidate.company),
        normalize_text(candidate.title),
        normalize_text(candidate.location),
        candidate.posted_at_raw or candidate.posted_at or "",
    )
    candidate_desc_signature = normalize_text(" ".join(candidate.description.split()[:30]))
    for offer in existing:
        if canonicalize_url(offer.source_url) == canonicalize_url(candidate.source_url):
            return offer.duplicate_group_id or offer.job_id
        offer_signature = (
            normalize_text(offer.company),
            normalize_text(offer.title),
            normalize_text(offer.location),
            offer.posted_at_raw or offer.posted_at or "",
        )
        if candidate_signature == offer_signature:
            return offer.duplicate_group_id or offer.job_id
        offer_desc_signature = normalize_text(" ".join(offer.description.split()[:30]))
        if offer_signature[:2] == candidate_signature[:2] and offer_desc_signature == candidate_desc_signature:
            return offer.duplicate_group_id or offer.job_id
    return None


def _best_search_query(title: str, description: str, search_phrases: list[str]) -> str | None:
    blob = f"{title}\n{description}"
    best_phrase = None
    best_score = -1
    for phrase in search_phrases:
        matched, _missing = keyword_overlap(blob, [item for item in phrase.split() if item.strip()])
        if len(matched) > best_score:
            best_score = len(matched)
            best_phrase = phrase
    return best_phrase


def scan_source(root: Path, source: str, portal: str) -> ScanSummary:
    store = FileStore(root)
    adapter = _adapter_for_portal(portal)
    existing = store.list_offers()
    results = adapter.fetch(source)

    discovered = verified = duplicates = expired = 0
    for result in results:
        offer = _offer_from_result(result)
        duplicate_group = _duplicate_group_for(existing, offer)
        if duplicate_group:
            duplicates += 1
            continue
        store.save_offer(offer)
        store.append_event(offer.job_id, EventType.DISCOVERED, {"source": source, "portal": portal, "liveness_status": offer.liveness_status})
        discovered += 1
        existing.append(offer)
        if offer.state == OfferState.VERIFIED:
            verified += 1
            store.append_event(offer.job_id, EventType.VERIFIED, {"verified_at": offer.verified_at})
        else:
            expired += 1
    store.rebuild_projections()
    return ScanSummary(discovered=discovered, verified=verified, duplicates=duplicates, expired=expired)


def import_candidate_profile(root: Path, resume_docx: str, personal_docx: str) -> ProfileImportSummary:
    imported = import_profile(root, resume_docx, personal_docx)
    write_imported_profile(root, imported)
    store = FileStore(root)
    return ProfileImportSummary(
        candidate_profile_path=relative_path_text(root, root / "config" / "candidate_profile.json"),
        search_preferences_path=relative_path_text(root, root / "config" / "search_preferences.json"),
        suggested_titles_path=relative_path_text(root, store.suggested_titles_path),
        suggested_titles=imported.suggested_titles,
    )


def suggested_titles(root: Path) -> list[str]:
    generated_path = root / "data" / "generated" / "suggested_titles.json"
    if generated_path.exists():
        return [str(item) for item in json.loads(generated_path.read_text(encoding="utf-8"))]
    candidate = load_candidate(root)
    return list(candidate.expanded_target_roles or candidate.target_roles)


def _ingest_target_if_needed(root: Path, target: str) -> OfferRecord:
    store = FileStore(root)
    if store.offer_path(target).exists():
        return store.load_offer(target)
    target_path = Path(target)
    if target_path.exists():
        result = GenericPortalAdapter().fetch(str(target_path))[0]
    elif target.startswith("http://") or target.startswith("https://"):
        result = GenericPortalAdapter().fetch(target)[0]
    else:
        return store.ensure_offer_exists(target)
    offer = _offer_from_result(result)
    existing = store.list_offers()
    duplicate_group = _duplicate_group_for(existing, offer)
    if not duplicate_group:
        store.save_offer(offer)
        store.append_event(offer.job_id, EventType.DISCOVERED, {"source": target, "portal": offer.source_type.value})
        if offer.state == OfferState.VERIFIED:
            store.append_event(offer.job_id, EventType.VERIFIED, {"verified_at": offer.verified_at})
        store.rebuild_projections()
    return store.load_offer(offer.job_id)


def evaluate_offer(root: Path, target: str, agent_name: str = "codex") -> OfferRecord:
    store = FileStore(root)
    candidate = load_candidate(root)
    offer = _ingest_target_if_needed(root, target)
    agent = _agent_for(agent_name)
    worker_result = agent.evaluate_offer(candidate, offer)
    offer.scorecard = worker_result.scorecard
    offer.match_score_pct = worker_result.scorecard.weighted_score
    offer.recommendation = worker_result.recommendation
    offer.source_citations = worker_result.source_citations
    offer.state = OfferState.EVALUATED
    offer.last_updated_at = utc_now()
    report_artifact = store.save_text_artifact(offer.job_id, "report", ArtifactKind.REPORT_MD, worker_result.report_body, "md")
    store.update_offer_artifacts(offer, [report_artifact])
    store.save_offer(offer)
    store.append_event(offer.job_id, EventType.EVALUATED, {"recommendation": offer.recommendation.value, "score": offer.scorecard.weighted_score})
    store.rebuild_projections()
    return offer


def build_pdf_artifacts(root: Path, job_id: str, agent_name: str = "codex", include_cover_letter: bool = True) -> OfferRecord:
    store = FileStore(root)
    candidate = load_candidate(root)
    offer = store.ensure_offer_exists(job_id)
    if not offer.scorecard:
        offer = evaluate_offer(root, job_id, agent_name)
    agent = _agent_for(agent_name)
    pdf_inputs = agent.generate_pdf_inputs(candidate, offer)
    artifacts = [
        store.save_binary_artifact(
            offer.job_id,
            "resume",
            ArtifactKind.RESUME_PDF,
            build_resume_pdf(pdf_inputs["resume"], title=f"{offer.company} Resume"),
            "pdf",
        )
    ]
    if include_cover_letter:
        artifacts.append(
            store.save_binary_artifact(
                offer.job_id,
                "cover-letter",
                ArtifactKind.COVER_LETTER_PDF,
                build_text_pdf(pdf_inputs["cover_letter"], title=f"{offer.company} Cover Letter"),
                "pdf",
            )
        )
    store.update_offer_artifacts(offer, artifacts)
    store.save_offer(offer)
    for artifact in artifacts:
        store.append_event(offer.job_id, EventType.ARTIFACT_CREATED, {"kind": artifact.kind.value, "path": artifact.path})
    store.rebuild_projections()
    return offer


def build_apply_pack(root: Path, job_id: str, agent_name: str = "codex") -> OfferRecord:
    store = FileStore(root)
    candidate = load_candidate(root)
    offer = store.ensure_offer_exists(job_id)
    if not offer.scorecard:
        offer = evaluate_offer(root, job_id, agent_name)
    apply_pack = _agent_for(agent_name).generate_apply_pack(candidate, offer)
    json_artifact = store.save_text_artifact(
        offer.job_id,
        "apply-pack",
        ArtifactKind.APPLY_PACK_JSON,
        json.dumps(dataclass_to_dict(apply_pack), indent=2),
        "json",
    )
    md_artifact = store.save_text_artifact(offer.job_id, "apply-pack", ArtifactKind.APPLY_PACK_MD, render_apply_pack_markdown(offer, apply_pack), "md")
    store.update_offer_artifacts(offer, [json_artifact, md_artifact])
    offer.state = OfferState.PACKET_READY
    offer.source_citations = list(candidate.source_citations)
    store.save_offer(offer)
    store.append_event(offer.job_id, EventType.ARTIFACT_CREATED, {"kind": "apply_pack", "paths": [json_artifact.path, md_artifact.path]})
    store.rebuild_projections()
    return offer


def _sources_for_board(root: Path, board: str, search_preferences: dict) -> tuple[list[str], str | None]:
    board_sources = search_preferences.get("board_sources", {}).get(board, [])
    browser_assisted_inputs = search_preferences.get("browser_assisted_inputs", {})
    inputs_dir = browser_assisted_inputs.get(board)
    if not inputs_dir:
        candidate_dir = root / "data" / "board_inputs" / board
        inputs_dir = str(candidate_dir)
    sources = [str(item) for item in board_sources]
    if Path(inputs_dir).exists():
        for item in sorted(Path(inputs_dir).glob("*")):
            if item.is_file():
                sources.append(str(item))
    deduped: list[str] = []
    for source in sources:
        if source not in deduped:
            deduped.append(source)
    return deduped, inputs_dir


def search_jobs(
    root: Path,
    boards: list[str],
    min_match: float = 70.0,
    posted_within_hours: float = 24.0,
    limit_per_board: int = 20,
    agent_name: str = "codex",
) -> SearchSummary:
    candidate = load_candidate(root)
    store = FileStore(root)
    search_preferences = _read_search_preferences(root)
    existing = store.list_offers()
    discovered = 0
    unique = 0

    for board in boards:
        adapter = _adapter_for_portal(board)
        sources, inputs_dir = _sources_for_board(root, board, search_preferences)
        board_results: list[PortalResult] = []
        if sources:
            for source in sources:
                board_results.extend(adapter.fetch(source))
        elif inputs_dir:
            board_results.extend(adapter.search("", limit=limit_per_board, inputs_dir=inputs_dir))

        board_unique: list[OfferRecord] = []
        for result in board_results:
            matched_keywords, missing_keywords = keyword_overlap(
                f"{result.title}\n{result.description}",
                candidate.professional_keywords[:14] + candidate.core_skills[:14],
            )
            result.matched_keywords = matched_keywords[:12]
            result.missing_keywords = missing_keywords[:12]
            result.search_query = _best_search_query(result.title, result.description, candidate.search_phrases)
            result.board_name = board
            offer = _offer_from_result(result)
            duplicate_group = _duplicate_group_for(existing + board_unique, offer)
            if duplicate_group:
                offer.duplicate_group_id = duplicate_group
                discovered += 1
                continue

            scorecard = _agent_for(agent_name).evaluate_offer(
                candidate,
                OfferRecord(
                    schema_version=offer.schema_version,
                    job_id=offer.job_id,
                    company=offer.company,
                    title=offer.title,
                    source_url=offer.source_url,
                    source_type=offer.source_type,
                    location=offer.location,
                    employment_type=offer.employment_type,
                    state=offer.state,
                    description=offer.description,
                    content_fingerprint=offer.content_fingerprint,
                    discovered_at=offer.discovered_at,
                    verified_at=offer.verified_at,
                    last_updated_at=offer.last_updated_at,
                    posted_at=offer.posted_at,
                    discovery_method=offer.discovery_method,
                    liveness_status=offer.liveness_status,
                    match_score_pct=offer.match_score_pct,
                    work_mode=offer.work_mode,
                    salary_text=offer.salary_text,
                    sponsorship_note=offer.sponsorship_note,
                    matched_keywords=offer.matched_keywords,
                    missing_keywords=offer.missing_keywords,
                    board_name=offer.board_name,
                    search_query=offer.search_query,
                    posted_at_raw=offer.posted_at_raw,
                    posted_age_hours=offer.posted_age_hours,
                    freshness_unknown=offer.freshness_unknown,
                    duplicate_group_id=offer.duplicate_group_id,
                ),
            ).scorecard
            offer.scorecard = scorecard
            offer.match_score_pct = scorecard.weighted_score
            offer.recommendation = scorecard.recommendation
            offer.source_citations = list(candidate.source_citations)
            if offer.freshness_unknown or offer.posted_age_hours is None or offer.posted_age_hours > posted_within_hours:
                offer.state = OfferState.DISCOVERED
            elif offer.match_score_pct >= min_match:
                offer.state = OfferState.VERIFIED
                offer.verified_at = utc_now()
            else:
                offer.state = OfferState.DISCOVERED
            offer.sponsorship_note = offer.sponsorship_note or next(
                (flag for flag in scorecard.red_flags if "sponsorship" in flag.lower() or "citizenship" in flag.lower()),
                offer.sponsorship_note,
            )
            board_unique.append(offer)
            discovered += 1

        board_unique = sorted(board_unique, key=lambda item: (item.freshness_unknown, item.posted_age_hours or 999999, -(item.match_score_pct or 0.0)))[:limit_per_board]
        for offer in board_unique:
            unique += 1
            store.save_offer(offer)
            store.append_event(
                offer.job_id,
                EventType.DISCOVERED,
                {"board": board, "search_query": offer.search_query, "match_score_pct": offer.match_score_pct},
            )
            existing.append(offer)

    store.rebuild_projections()
    offers = store.list_offers()
    fresh_matches = len(
        [
            offer
            for offer in offers
            if not offer.freshness_unknown and offer.posted_age_hours is not None and offer.posted_age_hours <= posted_within_hours
        ]
    )
    strong_matches = len([offer for offer in offers if (offer.match_score_pct or 0.0) >= min_match])
    return SearchSummary(
        boards=boards,
        discovered=discovered,
        unique=unique,
        fresh_matches=fresh_matches,
        strong_matches=strong_matches,
        tracker_path=relative_path_text(root, store.tracker_path),
    )


def run_batch(root: Path, parallel: int = 4, limit: int | None = None, agent_name: str = "codex") -> BatchSummary:
    store = FileStore(root)
    run_id = f"batch-{utc_now().replace(':', '-').replace('+00:00', 'z')}"
    candidates = [offer for offer in store.list_offers() if offer.state in {OfferState.VERIFIED, OfferState.QUEUED}]
    if limit is not None:
        candidates = candidates[:limit]

    for offer in candidates:
        offer.state = OfferState.QUEUED
        store.save_offer(offer)
        store.append_event(offer.job_id, EventType.STATE_CHANGED, {"state": OfferState.QUEUED.value})

    def worker(job_id: str) -> str:
        offer = evaluate_offer(root, job_id, agent_name)
        if any(note == "force_fail" for note in offer.notes):
            raise RuntimeError("forced batch failure for test coverage")
        build_pdf_artifacts(root, job_id, agent_name)
        build_apply_pack(root, job_id, agent_name)
        return job_id

    completed: list[str] = []
    failed: dict[str, str] = {}
    skipped = [offer.job_id for offer in store.list_offers() if offer.state not in {OfferState.VERIFIED, OfferState.QUEUED}]

    with ThreadPoolExecutor(max_workers=max(1, parallel)) as executor:
        futures = {executor.submit(worker, offer.job_id): offer.job_id for offer in candidates}
        for future in as_completed(futures):
            job_id = futures[future]
            try:
                completed.append(future.result())
                store.append_event(job_id, EventType.BATCH_RUN, {"run_id": run_id, "status": "completed"})
            except Exception as exc:
                failed[job_id] = str(exc)
                offer = store.ensure_offer_exists(job_id)
                offer.state = OfferState.VERIFIED
                offer.notes.append(f"batch failure: {exc}")
                store.save_offer(offer)
                store.append_event(job_id, EventType.FAILED, {"run_id": run_id, "error": str(exc)})

    run_path = store.runs_dir / f"{run_id}.json"
    run_path.write_text(json.dumps({"run_id": run_id, "completed": completed, "failed": failed, "skipped": skipped}, indent=2), encoding="utf-8")
    store.rebuild_projections()
    return BatchSummary(run_id=run_id, completed=completed, failed=failed, skipped=skipped)


def export_jobs(
    root: Path,
    *,
    min_match: float = 70.0,
    limit: int | None = None,
    agent_name: str = "codex",
    force: bool = False,
) -> JobsExportSummary:
    """
    Create `jobs/<Company>/<job_id>/` folders for strong matches and ensure each includes a tailored resume.

    For each selected offer, this ensures it is evaluated (if needed), builds PDF artifacts, then exports the folder.
    """
    store = FileStore(root)
    offers = store.list_offers()
    exported: list[str] = []
    skipped: list[str] = []

    # Ensure scores exist where missing so strong matches are not missed.
    for offer in offers:
        if offer.match_score_pct is None or offer.scorecard is None:
            try:
                offer = evaluate_offer(root, offer.job_id, agent_name)
            except Exception:
                skipped.append(offer.job_id)

    offers = store.list_offers()
    strong = [offer for offer in offers if (offer.match_score_pct or 0.0) >= min_match]
    strong.sort(key=lambda item: (-(item.match_score_pct or 0.0), item.company, item.title))
    if limit is not None:
        strong = strong[: max(0, limit)]

    for offer in strong:
        try:
            offer = build_pdf_artifacts(root, offer.job_id, agent_name, include_cover_letter=True)
            export_job_folder(root, offer, force=force)
            exported.append(offer.job_id)
        except Exception:
            skipped.append(offer.job_id)

    store.rebuild_projections()
    return JobsExportSummary(exported=exported, skipped=skipped, jobs_root=relative_path_text(root, root / "jobs"))


def tracker_summary(root: Path) -> dict[str, object]:
    store = FileStore(root)
    offers = store.list_offers()
    scored = [offer.match_score_pct for offer in offers if offer.match_score_pct is not None]
    return {
        "total": len(offers),
        "by_state": {state.value: len([offer for offer in offers if offer.state == state]) for state in OfferState},
        "average_score": round(sum(scored) / len(scored), 2) if scored else 0.0,
        "tracker_path": relative_path_text(root, store.tracker_path),
    }
