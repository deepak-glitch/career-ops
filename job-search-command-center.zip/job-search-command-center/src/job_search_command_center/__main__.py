from job_search_command_center.cli.main import main


if __name__ == "__main__":
    raise SystemExit(main())
