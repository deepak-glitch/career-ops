"""Rendering adapters."""
