from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass


PAGE_WIDTH = 612
PAGE_HEIGHT = 792
LEFT_MARGIN = 72
RIGHT_MARGIN = 72
TOP_START = 756
BOTTOM_MARGIN = 54
CONTENT_WIDTH = PAGE_WIDTH - LEFT_MARGIN - RIGHT_MARGIN
SKILL_BODY_X = LEFT_MARGIN + 165
HEADING_LINE_GAP = 18


@dataclass(slots=True)
class ResumeBlock:
    kind: str
    text: str
    right_text: str | None = None


def _escape_pdf_text(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _font_name(font_key: str) -> str:
    return "/F2" if font_key == "bold" else "/F1"


def _char_width(ch: str, *, bold: bool) -> int:
    if ch == " ":
        return 250
    if ch in "ilI.,:;'`|!":
        return 230 if bold else 210
    if ch in "mwMW@#%&":
        return 920 if bold else 860
    if ch.isupper():
        return 640 if bold else 610
    if ch.isdigit():
        return 500
    return 470 if bold else 450


def _measure_text(text: str, size: float, *, bold: bool = False) -> float:
    total = sum(_char_width(ch, bold=bold) for ch in text)
    return total * size / 1000.0


def _wrap_text(text: str, max_width: float, *, size: float, bold: bool = False) -> list[str]:
    words = text.split()
    if not words:
        return [""]
    lines: list[str] = []
    current = words[0]
    for word in words[1:]:
        candidate = f"{current} {word}"
        if _measure_text(candidate, size, bold=bold) <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def _date_line_pattern(text: str) -> bool:
    return bool(re.match(r"^[A-Z][a-z]{2}\s+\d{4}\s+-", text))


def _parse_resume_blocks(text: str) -> list[ResumeBlock]:
    raw_lines = [line.rstrip() for line in text.splitlines()]
    if not raw_lines:
        return []

    blocks: list[ResumeBlock] = []
    title = raw_lines[0][2:].strip() if raw_lines[0].startswith("# ") else raw_lines[0].strip()
    if title:
        blocks.append(ResumeBlock("title", title))
    if len(raw_lines) > 1 and raw_lines[1].strip():
        blocks.append(ResumeBlock("contact", raw_lines[1].strip()))
    if len(raw_lines) > 2 and raw_lines[2].strip():
        blocks.append(ResumeBlock("role", raw_lines[2].strip()))

    body_lines = raw_lines[3:]
    current_section = ""
    i = 0
    while i < len(body_lines):
        line = body_lines[i].strip()
        if not line:
            blocks.append(ResumeBlock("spacer", ""))
            i += 1
            continue
        if current_section == "" and not line.isupper():
            blocks.append(ResumeBlock("summary", line))
            i += 1
            continue
        if line.isupper() and len(line) <= 40:
            current_section = line
            blocks.append(ResumeBlock("section", line))
            i += 1
            continue
        if current_section == "SKILLS":
            blocks.append(ResumeBlock("skill", line))
            i += 1
            continue
        if current_section == "PROFESSIONAL EXPERIENCE":
            next_line = body_lines[i + 1].strip() if i + 1 < len(body_lines) else ""
            if line and next_line and _date_line_pattern(next_line) and not line.startswith("- "):
                blocks.append(ResumeBlock("experience_heading", line, next_line))
                i += 2
                continue
            if line.startswith("- "):
                blocks.append(ResumeBlock("bullet", line[2:].strip()))
                i += 1
                continue
            blocks.append(ResumeBlock("body", line))
            i += 1
            continue
        if current_section == "PROJECTS":
            if line.startswith("- "):
                blocks.append(ResumeBlock("bullet", line[2:].strip()))
            else:
                blocks.append(ResumeBlock("project_title", line))
            i += 1
            continue
        if current_section == "EDUCATION":
            next_line = body_lines[i + 1].strip() if i + 1 < len(body_lines) else ""
            if line and next_line and _date_line_pattern(next_line):
                blocks.append(ResumeBlock("education_heading", line, next_line))
                i += 2
                continue
            blocks.append(ResumeBlock("body", line))
            i += 1
            continue
        if current_section == "CERTIFICATIONS":
            blocks.append(ResumeBlock("bullet", line[2:].strip() if line.startswith("- ") else line))
            i += 1
            continue
        blocks.append(ResumeBlock("body", line))
        i += 1
    return blocks


def _wrap_structured_lines(text: str) -> list[tuple[str, str]]:
    structured: list[tuple[str, str]] = []
    for block in _parse_resume_blocks(text):
        if block.kind == "title":
            structured.append(("title", block.text))
        elif block.kind == "contact":
            structured.append(("contact", block.text))
        elif block.kind == "role":
            structured.append(("role", block.text))
        elif block.kind == "section":
            structured.append(("section", block.text))
        elif block.kind in {"summary", "skill", "body", "project_title"}:
            wrapped = textwrap.wrap(block.text, width=92) or [""]
            kind = "body" if block.kind != "project_title" else "section"
            for line in wrapped:
                structured.append((kind, line))
        elif block.kind == "experience_heading":
            structured.append(("body", block.text))
            structured.append(("body", block.right_text or ""))
        elif block.kind == "education_heading":
            structured.append(("body", block.text))
            structured.append(("body", block.right_text or ""))
        elif block.kind == "bullet":
            wrapped = textwrap.wrap(block.text, width=88) or [""]
            structured.append(("bullet", wrapped[0]))
            for extra in wrapped[1:]:
                structured.append(("bullet_cont", extra))
        elif block.kind == "spacer":
            structured.append(("blank", ""))
    return structured


class _PdfCanvas:
    def __init__(self) -> None:
        self.pages: list[list[str]] = [[]]
        self.y = TOP_START

    def _commands(self) -> list[str]:
        return self.pages[-1]

    def ensure_space(self, required: float) -> None:
        if self.y - required < BOTTOM_MARGIN:
            self.pages.append([])
            self.y = TOP_START

    def spacer(self, amount: float) -> None:
        self.ensure_space(amount)
        self.y -= amount

    def text(self, text: str, *, x: float, font_key: str, size: float) -> None:
        escaped = _escape_pdf_text(text)
        self._commands().extend(
            [
                "BT",
                f"{_font_name(font_key)} {size:.2f} Tf",
                f"1 0 0 1 {x:.2f} {self.y:.2f} Tm",
                f"({escaped}) Tj",
                "ET",
            ]
        )

    def centered_text(self, text: str, *, font_key: str, size: float) -> None:
        width = _measure_text(text, size, bold=font_key == "bold")
        x = max(LEFT_MARGIN, (PAGE_WIDTH - width) / 2.0)
        self.text(text, x=x, font_key=font_key, size=size)


def _draw_heading_block(canvas: _PdfCanvas, title: str, meta: str | None) -> None:
    meta_text = meta or ""
    title_width = _measure_text(title, 10, bold=True)
    meta_width = _measure_text(meta_text, 10)
    meta_x = max(LEFT_MARGIN, PAGE_WIDTH - RIGHT_MARGIN - meta_width)
    same_line_room = (meta_x - LEFT_MARGIN) - HEADING_LINE_GAP

    canvas.spacer(2)
    if meta_text and title_width <= same_line_room:
        canvas.ensure_space(12)
        canvas.text(title, x=LEFT_MARGIN, font_key="bold", size=10)
        canvas.text(meta_text, x=meta_x, font_key="regular", size=10)
        canvas.spacer(14)
        return

    for line in _wrap_text(title, CONTENT_WIDTH, size=10, bold=True):
        canvas.ensure_space(12)
        canvas.text(line, x=LEFT_MARGIN, font_key="bold", size=10)
        canvas.spacer(12)

    if meta_text:
        canvas.ensure_space(12)
        canvas.text(meta_text, x=meta_x, font_key="regular", size=10)
        canvas.spacer(14)


def build_resume_pdf(text: str, title: str = "Resume") -> bytes:
    blocks = _parse_resume_blocks(text)
    canvas = _PdfCanvas()

    for block in blocks:
        if block.kind == "title":
            canvas.ensure_space(24)
            canvas.centered_text(block.text, font_key="bold", size=16)
            canvas.spacer(18)
            continue

        if block.kind == "contact":
            canvas.ensure_space(14)
            canvas.centered_text(block.text, font_key="regular", size=10)
            canvas.spacer(16)
            continue

        if block.kind == "role":
            canvas.ensure_space(14)
            canvas.text(block.text, x=LEFT_MARGIN, font_key="bold", size=10)
            canvas.spacer(18)
            continue

        if block.kind == "section":
            canvas.spacer(4)
            canvas.ensure_space(14)
            canvas.text(block.text, x=LEFT_MARGIN, font_key="bold", size=10)
            canvas.spacer(14)
            continue

        if block.kind == "summary":
            wrapped = _wrap_text(block.text, CONTENT_WIDTH, size=10)
            for line in wrapped:
                canvas.ensure_space(12)
                canvas.text(line, x=LEFT_MARGIN, font_key="regular", size=10)
                canvas.spacer(12)
            canvas.spacer(4)
            continue

        if block.kind == "skill":
            if ":" in block.text:
                label, rest = block.text.split(":", 1)
                label_text = f"{label}:"
                label_width = _measure_text(label_text, 10, bold=True)
                body_x = max(SKILL_BODY_X, LEFT_MARGIN + label_width + 8)
                max_body_width = PAGE_WIDTH - RIGHT_MARGIN - body_x
                wrapped_rest = _wrap_text(rest.strip(), max_body_width, size=10)
                first = wrapped_rest[0] if wrapped_rest else ""
                canvas.ensure_space(12)
                canvas.text(label_text, x=LEFT_MARGIN, font_key="bold", size=10)
                canvas.text(first, x=body_x, font_key="regular", size=10)
                canvas.spacer(12)
                for extra in wrapped_rest[1:]:
                    canvas.ensure_space(12)
                    canvas.text(extra, x=body_x, font_key="regular", size=10)
                    canvas.spacer(12)
            else:
                wrapped = _wrap_text(block.text, CONTENT_WIDTH, size=10)
                for line in wrapped:
                    canvas.ensure_space(12)
                    canvas.text(line, x=LEFT_MARGIN, font_key="regular", size=10)
                    canvas.spacer(12)
            continue

        if block.kind in {"experience_heading", "education_heading"}:
            _draw_heading_block(canvas, block.text, block.right_text)
            continue

        if block.kind == "project_title":
            wrapped = _wrap_text(block.text, CONTENT_WIDTH, size=10, bold=True)
            for line in wrapped:
                canvas.ensure_space(12)
                canvas.text(line, x=LEFT_MARGIN, font_key="bold", size=10)
                canvas.spacer(12)
            continue

        if block.kind == "bullet":
            wrapped = _wrap_text(block.text, CONTENT_WIDTH - 22, size=10)
            bullet_x = LEFT_MARGIN + 6
            text_x = LEFT_MARGIN + 18
            for index, line in enumerate(wrapped):
                canvas.ensure_space(12)
                if index == 0:
                    canvas.text("-", x=bullet_x, font_key="regular", size=10)
                canvas.text(line, x=text_x, font_key="regular", size=10)
                canvas.spacer(12)
            continue

        if block.kind == "body":
            wrapped = _wrap_text(block.text, CONTENT_WIDTH, size=10)
            for line in wrapped:
                canvas.ensure_space(12)
                canvas.text(line, x=LEFT_MARGIN, font_key="regular", size=10)
                canvas.spacer(12)
            continue

        if block.kind == "spacer":
            canvas.spacer(6)

    return _build_pdf_document(canvas.pages or [[]], title=title)


def _build_pdf_document(pages: list[list[str]], *, title: str) -> bytes:
    objects: list[bytes] = []
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")

    page_object_ids: list[int] = []
    content_object_ids: list[int] = []
    next_object_id = 3
    for _ in pages:
        page_object_ids.append(next_object_id)
        content_object_ids.append(next_object_id + 1)
        next_object_id += 2

    kids = " ".join(f"{object_id} 0 R" for object_id in page_object_ids)
    objects.append(f"<< /Type /Pages /Count {len(pages)} /Kids [{kids}] >>".encode("ascii"))

    for page_index, page_commands in enumerate(pages):
        content_stream = "\n".join(page_commands).encode("latin-1", errors="replace")
        content_object_id = content_object_ids[page_index]
        page_object = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] /Resources "
            f"<< /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >> "
            f"/F2 << /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >> >> >> "
            f"/Contents {content_object_id} 0 R >>"
        ).encode("ascii")
        content_object = b"<< /Length " + str(len(content_stream)).encode("ascii") + b" >>\nstream\n" + content_stream + b"\nendstream"
        objects.append(page_object)
        objects.append(content_object)

    header = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    body = bytearray(header)
    offsets = [0]
    for index, obj in enumerate(objects, start=1):
        offsets.append(len(body))
        body.extend(f"{index} 0 obj\n".encode("ascii"))
        body.extend(obj)
        body.extend(b"\nendobj\n")

    xref_offset = len(body)
    body.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    body.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        body.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    trailer = (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R /Info << /Title ({_escape_pdf_text(title)}) >> >>\n"
        f"startxref\n{xref_offset}\n%%EOF"
    )
    body.extend(trailer.encode("latin-1", errors="replace"))
    return bytes(body)


def build_text_pdf(text: str, title: str = "Document") -> bytes:
    stripped = [line.strip() for line in text.splitlines() if line.strip()]
    if stripped and stripped[0].startswith("# "):
        return build_resume_pdf(text, title=title)

    structured_lines = _wrap_structured_lines(text)
    pages: list[list[tuple[str, str]]] = []
    current_page: list[tuple[str, str]] = []
    remaining_height = 730
    line_heights = {
        "title": 22,
        "contact": 16,
        "role": 18,
        "section": 16,
        "body": 14,
        "bullet": 14,
        "bullet_cont": 14,
        "blank": 8,
    }
    for item in structured_lines or [("blank", "")]:
        line_type, _line_text = item
        needed = line_heights.get(line_type, 15)
        if current_page and remaining_height - needed < 40:
            pages.append(current_page)
            current_page = []
            remaining_height = 730
        current_page.append(item)
        remaining_height -= needed
    if not pages or current_page:
        pages.append(current_page)

    objects: list[bytes] = []
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")

    page_object_ids: list[int] = []
    content_object_ids: list[int] = []
    next_object_id = 3
    for _ in pages:
        page_object_ids.append(next_object_id)
        content_object_ids.append(next_object_id + 1)
        next_object_id += 2

    kids = " ".join(f"{object_id} 0 R" for object_id in page_object_ids)
    objects.append(f"<< /Type /Pages /Count {len(pages)} /Kids [{kids}] >>".encode("ascii"))

    for page_index, lines in enumerate(pages):
        content_object_id = content_object_ids[page_index]
        content_lines = ["BT", "50 770 Td"]
        first_line = True
        for line_type, line in lines:
            escaped = _escape_pdf_text(line)
            font = "/F1 10 Tf"
            indent = 0
            move = 14
            align = "left"
            if line_type == "title":
                font = "/F2 16 Tf"
                move = 22
                align = "center"
            elif line_type == "contact":
                move = 16
                align = "center"
            elif line_type == "role":
                font = "/F2 10 Tf"
                move = 18
            elif line_type == "section":
                font = "/F2 10 Tf"
                move = 16
            elif line_type == "bullet":
                indent = 12
            elif line_type == "bullet_cont":
                indent = 24
            elif line_type == "blank":
                escaped = ""
                move = 8

            center_indent = 0
            if align == "center":
                approximate_width = len(line) * (8 if line_type == "title" else 5)
                center_indent = max(0, int((512 - approximate_width) / 2))

            if first_line:
                content_lines.append(font)
                if center_indent:
                    content_lines.append(f"{center_indent} 0 Td")
                elif indent:
                    content_lines.append(f"{indent} 0 Td")
                content_lines.append(f"({escaped}) Tj")
                if center_indent:
                    content_lines.append(f"{-center_indent} 0 Td")
                elif indent:
                    content_lines.append(f"{-indent} 0 Td")
                first_line = False
                continue
            content_lines.append(f"0 -{move} Td")
            content_lines.append(font)
            if center_indent:
                content_lines.append(f"{center_indent} 0 Td")
            elif indent:
                content_lines.append(f"{indent} 0 Td")
            content_lines.append(f"({escaped}) Tj")
            if center_indent:
                content_lines.append(f"{-center_indent} 0 Td")
            elif indent:
                content_lines.append(f"{-indent} 0 Td")
        content_lines.append("ET")
        content_stream = "\n".join(content_lines).encode("latin-1", errors="replace")
        page_object = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources "
            f"<< /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >> "
            f"/F2 << /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >> >> >> "
            f"/Contents {content_object_id} 0 R >>"
        ).encode("ascii")
        content_object = b"<< /Length " + str(len(content_stream)).encode("ascii") + b" >>\nstream\n" + content_stream + b"\nendstream"
        objects.append(page_object)
        objects.append(content_object)

    header = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    body = bytearray(header)
    offsets = [0]
    for index, obj in enumerate(objects, start=1):
        offsets.append(len(body))
        body.extend(f"{index} 0 obj\n".encode("ascii"))
        body.extend(obj)
        body.extend(b"\nendobj\n")

    xref_offset = len(body)
    body.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    body.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        body.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    trailer = (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R /Info << /Title ({_escape_pdf_text(title)}) >> >>\n"
        f"startxref\n{xref_offset}\n%%EOF"
    )
    body.extend(trailer.encode("latin-1", errors="replace"))
    return bytes(body)
