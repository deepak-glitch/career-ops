from __future__ import annotations

import html
import re
import zipfile
from pathlib import Path


WORD_NAMESPACES = (
    'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
    'xmlns:ve="http://schemas.openxmlformats.org/markup-compatibility/2006" '
    'xmlns:o="urn:schemas-microsoft-com:office:office" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
    'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
    'xmlns:v="urn:schemas-microsoft-com:vml" '
    'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
    'xmlns:w10="urn:schemas-microsoft-com:office:word" '
    'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
    'xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" '
    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
    'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" '
    'xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" '
    'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" '
    'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
    'mc:Ignorable="w14" xml:space="preserve"'
)


def _escape(text: str) -> str:
    return html.escape(text, quote=False)


def _extract_sect_pr(template_bytes: bytes) -> str:
    xml = template_bytes.decode("utf-8", errors="replace")
    match = re.search(r"(<w:sectPr[\s\S]+?</w:sectPr>)", xml)
    if not match:
        return (
            '<w:sectPr>'
            '<w:pgSz w:w="12240" w:h="15840"/>'
            '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/>'
            '</w:sectPr>'
        )
    return match.group(1)


def _run(text: str, *, bold: bool = False, spacing: int | None = None) -> str:
    if not text:
        return ""
    rpr = []
    if bold:
        rpr.append("<w:b/><w:bCs/>")
    if spacing is not None:
        rpr.append(f'<w:spacing w:val="{spacing}"/>')
    rpr_xml = f"<w:rPr>{''.join(rpr)}</w:rPr>" if rpr else "<w:rPr/>"
    return f"<w:r>{rpr_xml}<w:t>{_escape(text)}</w:t></w:r>"


def _paragraph(text: str, *, style: str | None = None, center: bool = False, spacing_before: int | None = None,
               indent_left: int | None = None, right: int | None = None, first_line: int | None = None,
               justify: str | None = None, runs: str | None = None) -> str:
    ppr_parts = []
    if style:
        ppr_parts.append(f'<w:pStyle w:val="{style}"/>')
    if spacing_before is not None:
        ppr_parts.append(f'<w:spacing w:before="{spacing_before}"/>')
    if indent_left is not None or right is not None or first_line is not None:
        attrs = []
        if indent_left is not None:
            attrs.append(f'w:left="{indent_left}"')
        if right is not None:
            attrs.append(f'w:right="{right}"')
        if first_line is not None:
            attrs.append(f'w:firstLine="{first_line}"')
        ppr_parts.append(f"<w:ind {' '.join(attrs)}/>")
    if center:
        ppr_parts.append('<w:jc w:val="center"/>')
    elif justify:
        ppr_parts.append(f'<w:jc w:val="{justify}"/>')
    ppr = f"<w:pPr>{''.join(ppr_parts)}</w:pPr>" if ppr_parts else "<w:pPr/>"
    body = runs if runs is not None else _run(text)
    return f"<w:p>{ppr}{body}</w:p>"


def _blank_paragraph() -> str:
    return '<w:p><w:pPr><w:pStyle w:val="BodyText"/></w:pPr><w:r><w:rPr><w:b/></w:rPr></w:r></w:p>'


def _contact_paragraph(text: str) -> str:
    return _paragraph(text, style="BodyText", center=True)


def _role_paragraph(text: str) -> str:
    return _paragraph(text, style="Heading2")


def _summary_paragraph(text: str) -> str:
    return _paragraph(text, style="BodyText", spacing_before=75, indent_left=14, right=307, justify="both")


def _section_paragraph(text: str) -> str:
    return _paragraph(text, style="Heading1", spacing_before=123)


def _skill_line(text: str) -> str:
    if ":" in text:
        label, rest = text.split(":", 1)
        runs = _run(label + ":", bold=True) + _run(rest)
        return _paragraph("", runs=runs, indent_left=14)
    return _paragraph(text, indent_left=14)


def _date_line_pattern(text: str) -> bool:
    return bool(re.match(r"^[A-Z][a-z]{2}\s+\d{4}\s+-", text))


def _experience_heading_paragraph(title_line: str, meta_line: str) -> str:
    runs = _run(title_line, bold=True) + '<w:r><w:rPr/><w:tab/></w:r>' + _run(meta_line)
    return (
        '<w:p><w:pPr><w:tabs><w:tab w:pos="8282" w:val="left" w:leader="none"/></w:tabs>'
        '<w:spacing w:before="155"/><w:ind w:left="14" w:right="0" w:firstLine="0"/>'
        '<w:jc w:val="left"/></w:pPr>'
        f'{runs}</w:p>'
    )


def _project_title_paragraph(text: str) -> str:
    return _paragraph("", runs=_run(text, bold=True), indent_left=14, spacing_before=80)


def _education_heading_paragraph(title_line: str, meta_line: str) -> str:
    runs = _run(title_line, bold=True) + '<w:r><w:rPr/><w:tab/></w:r>' + _run(meta_line)
    return (
        '<w:p><w:pPr><w:tabs><w:tab w:pos="8282" w:val="left" w:leader="none"/></w:tabs>'
        '<w:spacing w:before="100"/><w:ind w:left="14" w:right="0" w:firstLine="0"/>'
        '<w:jc w:val="left"/></w:pPr>'
        f'{runs}</w:p>'
    )


def _bullet_paragraph(text: str) -> str:
    runs = _run(text)
    return (
        '<w:p><w:pPr><w:pStyle w:val="ListParagraph"/><w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr>'
        '<w:tabs><w:tab w:pos="374" w:val="left" w:leader="none"/></w:tabs>'
        '<w:spacing w:line="276" w:lineRule="auto" w:before="8" w:after="0"/>'
        '<w:ind w:left="374" w:right="800" w:hanging="360"/><w:jc w:val="left"/></w:pPr>'
        f'{runs}</w:p>'
    )


def build_resume_docx(text: str, template_path: str | Path) -> bytes:
    template_path = Path(template_path)
    lines = [line.rstrip() for line in text.splitlines()]
    title = lines[0][2:] if lines and lines[0].startswith("# ") else (lines[0] if lines else "")
    contact = lines[1] if len(lines) > 1 else ""
    role = lines[2] if len(lines) > 2 else ""
    body_lines = lines[3:] if len(lines) > 3 else []

    paragraphs: list[str] = [
        _paragraph(title, style="Title"),
        _blank_paragraph(),
        _contact_paragraph(contact),
        _role_paragraph(role),
    ]

    current_section = ""
    i = 0
    while i < len(body_lines):
        line = body_lines[i].strip()
        if not line:
            i += 1
            continue
        if current_section == "" and not line.isupper():
            paragraphs.append(_summary_paragraph(line))
            i += 1
            continue
        if line.isupper() and len(line) < 40:
            current_section = line
            paragraphs.append(_section_paragraph(line))
            i += 1
            continue
        if current_section == "SKILLS":
            paragraphs.append(_skill_line(line))
            i += 1
            continue
        if current_section == "PROFESSIONAL EXPERIENCE":
            next_line = body_lines[i + 1].strip() if i + 1 < len(body_lines) else ""
            if line and next_line and _date_line_pattern(next_line) and not line.startswith("- "):
                paragraphs.append(_experience_heading_paragraph(line, next_line))
                i += 2
                continue
            if line.startswith("- "):
                paragraphs.append(_bullet_paragraph(line[2:].strip()))
                i += 1
                continue
            i += 1
            continue
        if current_section == "PROJECTS":
            if not line.startswith("- "):
                paragraphs.append(_project_title_paragraph(line))
            else:
                paragraphs.append(_bullet_paragraph(line[2:].strip()))
            i += 1
            continue
        if current_section == "EDUCATION":
            next_line = body_lines[i + 1].strip() if i + 1 < len(body_lines) else ""
            if line and next_line and _date_line_pattern(next_line):
                paragraphs.append(_education_heading_paragraph(line, next_line))
                i += 2
                continue
            paragraphs.append(_paragraph(line, indent_left=14))
            i += 1
            continue
        if current_section == "CERTIFICATIONS":
            if line.startswith("- "):
                paragraphs.append(_bullet_paragraph(line[2:].strip()))
            else:
                paragraphs.append(_paragraph(line, indent_left=14))
            i += 1
            continue
        paragraphs.append(_paragraph(line, style="BodyText"))
        i += 1

    with zipfile.ZipFile(template_path) as template_zip:
        template_entries = {name: template_zip.read(name) for name in template_zip.namelist()}

    sect_pr = _extract_sect_pr(template_entries["word/document.xml"])
    document_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<w:document {WORD_NAMESPACES}><w:body>'
        + "".join(paragraphs)
        + sect_pr
        + "</w:body></w:document>"
    ).encode("utf-8")

    output = Path(template_path).with_suffix(".generated.docx")
    from io import BytesIO

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as out_zip:
        for name, data in template_entries.items():
            if name == "word/document.xml":
                out_zip.writestr(name, document_xml)
            else:
                out_zip.writestr(name, data)
    return buffer.getvalue()
