from __future__ import annotations

from abc import ABC, abstractmethod

from job_search_command_center.engine.types import ApplyPack, CandidateProfile, OfferRecord, WorkerResult


class AgentAdapter(ABC):
    name: str

    @abstractmethod
    def evaluate_offer(self, candidate: CandidateProfile, offer: OfferRecord) -> WorkerResult:
        raise NotImplementedError

    @abstractmethod
    def generate_pdf_inputs(self, candidate: CandidateProfile, offer: OfferRecord) -> dict[str, str]:
        raise NotImplementedError

    @abstractmethod
    def generate_apply_pack(self, candidate: CandidateProfile, offer: OfferRecord) -> ApplyPack:
        raise NotImplementedError

    def batch_worker(self, candidate: CandidateProfile, offer: OfferRecord) -> WorkerResult:
        return self.evaluate_offer(candidate, offer)
