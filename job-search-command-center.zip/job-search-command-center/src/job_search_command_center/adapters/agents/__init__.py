"""Agent adapters."""
