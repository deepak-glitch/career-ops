from __future__ import annotations

from job_search_command_center.adapters.agents.codex import CodexAgentAdapter
from job_search_command_center.engine.types import CandidateProfile, OfferRecord, WorkerResult


class MockAgentAdapter(CodexAgentAdapter):
    name = "mock"

    def evaluate_offer(self, candidate: CandidateProfile, offer: OfferRecord) -> WorkerResult:
        result = super().evaluate_offer(candidate, offer)
        result.normalized_jd_metadata["adapter"] = self.name
        return result
