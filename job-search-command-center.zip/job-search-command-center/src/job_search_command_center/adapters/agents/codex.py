from __future__ import annotations

from job_search_command_center.adapters.agents.base import AgentAdapter
from job_search_command_center.engine.reports import cover_letter_text, render_report, resume_text
from job_search_command_center.engine.scoring import ScoreContext, evaluate_scorecard
from job_search_command_center.engine.types import ApplyPack, ArtifactManifest, CandidateProfile, OfferRecord, WorkerResult, utc_now


class CodexAgentAdapter(AgentAdapter):
    name = "codex"

    def evaluate_offer(self, candidate: CandidateProfile, offer: OfferRecord) -> WorkerResult:
        scorecard = evaluate_scorecard(
            candidate,
            ScoreContext(
                company=offer.company,
                title=offer.title,
                description=offer.description,
                location=offer.location,
                work_mode=offer.work_mode,
                salary_text=offer.salary_text,
                sponsorship_text=offer.sponsorship_note,
                posted_age_hours=offer.posted_age_hours,
                freshness_unknown=offer.freshness_unknown,
            ),
        )
        report_body = render_report(candidate, offer, scorecard)
        return WorkerResult(
            normalized_jd_metadata={
                "company": offer.company,
                "title": offer.title,
                "location": offer.location,
                "employment_type": offer.employment_type,
            },
            scorecard=scorecard,
            recommendation=scorecard.recommendation,
            report_body=report_body,
            artifact_manifest=ArtifactManifest(),
            source_citations=list(candidate.source_citations),
        )

    def generate_pdf_inputs(self, candidate: CandidateProfile, offer: OfferRecord) -> dict[str, str]:
        if not offer.scorecard:
            raise ValueError("offer must be evaluated before generating PDF inputs")
        return {
            "resume": resume_text(candidate, offer, offer.scorecard),
            "cover_letter": cover_letter_text(candidate, offer, offer.scorecard),
        }

    def generate_apply_pack(self, candidate: CandidateProfile, offer: OfferRecord) -> ApplyPack:
        score = offer.scorecard.weighted_score if offer.scorecard else "unknown"
        return ApplyPack(
            version="1.0",
            job_id=offer.job_id,
            generated_at=utc_now(),
            checklist=[
                "Review the tailored resume PDF for tone and wording.",
                "Confirm work authorization language matches the application form.",
                "Use the answer pack for free-text fields, then manually review before submitting.",
            ],
            answers={
                "Why are you interested in this role?": (
                    f"I am interested in the {offer.title} role at {offer.company} because it lines up with my background in applied AI, "
                    f"workflow automation, and product-minded engineering. The role scored {score}/100 in my pipeline because the JD overlaps "
                    f"with the systems work I already do."
                ),
                "Why are you a fit?": (
                    "My background combines Python delivery, AI workflow design, and hands-on ownership from idea to shipped artifact. "
                    "I am strongest when the work needs both technical execution and pragmatic product judgment."
                ),
                "Anything else we should know?": (
                    f"I prefer roles with strong remote collaboration habits and clear ownership. My source materials for this application live in "
                    f"{', '.join(candidate.source_citations)}."
                ),
            },
            source_citations=list(candidate.source_citations),
        )
