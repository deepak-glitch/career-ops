from __future__ import annotations

from pathlib import Path
from urllib.parse import urljoin

from job_search_command_center.adapters.portals.base import PortalAdapter
from job_search_command_center.adapters.portals.common import AnchorParser, build_result, infer_company_from_url, load_source_text, parse_local_description
from job_search_command_center.engine.types import PortalResult, SourceType


class GenericPortalAdapter(PortalAdapter):
    name = "generic"

    def fetch(self, source: str) -> list[PortalResult]:
        source_path = Path(source)
        if source_path.exists() and source_path.suffix.lower() in {".md", ".txt"}:
            description = source_path.read_text(encoding="utf-8")
            metadata = parse_local_description(description, source)
            return [
                build_result(
                    source_type=SourceType.LOCAL,
                    source_url=metadata["source_url"],
                    company=str(metadata["company"] or "Local Company"),
                    title=str(metadata["title"] or "Local Role"),
                    location=str(metadata["location"] or "Remote"),
                    employment_type=str(metadata["employment_type"] or "Full-time"),
                    posted_at=str(metadata["posted_at"]) if metadata.get("posted_at") else None,
                    description=str(metadata["description"] or description),
                    discovery_method="local_file",
                    posted_at_raw=str(metadata["posted_at_raw"]) if metadata.get("posted_at_raw") else None,
                )
            ]

        text = load_source_text(source)
        parser = AnchorParser()
        parser.feed(text)
        company = infer_company_from_url(source)
        if not parser.links:
            return [
                build_result(
                    source_type=SourceType.GENERIC,
                    source_url=source,
                    company=company,
                    title="Generic Parsed Role",
                    location="Unknown",
                    employment_type="Unknown",
                    posted_at=None,
                    description=text,
                    discovery_method="generic_page",
                )
            ]
        return [
            build_result(
                source_type=SourceType.GENERIC,
                source_url=urljoin(source, href),
                company=company,
                title=title or "Generic Parsed Role",
                location="Unknown",
                employment_type="Unknown",
                posted_at=None,
                description=text,
                discovery_method="generic_page",
            )
            for href, title in parser.links
        ]
