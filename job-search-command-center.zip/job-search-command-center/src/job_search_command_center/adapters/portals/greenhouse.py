from __future__ import annotations

from pathlib import Path

from job_search_command_center.adapters.portals.base import PortalAdapter
from job_search_command_center.adapters.portals.common import build_result, load_source_json, load_source_text, parse_local_description
from job_search_command_center.engine.types import PortalResult, SourceType


class GreenhouseAdapter(PortalAdapter):
    name = "greenhouse"

    def fetch(self, source: str) -> list[PortalResult]:
        source_path = Path(source)
        if source_path.exists() and source_path.suffix.lower() in {".md", ".txt"}:
            description = source_path.read_text(encoding="utf-8")
            metadata = parse_local_description(description, source)
            return [
                build_result(
                    source_type=SourceType.GREENHOUSE,
                    source_url=str(metadata["source_url"] or source),
                    company=str(metadata["company"] or "Greenhouse Company"),
                    title=str(metadata["title"] or "Greenhouse Imported Role"),
                    location=str(metadata["location"] or "Unknown"),
                    employment_type=str(metadata["employment_type"] or "Unknown"),
                    posted_at=str(metadata["posted_at"]) if metadata.get("posted_at") else None,
                    description=str(metadata["description"] or description),
                    discovery_method="greenhouse_local_file",
                    posted_at_raw=str(metadata["posted_at_raw"]) if metadata.get("posted_at_raw") else None,
                )
            ]
        if source.endswith(".json") or "boards-api.greenhouse.io" in source:
            payload = load_source_json(source)
            results: list[PortalResult] = []
            for job in payload.get("jobs", []):
                company = "Greenhouse Company"
                url = str(job.get("absolute_url") or source)
                results.append(
                    build_result(
                        source_type=SourceType.GREENHOUSE,
                        source_url=url,
                        company=company,
                        title=str(job.get("title") or "Unknown Role"),
                        location=str(job.get("location", {}).get("name") or "Unknown"),
                        employment_type=str(next((item.get("value") for item in job.get("metadata", []) if item.get("name") == "employment_type"), "Unknown")),
                        posted_at=str(job.get("updated_at")) if job.get("updated_at") else None,
                        description=str(job.get("content") or ""),
                        discovery_method="greenhouse_api",
                    )
                )
            return results
        return [
            build_result(
                source_type=SourceType.GREENHOUSE,
                source_url=source,
                company="Greenhouse Company",
                title="Parsed Greenhouse Role",
                location="Unknown",
                employment_type="Unknown",
                posted_at=None,
                description=load_source_text(source),
                discovery_method="greenhouse_page",
            )
        ]

    def search(self, query: str, limit: int = 20, inputs_dir: str | None = None) -> list[PortalResult]:
        if not inputs_dir:
            return []
        path = Path(inputs_dir)
        if not path.exists():
            return []
        results: list[PortalResult] = []
        for item in sorted(path.glob("*")):
            if item.is_file():
                for result in self.fetch(str(item)):
                    result.search_query = query
                    results.append(result)
        return results[:limit]
