from __future__ import annotations

from pathlib import Path
from urllib.parse import urljoin

from job_search_command_center.adapters.portals.base import PortalAdapter
from job_search_command_center.adapters.portals.common import AnchorParser, build_result, infer_company_from_url, load_source_text, parse_local_description
from job_search_command_center.engine.types import PortalResult, SourceType


class AshbyAdapter(PortalAdapter):
    name = "ashby"

    def fetch(self, source: str) -> list[PortalResult]:
        source_path = Path(source)
        if source_path.exists() and source_path.suffix.lower() in {".md", ".txt"}:
            description = source_path.read_text(encoding="utf-8")
            metadata = parse_local_description(description, source)
            return [
                build_result(
                    source_type=SourceType.ASHBY,
                    source_url=str(metadata["source_url"] or source),
                    company=str(metadata["company"] or infer_company_from_url(str(metadata["source_url"] or source))),
                    title=str(metadata["title"] or "Ashby Imported Role"),
                    location=str(metadata["location"] or "Unknown"),
                    employment_type=str(metadata["employment_type"] or "Unknown"),
                    posted_at=str(metadata["posted_at"]) if metadata.get("posted_at") else None,
                    description=str(metadata["description"] or description),
                    discovery_method="ashby_local_file",
                    posted_at_raw=str(metadata["posted_at_raw"]) if metadata.get("posted_at_raw") else None,
                )
            ]
        text = load_source_text(source)
        parser = AnchorParser()
        parser.feed(text)
        company = infer_company_from_url(source)
        results: list[PortalResult] = []
        for href, title in parser.links:
            if not title:
                continue
            results.append(
                build_result(
                    source_type=SourceType.ASHBY,
                    source_url=urljoin(source, href),
                    company=company,
                    title=title,
                    location="Unknown",
                    employment_type="Unknown",
                    posted_at=None,
                    description=text,
                    discovery_method="ashby_page",
                )
            )
        return results

    def search(self, query: str, limit: int = 20, inputs_dir: str | None = None) -> list[PortalResult]:
        if not inputs_dir:
            return []
        path = Path(inputs_dir)
        if not path.exists():
            return []
        results: list[PortalResult] = []
        for item in sorted(path.glob("*")):
            if item.is_file():
                for result in self.fetch(str(item)):
                    result.search_query = query
                    results.append(result)
        return results[:limit]
