from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen

from job_search_command_center.engine.ids import content_fingerprint, normalize_text
from job_search_command_center.engine.types import PortalResult, SourceType, utc_now


TRACKING_QUERY_KEYS = {
    "gh_jid",
    "gh_src",
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "trk",
    "trkInfo",
    "refId",
}


def load_source_text(source: str) -> str:
    path = Path(source)
    if path.exists():
        return path.read_text(encoding="utf-8")
    request = Request(source, headers={"User-Agent": "job-search-command-center/1.0"})
    with urlopen(request) as response:  # noqa: S310
        return response.read().decode("utf-8")


def load_source_json(source: str) -> dict:
    return json.loads(load_source_text(source))


def infer_company_from_url(url: str) -> str:
    host = urlparse(url).netloc or "local"
    host = host.replace("www.", "")
    return host.split(".")[0].replace("-", " ").title()


def canonicalize_url(url: str) -> str:
    parsed = urlparse(url)
    if not parsed.scheme:
        return url
    kept_query = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True) if key not in TRACKING_QUERY_KEYS]
    normalized_path = re.sub(r"/+", "/", parsed.path.rstrip("/")) or "/"
    return urlunparse((parsed.scheme.lower(), parsed.netloc.lower(), normalized_path, parsed.params, urlencode(kept_query), ""))


class AnchorParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[tuple[str, str]] = []
        self.current_href = ""
        self.current_text = ""
        self.in_anchor = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            attrs_dict = dict(attrs)
            href = attrs_dict.get("href") or ""
            self.current_href = href
            self.current_text = ""
            self.in_anchor = True

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self.in_anchor and self.current_href:
            self.links.append((self.current_href.strip(), self.current_text.strip()))
            self.current_href = ""
            self.current_text = ""
            self.in_anchor = False

    def handle_data(self, data: str) -> None:
        if self.in_anchor:
            self.current_text += data


def verify_description(description: str) -> str:
    lowered = description.lower()
    expired_markers = [
        "job no longer available",
        "no longer open",
        "position has been filled",
        "this job has expired",
        "page not found",
    ]
    if any(marker in lowered for marker in expired_markers):
        return "expired"
    if len(description.strip()) < 40:
        return "expired"
    return "active"


def parse_posted_age_hours(posted_at: str | None, now: datetime | None = None) -> tuple[float | None, bool]:
    if not posted_at:
        return None, True
    raw = posted_at.strip()
    lowered = raw.lower()
    reference = now or datetime.now(timezone.utc)

    direct_patterns = [
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d",
        "%m/%d/%Y",
        "%b %d, %Y",
        "%B %d, %Y",
    ]
    for pattern in direct_patterns:
        try:
            parsed = datetime.strptime(raw, pattern)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            delta = reference - parsed.astimezone(timezone.utc)
            return round(delta.total_seconds() / 3600, 2), False
        except ValueError:
            continue

    relative_match = re.search(r"(\d+(?:\.\d+)?)\s*(hour|hours|hr|hrs|day|days|minute|minutes|min|mins)\s+ago", lowered)
    if relative_match:
        value = float(relative_match.group(1))
        unit = relative_match.group(2)
        if unit.startswith("day"):
            hours = value * 24
        elif unit.startswith("min"):
            hours = value / 60
        else:
            hours = value
        return round(hours, 2), False

    if "yesterday" in lowered:
        return 24.0, False
    if "today" in lowered or "just posted" in lowered or "recently posted" in lowered:
        return 1.0 if "recently posted" not in lowered else None, "recently posted" in lowered

    return None, True


def extract_salary_text(text: str) -> str | None:
    salary_match = re.search(r"(\$\s?\d[\d,]*(?:\s?-\s?\$\s?\d[\d,]*)?(?:\s*(?:per year|yearly|annually|/hr|per hour))?)", text, re.IGNORECASE)
    return salary_match.group(1).strip() if salary_match else None


def extract_work_mode(text: str) -> str | None:
    lowered = text.lower()
    if "remote" in lowered:
        return "remote"
    if "hybrid" in lowered:
        return "hybrid"
    if "onsite" in lowered or "on-site" in lowered:
        return "onsite"
    return None


def extract_sponsorship_text(text: str) -> str | None:
    for match in re.finditer(r"([^.]*sponsorship[^.]*\.)", text, re.IGNORECASE):
        return match.group(1).strip()
    for match in re.finditer(r"([^.]*work authorization[^.]*\.)", text, re.IGNORECASE):
        return match.group(1).strip()
    return None


def keyword_overlap(text: str, keywords: list[str]) -> tuple[list[str], list[str]]:
    lowered = normalize_text(text.replace("/", " "))
    matched: list[str] = []
    missing: list[str] = []
    for keyword in keywords:
        normalized_keyword = normalize_text(keyword.replace("/", " "))
        if normalized_keyword and normalized_keyword in lowered:
            matched.append(keyword)
        else:
            missing.append(keyword)
    return matched, missing


def parse_local_description(description: str, source: str) -> dict[str, str | None]:
    company = "Local Company"
    title = "Local Role"
    location = "Remote"
    employment_type = "Full-time"
    source_url: str | None = None
    posted_at: str | None = None
    posted_at_raw: str | None = None

    for line in description.splitlines():
        lowered = line.strip().lower()
        if lowered.startswith("company:"):
            company = line.split(":", 1)[1].strip() or company
        elif lowered.startswith("title:"):
            title = line.split(":", 1)[1].strip() or title
        elif lowered.startswith("location:"):
            location = line.split(":", 1)[1].strip() or location
        elif lowered.startswith("employment_type:") or lowered.startswith("employment type:"):
            employment_type = line.split(":", 1)[1].strip() or employment_type
        elif lowered.startswith("source url:"):
            value = line.split(":", 1)[1].strip()
            source_url = value or source_url
        elif lowered.startswith("posted_at:") or lowered.startswith("posted at:") or lowered.startswith("dateposted:"):
            value = line.split(":", 1)[1].strip()
            posted_at = value or posted_at
            posted_at_raw = value or posted_at_raw

    # If a file wrote a URL-encoded Source URL, normalize for downstream dedupe/fingerprints.
    if source_url and "%" in source_url:
        try:
            source_url = unquote(source_url)
        except Exception:
            pass

    return {
        "company": company,
        "title": title,
        "location": location,
        "employment_type": employment_type,
        "description": description,
        "source_url": source_url or source,
        "posted_at": posted_at,
        "posted_at_raw": posted_at_raw,
    }


def build_result(
    source_type: SourceType,
    source_url: str,
    company: str,
    title: str,
    location: str,
    employment_type: str,
    posted_at: str | None,
    description: str,
    discovery_method: str,
    *,
    board_name: str | None = None,
    search_query: str | None = None,
    posted_at_raw: str | None = None,
    salary_text: str | None = None,
    work_mode: str | None = None,
    sponsorship_text: str | None = None,
    matched_keywords: list[str] | None = None,
    missing_keywords: list[str] | None = None,
) -> PortalResult:
    posted_age_hours, freshness_unknown = parse_posted_age_hours(posted_at_raw or posted_at)
    canonical_url = canonicalize_url(source_url)
    cleaned_description = description.strip()
    return PortalResult(
        source_type=source_type,
        source_url=canonical_url,
        company=company,
        title=title,
        location=location,
        employment_type=employment_type,
        posted_at=posted_at,
        description=cleaned_description,
        discovered_at=utc_now(),
        discovery_method=discovery_method,
        content_fingerprint=content_fingerprint(company, title, canonical_url, cleaned_description),
        liveness_status=verify_description(cleaned_description),
        board_name=board_name or source_type.value,
        search_query=search_query,
        posted_at_raw=posted_at_raw or posted_at,
        posted_age_hours=posted_age_hours,
        salary_text=salary_text or extract_salary_text(cleaned_description),
        work_mode=work_mode or extract_work_mode(" ".join([location, cleaned_description])),
        sponsorship_text=sponsorship_text or extract_sponsorship_text(cleaned_description),
        matched_keywords=list(matched_keywords or []),
        missing_keywords=list(missing_keywords or []),
        freshness_unknown=freshness_unknown,
    )
