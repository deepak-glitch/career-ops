from __future__ import annotations

from abc import ABC, abstractmethod

from job_search_command_center.engine.types import PortalResult


class PortalAdapter(ABC):
    name: str

    @abstractmethod
    def fetch(self, source: str) -> list[PortalResult]:
        raise NotImplementedError

    def search(self, query: str, limit: int = 20, inputs_dir: str | None = None) -> list[PortalResult]:
        raise NotImplementedError(f"{self.name} does not implement search()")
