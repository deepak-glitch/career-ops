from __future__ import annotations

import json
from pathlib import Path

from job_search_command_center.engine.projections import build_pipeline_md, build_scan_history_tsv, build_tracker_md
from job_search_command_center.engine.store import FileStore
from job_search_command_center.engine.types import ArtifactKind, OfferRecord, OfferState, ValidationError


LEGAL_PREDECESSORS: dict[OfferState, set[OfferState]] = {
    OfferState.DISCOVERED: set(),
    OfferState.VERIFIED: {OfferState.DISCOVERED},
    OfferState.QUEUED: {OfferState.VERIFIED},
    OfferState.EVALUATED: {OfferState.QUEUED, OfferState.VERIFIED},
    OfferState.PACKET_READY: {OfferState.EVALUATED},
    OfferState.APPLIED: {OfferState.PACKET_READY},
    OfferState.RESPONDED: {OfferState.APPLIED},
    OfferState.INTERVIEW: {OfferState.RESPONDED, OfferState.APPLIED},
    OfferState.OFFER: {OfferState.INTERVIEW},
    OfferState.REJECTED: {OfferState.APPLIED, OfferState.RESPONDED, OfferState.INTERVIEW},
    OfferState.ARCHIVED: {OfferState.DISCOVERED, OfferState.VERIFIED, OfferState.EVALUATED, OfferState.PACKET_READY, OfferState.REJECTED},
}


def _load_offers_with_issues(store: FileStore) -> tuple[list[OfferRecord], list[str]]:
    offers: list[OfferRecord] = []
    issues: list[str] = []
    for path in sorted(store.offers_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            offers.append(OfferRecord.from_dict(data))
        except Exception as exc:
            issues.append(f"Malformed offer file: {path.name} ({exc})")
    return offers, issues


def run_integrity_check(root: Path) -> list[str]:
    store = FileStore(root)
    offers, issues = _load_offers_with_issues(store)

    seen_urls: dict[str, str] = {}
    seen_fingerprints: set[tuple[str, str, str]] = set()
    for offer in offers:
        if offer.source_url in seen_urls and offer.state != OfferState.ARCHIVED:
            issues.append(f"Duplicate active source_url for {offer.job_id} and {seen_urls[offer.source_url]}")
        seen_urls[offer.source_url] = offer.job_id

        fingerprint_key = (offer.company.lower(), offer.title.lower(), offer.content_fingerprint)
        if fingerprint_key in seen_fingerprints and offer.state != OfferState.ARCHIVED:
            issues.append(f"Duplicate active fingerprint for {offer.job_id}")
        seen_fingerprints.add(fingerprint_key)

        if offer.state == OfferState.PACKET_READY:
            if not offer.artifact_manifest.get(ArtifactKind.APPLY_PACK_JSON):
                issues.append(f"Missing apply-pack JSON artifact for {offer.job_id}")
            if not offer.artifact_manifest.get(ArtifactKind.RESUME_PDF):
                issues.append(f"Missing resume PDF artifact for {offer.job_id}")

        for artifact in offer.artifact_manifest.items:
            artifact_path = root / artifact.path
            if not artifact_path.exists():
                issues.append(f"Missing artifact file for {offer.job_id}: {artifact.path}")

    expected_tracker = build_tracker_md(root, offers)
    if store.tracker_path.exists() and store.tracker_path.read_text(encoding="utf-8") != expected_tracker:
        issues.append("tracker.md is out of sync with canonical offer files")

    expected_pipeline = build_pipeline_md(offers)
    if store.pipeline_path.exists() and store.pipeline_path.read_text(encoding="utf-8") != expected_pipeline:
        issues.append("pipeline.md is out of sync with canonical offer files")

    expected_scan = build_scan_history_tsv(offers)
    if store.scan_history_path.exists() and store.scan_history_path.read_text(encoding="utf-8") != expected_scan:
        issues.append("scan-history.tsv is out of sync with canonical offer files")

    return issues


def rebuild_projections(root: Path) -> None:
    FileStore(root).rebuild_projections()
