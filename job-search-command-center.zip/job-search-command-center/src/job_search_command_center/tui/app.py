from __future__ import annotations

import os
from pathlib import Path

from job_search_command_center.engine.store import FileStore
from job_search_command_center.engine.types import OfferState


class DashboardApp:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.store = FileStore(root)
        self.filter_state: str | None = None

    def _clear(self) -> None:
        os.system("cls" if os.name == "nt" else "clear")

    def _render(self) -> None:
        offers = self.store.list_offers()
        if self.filter_state:
            offers = [offer for offer in offers if offer.state.value == self.filter_state]
        self._clear()
        print("Job Search Command Center")
        print("=" * 60)
        print(f"Project root: {self.root}")
        print(f"Offers loaded: {len(offers)}")
        print(f"Filter: {self.filter_state or 'all'}")
        print("")
        print("Job ID                              State         Score  Company | Role")
        print("-" * 100)
        for offer in offers[:15]:
            score = f"{offer.scorecard.weighted_score:.2f}" if offer.scorecard else "-"
            print(f"{offer.job_id[:34]:34}  {offer.state.value[:12]:12}  {score:5}  {offer.company} | {offer.title}")
        if not offers:
            print("No offers available.")
        print("")
        print("Commands: [enter] refresh, filter <state>, clear, state <job_id> <state>, open <job_id>, retry, quit")

    def _open_offer(self, job_id: str) -> None:
        offer = self.store.ensure_offer_exists(job_id)
        print("")
        print(f"{offer.company} | {offer.title}")
        print(f"State: {offer.state.value}")
        print(f"URL: {offer.source_url}")
        print(f"Artifacts: {[item.path for item in offer.artifact_manifest.items]}")
        input("\nPress Enter to continue...")

    def _set_state(self, job_id: str, state_value: str) -> None:
        offer = self.store.ensure_offer_exists(job_id)
        offer.state = OfferState(state_value)
        self.store.save_offer(offer)
        self.store.rebuild_projections()

    def run(self) -> None:
        while True:
            self._render()
            command = input("> ").strip()
            if not command:
                continue
            if command == "quit":
                break
            if command.startswith("filter "):
                self.filter_state = command.split(" ", 1)[1].strip()
                continue
            if command == "clear":
                self.filter_state = None
                continue
            if command.startswith("open "):
                self._open_offer(command.split(" ", 1)[1].strip())
                continue
            if command.startswith("state "):
                _, job_id, state_value = command.split(" ", 2)
                self._set_state(job_id, state_value)
                continue
            if command == "retry":
                print("Use `job-center batch run` to retry eligible queued or verified offers.")
                input("\nPress Enter to continue...")
