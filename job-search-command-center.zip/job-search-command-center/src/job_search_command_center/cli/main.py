from __future__ import annotations

import argparse
from pathlib import Path

from job_search_command_center.engine.pipeline import (
    build_apply_pack,
    build_pdf_artifacts,
    evaluate_offer,
    export_jobs,
    import_candidate_profile,
    run_batch,
    scan_source,
    search_jobs,
    suggested_titles,
    tracker_summary,
)
from job_search_command_center.engine.store import FileStore
from job_search_command_center.integrity.checks import rebuild_projections, run_integrity_check
from job_search_command_center.tui.app import DashboardApp


def _root_from_args(args: argparse.Namespace) -> Path:
    return Path(args.root).resolve()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-center", description="AI job search command center")
    parser.add_argument("--root", default=".", help="Project root directory")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Scan a portal source")
    scan_parser.add_argument("--source", required=True)
    scan_parser.add_argument("--portal", default="generic", choices=["greenhouse", "ashby", "lever", "linkedin", "indeed", "dice", "generic"])

    profile_parser = subparsers.add_parser("profile", help="Profile commands")
    profile_subparsers = profile_parser.add_subparsers(dest="profile_command", required=True)
    profile_import_parser = profile_subparsers.add_parser("import", help="Import resume and personal profile DOCX files")
    profile_import_parser.add_argument("--resume-docx", required=True)
    profile_import_parser.add_argument("--personal-docx", required=True)

    titles_parser = subparsers.add_parser("titles", help="Suggested title commands")
    titles_subparsers = titles_parser.add_subparsers(dest="titles_command", required=True)
    titles_subparsers.add_parser("suggest", help="Show suggested AI job titles")

    search_parser = subparsers.add_parser("search", help="Search commands")
    search_subparsers = search_parser.add_subparsers(dest="search_command", required=True)
    search_run_parser = search_subparsers.add_parser("run", help="Run board discovery and ranking")
    search_run_parser.add_argument("--boards", required=True, help="Comma-separated board list")
    search_run_parser.add_argument("--min-match", type=float, default=70.0)
    search_run_parser.add_argument("--posted-within-hours", type=float, default=24.0)
    search_run_parser.add_argument("--limit-per-board", type=int, default=20)
    search_run_parser.add_argument("--agent", default="codex", choices=["codex", "mock"])

    evaluate_parser = subparsers.add_parser("evaluate", help="Evaluate an offer from job_id, file, or URL")
    evaluate_parser.add_argument("target")
    evaluate_parser.add_argument("--agent", default="codex", choices=["codex", "mock"])

    batch_parser = subparsers.add_parser("batch", help="Batch commands")
    batch_subparsers = batch_parser.add_subparsers(dest="batch_command", required=True)
    batch_run_parser = batch_subparsers.add_parser("run", help="Run batch processing")
    batch_run_parser.add_argument("--parallel", type=int, default=4)
    batch_run_parser.add_argument("--limit", type=int)
    batch_run_parser.add_argument("--agent", default="codex", choices=["codex", "mock"])

    pdf_parser = subparsers.add_parser("pdf", help="PDF commands")
    pdf_subparsers = pdf_parser.add_subparsers(dest="pdf_command", required=True)
    pdf_build_parser = pdf_subparsers.add_parser("build", help="Build resume and cover letter PDFs")
    pdf_build_parser.add_argument("job_id")
    pdf_build_parser.add_argument("--agent", default="codex", choices=["codex", "mock"])
    pdf_build_parser.add_argument("--no-cover-letter", action="store_true")

    apply_parser = subparsers.add_parser("apply-pack", help="Generate application packet")
    apply_parser.add_argument("job_id")
    apply_parser.add_argument("--agent", default="codex", choices=["codex", "mock"])

    jobs_parser = subparsers.add_parser("jobs", help="Job folder export commands")
    jobs_subparsers = jobs_parser.add_subparsers(dest="jobs_command", required=True)
    jobs_export_parser = jobs_subparsers.add_parser("export", help="Export strong-match folders under jobs/<Company>/<job_id>/")
    jobs_export_parser.add_argument("--min-match", type=float, default=70.0)
    jobs_export_parser.add_argument("--limit", type=int)
    jobs_export_parser.add_argument("--force", action="store_true")
    jobs_export_parser.add_argument("--agent", default="codex", choices=["codex", "mock"])

    subparsers.add_parser("tracker", help="Show tracker summary")

    integrity_parser = subparsers.add_parser("integrity", help="Integrity commands")
    integrity_subparsers = integrity_parser.add_subparsers(dest="integrity_command", required=True)
    integrity_subparsers.add_parser("check", help="Check integrity")
    integrity_subparsers.add_parser("rebuild", help="Rebuild generated projections")

    subparsers.add_parser("tui", help="Launch terminal dashboard")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    root = _root_from_args(args)

    if args.command == "scan":
        summary = scan_source(root, args.source, args.portal)
        print(f"Discovered: {summary.discovered}")
        print(f"Verified: {summary.verified}")
        print(f"Duplicates: {summary.duplicates}")
        print(f"Expired: {summary.expired}")
        return 0

    if args.command == "profile" and args.profile_command == "import":
        summary = import_candidate_profile(root, args.resume_docx, args.personal_docx)
        print(f"Candidate profile: {summary.candidate_profile_path}")
        print(f"Search preferences: {summary.search_preferences_path}")
        print(f"Suggested titles: {summary.suggested_titles_path}")
        print(f"Titles imported: {len(summary.suggested_titles)}")
        return 0

    if args.command == "titles" and args.titles_command == "suggest":
        for title in suggested_titles(root):
            print(title)
        return 0

    if args.command == "search" and args.search_command == "run":
        boards = [item.strip() for item in args.boards.split(",") if item.strip()]
        summary = search_jobs(
            root,
            boards=boards,
            min_match=args.min_match,
            posted_within_hours=args.posted_within_hours,
            limit_per_board=args.limit_per_board,
            agent_name=args.agent,
        )
        print(f"Boards: {', '.join(summary.boards)}")
        print(f"Discovered: {summary.discovered}")
        print(f"Unique: {summary.unique}")
        print(f"Fresh matches: {summary.fresh_matches}")
        print(f"Strong matches: {summary.strong_matches}")
        print(f"Tracker: {summary.tracker_path}")
        return 0

    if args.command == "evaluate":
        offer = evaluate_offer(root, args.target, args.agent)
        print(f"Evaluated {offer.job_id} -> {offer.recommendation.value if offer.recommendation else 'unknown'}")
        return 0

    if args.command == "batch" and args.batch_command == "run":
        summary = run_batch(root, parallel=args.parallel, limit=args.limit, agent_name=args.agent)
        print(f"Run: {summary.run_id}")
        print(f"Completed: {len(summary.completed)}")
        print(f"Failed: {len(summary.failed)}")
        if summary.failed:
            for job_id, error in summary.failed.items():
                print(f"- {job_id}: {error}")
        return 0 if not summary.failed else 1

    if args.command == "pdf" and args.pdf_command == "build":
        offer = build_pdf_artifacts(root, args.job_id, args.agent, include_cover_letter=not args.no_cover_letter)
        print(f"Generated PDFs for {offer.job_id}")
        return 0

    if args.command == "apply-pack":
        offer = build_apply_pack(root, args.job_id, args.agent)
        print(f"Generated apply pack for {offer.job_id}")
        return 0

    if args.command == "jobs" and args.jobs_command == "export":
        summary = export_jobs(root, min_match=args.min_match, limit=args.limit, agent_name=args.agent, force=args.force)
        print(f"Jobs root: {summary.jobs_root}")
        print(f"Exported: {len(summary.exported)}")
        if summary.skipped:
            print(f"Skipped: {len(summary.skipped)}")
            for job_id in summary.skipped[:25]:
                print(f"- {job_id}")
        return 0

    if args.command == "tracker":
        store = FileStore(root)
        store.rebuild_projections()
        summary = tracker_summary(root)
        print(f"Total offers: {summary['total']}")
        print(f"Average score: {summary['average_score']}")
        print(f"Tracker: {summary['tracker_path']}")
        for state, count in summary["by_state"].items():
            if count:
                print(f"- {state}: {count}")
        return 0

    if args.command == "integrity":
        if args.integrity_command == "check":
            issues = run_integrity_check(root)
            if not issues:
                print("Integrity check passed.")
                return 0
            print("Integrity issues:")
            for issue in issues:
                print(f"- {issue}")
            return 1
        rebuild_projections(root)
        print("Rebuilt tracker, pipeline, scan history, and summary projections.")
        return 0

    if args.command == "tui":
        DashboardApp(root).run()
        return 0

    parser.error("Unsupported command")
    return 2
