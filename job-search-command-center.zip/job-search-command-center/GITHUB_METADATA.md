# GitHub Metadata

## Repository Name

`job-search-command-center`

## Short Description

Resume-driven local-first AI job search toolkit for importing a candidate profile, ranking jobs, generating tailored resumes, and tracking the application pipeline.

## Topics

- `job-search`
- `resume-builder`
- `resume-tailoring`
- `ats-resume`
- `career-tools`
- `ai-jobs`
- `llm`
- `rag`
- `agentic-ai`
- `python`
- `cli`
- `local-first`

## Suggested Visibility

- `Private` if the repo still contains personal candidate configuration or generated resume artifacts
- `Public` only after replacing personal profile data with sample or sanitized versions
