# Live Shortlist (April 13, 2026)

Fresh or near-fresh public listings reviewed on April 13, 2026 for Deepak's current AI profile.

## Fresh Priority

- UnitedHealth Group — Sr AI or ML Engineer — Remote Nationwide or Hybrid in NJ/MN/DC — Dice — Posted `Today`
  Link: https://www.dice.com/jobs/q-%28%22AI%20Engineer%22%20OR%20%22Machine%20Learning%20Engineer%22%20OR%20%22-jobs
  Notes: Strong healthcare alignment, remote or hybrid flexibility, salary range shown, but more senior than ideal.

- Serval — Applied AI Engineer — San Francisco — Ashby — Crawled `Today`
  Link: https://jobs.ashbyhq.com/Serval/2bfaede4-22b2-43b2-a14c-f45e5f398624/
  Notes: Strong agentic AI, production deployment, evaluation, and platform fit. Main downside is onsite San Francisco.

- hackajob / American Express — Senior AI Engineer / Applied ML Engineer / LLM Engineer — United States — LinkedIn — Posted `1 day ago`
  Link: https://www.linkedin.com/jobs/view/senior-ai-engineer-applied-ml-engineer-llm-engineer-at-hackajob-4382234928
  Notes: Strong LLM and applied ML fit, but clearly senior.

- VDart — Senior AI Engineer, Generative AI & Agentic Systems — New York, NY — Dice — Posted `Yesterday`
  Link: https://www.dice.com/jobs/q-%28%22AI%20Engineer%22%20OR%20%22Machine%20Learning%20Engineer%22%20OR%20%22-jobs
  Notes: Strong agentic systems and RAG fit. Likely contract and senior.

- Miracle Software Systems — Generative AI Engineer — Dearborn, MI — Dice — Posted `Yesterday`
  Link: https://www.dice.com/jobs/q-%28%22AI%20Engineer%22%20OR%20%22Machine%20Learning%20Engineer%22%20OR%20%22-jobs
  Notes: Good LLM and RAG architecture match. Hybrid and automotive domain rather than healthcare.

## Strong Fit, Not Fresh 24h

- Acentra Health — Machine Learning Engineer / AI Engineer — Remote — Indeed
  Link: https://www.indeed.com/viewjob?jk=938b987d0727ab49
  Notes: Very strong profile match for healthcare AI, RAG, LLMs, regulated environment, Python, AWS/Azure, and healthcare compliance.

- Pager Health — Applied AI Engineer — Remote — Indeed
  Link: https://www.indeed.com/viewjob?jk=1f140484f5766fbb
  Notes: Excellent healthcare and agentic AI fit with strong role wording around guardrails, observability, orchestration, RAG, and production agents.

- Zapier — Staff Applied AI Engineer, AI Capabilities — Ashby
  Link: https://jobs.ashbyhq.com/zapier/2b57e91a-725f-4e57-aa49-716e0f26eead/
  Notes: Strong platform and orchestration fit, but staff level.

- CodeRabbit — Applied AI Engineer — Ashby
  Link: https://jobs.ashbyhq.com/coderabbit/8f17b66f-ea44-4e83-85f6-ef9427d61a01
  Notes: Excellent RAG, generative AI, and multi-step agentic reasoning fit, but hybrid San Francisco and likely more senior expectations.

- WorkOS — Applied AI Engineer — Indeed
  Link: https://www.indeed.com/viewjob?jk=9b505f98eaaa04c3
  Notes: Strong fit for developer tooling, APIs, and AI identity/agent infrastructure. Less healthcare aligned but very strong platform signal.

## Immediate Best Targets

- Acentra Health
- Pager Health
- UnitedHealth Group
- Serval
- Miracle Software Systems

## Notes

- Freshness is board-dependent. Items marked `Today`, `Yesterday`, or `1 day ago` came from public board snippets reviewed on April 13, 2026.
- Some Dice and LinkedIn links above are search-result pages rather than individual detail pages when the direct job-detail URL was not cleanly exposed in public search.
- This shortlist is intentionally deduped at the company-role level for manual review.
