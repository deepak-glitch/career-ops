# Offer Evaluation

**Company:** Miracle Software Systems
**Title:** Generative AI Engineer
**URL:** c:\Users\deepa\OneDrive\Documents\New project\job-search-command-center\fixtures\live_jobs_2026-04-13\miracle_generative_ai_engineer.md
**Recommendation:** Apply
**Match Score:** 76.72/100

## A. Role Summary
Generative AI Engineer at Miracle Software Systems is evaluated against the candidate's applied AI profile and local constraints.

## B. Match And Evidence
The strongest evidence comes from these local candidate sources:
- config/candidate_profile.json
- config/resume_facts.md
- config/proof_bank.md
- config/search_preferences.json

Matched keywords: No high-signal keyword overlap extracted yet.

## C. Level And Growth Strategy
The role is assessed for ownership, seniority fit, and room for expansion.

## D. Compensation And Logistics
Remote and compensation signals are folded into the weighted model without inventing missing numbers.

## E. Personalization And Company Fit
Candidate summary: Applied AI engineer with experience building RAG systems, agentic workflows, predictive ML pipelines, and production-ready APIs across healthcare, enterprise, and multimodal use cases. Currently at Progress Solutions.

## F. Recommendation
Miracle Software Systems | Generative AI Engineer scored 76.72/100 with 1 red-flag signal(s).

### Red Flags
- Listing freshness is ambiguous, so it should not appear in fresh-only views.

## Score Appendix
- Title Alignment: 100.0/100 (16%) - Scored from overlap between the role title and expanded AI, LLM, agentic, platform, and multimodal target titles.
- Professional Keyword Overlap: 56.67/100 (13%) - Measures overlap with professional market language such as RAG, observability, guardrails, vector search, and production deployment.
- Agentic / LLM / RAG Relevance: 89.17/100 (14%) - Rewards explicit references to agentic workflows, LLM application work, retrieval, structured outputs, and evaluation.
- Domain Relevance: 45.83/100 (8%) - Looks for healthcare, applied AI, SaaS, consulting, and related domain signals from the candidate profile.
- Seniority Fit: 75.0/100 (8%) - Balances target scope against current years of experience while strongly discounting junior or internship roles.
- Location / Work Mode Fit: 75.0/100 (8%) - Scores remote, hybrid, and relocation-compatible roles higher than ambiguous or restrictive setups.
- Compensation Fit: 60.0/100 (6%) - Uses visible compensation language as a soft quality signal rather than inventing missing salary data.
- Sponsorship Risk: 90.0/100 (9%) - Penalizes roles that explicitly reject sponsorship or impose work-authorization constraints.
- Evidence Strength: 100.0/100 (12%) - Estimates how strongly the resume facts and proof bank support claims needed for the role.
- Freshness Bonus: 25.0/100 (6%) - Boosts listings posted within the last 24 hours and discounts stale or ambiguous postings.
