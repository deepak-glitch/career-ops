# Offer Evaluation

**Company:** Greenhouse Company
**Title:** Applied AI Engineer
**URL:** https://job-boards.greenhouse.io/example/jobs/1001
**Recommendation:** Apply
**Match Score:** 73.91/100

## A. Role Summary
Applied AI Engineer at Greenhouse Company is evaluated against the candidate's applied AI profile and local constraints.

## B. Match And Evidence
The strongest evidence comes from these local candidate sources:
- config/candidate_profile.json
- config/resume_facts.md
- config/proof_bank.md
- config/search_preferences.json

Matched keywords: No high-signal keyword overlap extracted yet.

## C. Level And Growth Strategy
The role is assessed for ownership, seniority fit, and room for expansion.

## D. Compensation And Logistics
Remote and compensation signals are folded into the weighted model without inventing missing numbers.

## E. Personalization And Company Fit
Candidate summary: Applied AI engineer with experience building RAG systems, agentic workflows, predictive ML pipelines, and production-ready APIs across healthcare, enterprise, and multimodal use cases. Currently at Progress Solutions.

## F. Recommendation
Greenhouse Company | Applied AI Engineer scored 73.91/100 with no blocking red flags.

### Red Flags
- None

## Score Appendix
- Title Alignment: 100.0/100 (16%) - Scored from overlap between the role title and expanded AI, LLM, agentic, platform, and multimodal target titles.
- Professional Keyword Overlap: 45.83/100 (13%) - Measures overlap with professional market language such as RAG, observability, guardrails, vector search, and production deployment.
- Agentic / LLM / RAG Relevance: 67.5/100 (14%) - Rewards explicit references to agentic workflows, LLM application work, retrieval, structured outputs, and evaluation.
- Domain Relevance: 35.0/100 (8%) - Looks for healthcare, applied AI, SaaS, consulting, and related domain signals from the candidate profile.
- Seniority Fit: 75.0/100 (8%) - Balances target scope against current years of experience while strongly discounting junior or internship roles.
- Location / Work Mode Fit: 95.0/100 (8%) - Scores remote, hybrid, and relocation-compatible roles higher than ambiguous or restrictive setups.
- Compensation Fit: 60.0/100 (6%) - Uses visible compensation language as a soft quality signal rather than inventing missing salary data.
- Sponsorship Risk: 90.0/100 (9%) - Penalizes roles that explicitly reject sponsorship or impose work-authorization constraints.
- Evidence Strength: 100.0/100 (12%) - Estimates how strongly the resume facts and proof bank support claims needed for the role.
- Freshness Bonus: 40.0/100 (6%) - Boosts listings posted within the last 24 hours and discounts stale or ambiguous postings.
