# Apply Pack

**Job ID:** greenhouse-company-applied-ai-engineer-7edb66ac2a5d5940
**Company:** Greenhouse Company
**Title:** Applied AI Engineer

## Checklist
- Review the tailored resume PDF for tone and wording.
- Confirm work authorization language matches the application form.
- Use the answer pack for free-text fields, then manually review before submitting.

## Suggested Answers
### Why are you interested in this role?
I am interested in the Applied AI Engineer role at Greenhouse Company because it lines up with my background in applied AI, workflow automation, and product-minded engineering. The role scored 3.57/5 in my pipeline because the JD overlaps with the systems work I already do.

### Why are you a fit?
My background combines Python delivery, AI workflow design, and hands-on ownership from idea to shipped artifact. I am strongest when the work needs both technical execution and pragmatic product judgment.

### Anything else we should know?
I prefer roles with strong remote collaboration habits and clear ownership. My source materials for this application live in config/candidate_profile.json, config/resume_facts.md, config/proof_bank.md.

## Source Citations
- config/candidate_profile.json
- config/resume_facts.md
- config/proof_bank.md
