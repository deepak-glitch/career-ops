# Pipeline

## Inbox
- unstructured-technologie-ai-engineer-public-sector-3afb94e3b77bf9cf | Unstructured Technologies Inc. | AI Engineer - Public Sector | verified | 81.01%

## In Progress
- greenhouse-company-applied-ai-engineer-7edb66ac2a5d5940 | Greenhouse Company | Applied AI Engineer | evaluated | 73.91%
- greenhouse-company-junior-qa-engineer-e9d0f74ef7a5bc74 | Greenhouse Company | Junior QA Engineer | evaluated | 44.13%
- pager-health-applied-ai-engineer-5c3d5cf617feb0a8 | Pager Health | Applied AI Engineer | evaluated | 82.11%
- miracle-software-systems-generative-ai-engineer-52615aac8c720555 | Miracle Software Systems | Generative AI Engineer | evaluated | 76.72%
- acentra-health-machine-learning-engineer-ai-eng-0b659d4955cb6a18 | Acentra Health | Machine Learning Engineer / AI Engineer | evaluated | 74.58%
- mlabs-applied-ai-engineer-353d0437fdaa4adb | MLabs | Applied AI Engineer | evaluated | 71.87%
- serval-applied-ai-engineer-88225cc9362586be | Serval | Applied AI Engineer | evaluated | 71.57%
- workos-software-engineer-applied-ai-4ef5fe2fb5c3e462 | WorkOS | Software Engineer, Applied AI | evaluated | 56.97%
- unitedhealth-group-sr-ai-or-ml-engineer-b91f4e31b010967f | UnitedHealth Group | Sr AI or ML Engineer | evaluated | 47.11%

## Closed
- None
