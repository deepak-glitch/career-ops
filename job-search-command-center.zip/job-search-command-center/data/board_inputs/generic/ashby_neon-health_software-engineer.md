Company: Neon Health
Title: Software Engineer
Location: United States, United States
employment_type: FULL_TIME
Source URL: https://jobs.ashbyhq.com/neon-health/eb5b50a9-5cb6-4d1b-828e-189286f63320

JD Extract:
TLDR
You'll be hands-on in improving the real-world behavior of our AI systems — tracing and fixing runtime issues, building agent simulators, designing LLM evals and QA tools, and interfacing with client data. This is a role for builders who like prompt-level debugging, LLM system testing, and building infrastructure that improves our AI agents’ performance.
About us: join the team making life-saving drugs accessible
The crisis: Sarah delayed cancer treatment for weeks facing $30,000 monthly costs. Marcus's autoimmune condition worsened while battling insurance denials.
Over 50% of critical prescriptions are abandoned due to:
Cost barriers: Patients with high copays are 5x more likely to abandon treatment
Insurance maze: Complex prior authorizations block access
Logistical challenges: Coordinating medical visits for treatments
Our solution: Neon's technology eliminates these obstacles by automating patient access workflows for pharma companies: —automating authorizations, streamlining benefits verification, and unlocking financial assistance.
Join our mission: We want to live in a world where every patient can navigate the healthcare system with ease, especially when it matters most. Help us ensure that access to medicine is determined by clinical need—not bureaucracy or financial constraint. When Neon succeeds, patients access life-saving treatments without bankrupting their families, while we build an AI automation powerhouse serving healthcare's biggest enterprises.
Why join Neon
Frighteningly ambitious: We’re not just idealists. We’re seasoned builders. On a mission to build a $200B+ company—on the scale of Palantir or ServiceNow—serving the largest healthcare enterprises.
Experienced founding team: Built by exited founders, YC & MIT alum , ex-Tesla, ex-Google engineers.
Hypergrowth with stability: We went from initial idea to 7+ figure customer contracts in just 4 months—in an industry where sales cycles typically take 12-18 months. We are profitable and relentlessly focused on execution.
Powerhouse backing: We’re funded by elite Silicon Valley VCs who've backed unicorns like DoorDash, Lyft, and Mammoth Biosciences. And strategic healthcare investors with deep industry connections.
Outsized impact & opportunity: Work at the intersection of agentic AI, healthcare transformation, and life-changing patient outcomes.
Career acceleration: Join early and grow rapidly with us as we scale toward category dominance in healthcare automation.
What’s unique about working here
Mission-driven capitalists
We’re a rare blend of mission-driven capitalists. We are on the path towards building a $200B+ business while dramatically improving the healthcare system—and patients’ lives.
Working like athletes
Like athletes, we are constantly honing our craft to produce our best possible work.
We work with intention and humility. We support and challenge each other to be our best selves.
And as a team, we achieve goals together that would be impossible alone.
Frequent offsites
We spend one week every month offsite in beautiful places like Tahoe, Squamish, Mendocino, the Santa Cruz mountains, and Monterrey. We ship an incredible amount of product on these offsites. And we have a blast — climbing, swimming, surfing, and otherwise enjoying these beautiful places.
Rediscover the magic of coding late into the night, in the zone. Side by side with a team that—through their example of excellence—is inspiring you to reach your potential.
It’s not for everyone.
But if you long for an intense camaraderie that you can’t find elsewhere, then Neon is the place for you.
The role: Software Engineer
What You’ll Do
You’ll work across our AI agent platform — writing prompts, debugging runtime issues, building agent simulation tooling, creating evals, interfacing with client data, and helping us monitor system behavior at scale.
This is not a model training role — it's an applied systems position focused on behavior , infrastructure , and debugging real-world agents in production.
You will be working at the forefront of agentic AI, where you’ll be pushing the boundaries of our agents’ capabilities.
Some examples of what you might work on:
Trace and fix runtime bugs, then write regression tests.
Design evaluation datasets to simulate realistic workflows or red-team our system.
Build internal tooling for QA and agent simulation.
Normalize and transform messy client data for system integration.
Set up automatic testing and latency tracking infrastructure.
Create dashboards and observability tooling for agentic system behavior.
Expand on our existing eval & testing framework and agent simulation infrastructure.
Skills Required
Technical Skills
Proficiency in TypeScript
Strong generalist software engineer
Strong debugging skills. ****You can trace runtime failures, dig through logs, and pinpoint issues in async or multi-step agent systems.
Data transformation and ingestion. You can build pipelines to normalize and convert unstructured data for use in AI systems.
Strong understanding of system design , including distributed systems and reliability/performance tradeoffs
Experience using modern AI coding tools (e.g. Cursor, GitHub Copilot, Claude)
Excellent documentation and testing discipline
Proficiency with Git
Soft Skills
You care about improving agent behavior. This is an applied systems position focused on behavior , infrastructure , and debugging real-world agents in production. You will be working at the forefront of agentic AI, where you’ll be pushing the boundaries of our agents’ capabilities.
You’re high agency. AKA “agentic” ;) You can thrive with minimal structure. You are internally motivated. You proactively seek out ways to create value for your team.
You don’t mind getting in the weeds. Improving agent performance requires diving deep into the details: identifying and understanding real-world edge cases, editing prompts to address them, and writing evals to cover them in the future. Sound exciting You’ll thrive. Sound tedious You won’t.
You’re comfortable with ambiguity. You work well when specs are loose, or when the solution space spans prompts, code, and even a little RLHF.
You learn fast and move fast. You can pattern-match from past systems work and adapt to LLM-specific edge cases quickly.
Experience & Who Should Apply
We're looking for engineers with 2-7 years of experience who have worked closely with LLMs or AI agents in production systems . This is not a model R&D role — it’s about applying AI

