Company: MLabs
Title: Applied AI Engineer
Location: New York, NY (On-site, 5 days/week)
employment_type: Full-time
Source URL: https://www.indeed.com/viewjob?jk=cdf03433f474dd6a

Applied AI Engineer role in healthcare and life sciences with LLMs and machine learning for production use cases. Responsibilities include end-to-end AI augmentation and automation, data extraction, summarization, reference-based search and question answering, process outcome prediction, and building multi-modal model-powered bots and agents. The role asks for Python, React, TypeScript, PostgreSQL, Kubernetes, experimentation and evaluation systems, strong ownership, and cross-functional product delivery. Visa sponsorship is available.
