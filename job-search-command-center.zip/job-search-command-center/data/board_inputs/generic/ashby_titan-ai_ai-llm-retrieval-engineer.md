Company: Titan AI
Title: AI LLM Retrieval Engineer
Location: United States
employment_type: FULL_TIME
Source URL: https://jobs.ashbyhq.com/titan-ai/2bd78c4f-6cea-44a2-977b-32b4147a2e8d

JD Extract:
Titan is building the AI platform for banking – creating the models and agents that will define the industry. Led by a team of former CTOs with multiple exits, we're seeking an AI LLM Retrieval Engineer to join our team building the data and retrieval backbone for autonomous banking and fintech.
What you'll do
Architect and maintain client-specific and internal RAG pipelines, including embedding generation, document chunking, and metadata tagging
Collaborate directly with enterprise clients to assess data landscapes, retrieval requirements, and grounding needs
Select, test, and optimize embedding models (text, multimodal) for accuracy and efficiency
Design retrieval strategies (dense, sparse, hybrid) to maximize precision and recall
Establish and monitor evaluation metrics for retrieval performance (e.g., recall@k, MRR, nDCG)
Align retrieval structure, granularity, and metadata with reasoning workflows
Maintain documentation, schemas, and retrieval guidelines for internal and client teams
Stay current with advancements in vector databases, embedding models, and retrieval frameworks
Required qualifications
Proven track record building and optimizing retrieval systems in production
Deep understanding of embedding models, indexing strategies, and ANN search
Experience with vector DBs (e.g., Pinecone, Weaviate, Milvus, Vespa, FAISS)
Strong proficiency in Python and familiarity with RAG frameworks (LangChain, LlamaIndex, Haystack)
Knowledge of relevance tuning, hybrid search, and retrieval evaluation
Experience working with graph databases (Neo4J, ArangoDB)
Strong communication skills for technical and client-facing collaboration
What we offer
Competitive compensation (salary + meaningful, pre-Series A equity)
Remote-first culture with opportunity for in-person collaboration
Unlimited PTO
Medical, dental, and vision coverage (100% of employee premiums paid by Titan)
Why Titan
We're building the AI platform for banking because many of the two million people employed by 4,000+ banks in the United States cannot safely and securely use bleeding edge AI tools at work. Moreover, none of them are using AI tools purpose-built for banking in their daily workflows. We are changing that.
We are creating secure, bank-native AI infrastructure and applications that meet the needs of modern banking and financial services. Our platform includes:
Titan Foundry: Secure gateway to top AI models for bank employees
Banking-Reasoning Models: Our flagship small language models purpose-built for financial services, trained by ex-regulators and banking leaders
Banking Agents: Configurable AI application layer with expertise in lending, compliance, underwriting, and operations
Our small team consists of former founders, CTOs, engineers, operators, and regulators from places like Goldman Sachs, KeyBank, and the Office of the Comptroller of the Currency. We have built and sold companies to top 25 U.S. banks.
If you’re a high-agency individual who loves tackling complex problems in an emerging space, we want to hear from you!
