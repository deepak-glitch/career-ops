Company: Pearl Health
Title: Senior Software Engineer (Applied AI)
Location: United States
employment_type: FULL_TIME
Source URL: https://jobs.ashbyhq.com/pearlhealth/1b46281e-e85c-409e-afaa-4daa28b1eee2/

JD Extract:
The Opportunity
As a Senior Software Engineer (Applied AI), you will play a critical hands-on role in building the AI-powered intelligence layer of the Pearl platform. You will design and implement Applied AI features, including RAG pipelines, Agentic workflows, and LLM integrations, while ensuring these capabilities are delivered through scalable, production-grade services. If you are passionate about turning cutting-edge AI into real products that drive better health outcomes for thousands of providers and their patients, this role could be a great fit.
Who We Are
Pearl Health is dedicated to empowering primary care providers, health systems, and physician-led networks to succeed in the shift to value-based care. Our platform delivers the technology, financial tools, and expert services that enable practices to provide more proactive, effective care to their Medicare patients, ultimately lowering costs and improving health outcomes.
Founded in 2020, we are a team of healthcare and technology innovators backed by premier investors like Andreessen Horowitz, Viking Global Investors, and AlleyCorp. We partner with thousands of providers across 44 states to build a more sustainable future for American healthcare.
What You'll Do
Applied AI & Full-Stack Engineering
Design, build, and own production AI features powered by LLMs, including RAG architectures (chunking strategies, semantic search, vector databases) and Agentic workflows.
Develop high-performance data pipelines, APIs, and microservices that process healthcare data at scale and securely integrate LLM outputs into user-facing experiences.
Execute Proof-of-Concepts (POCs) and technical evaluations of new AI technologies to validate product viability and scalability.
Build responsive web applications using modern frontend frameworks to deliver intuitive, user-facing intelligence and analytic features.
Ensure observability, monitoring, and operational excellence for AI-powered services, championing security and regulatory compliance (HIPAA, SOC2).
Technical Leadership & Collaboration
Drive architectural decisions and system optimizations for AI features in close collaboration with product and engineering leadership.
Own technical projects from discovery to delivery with autonomy, ensuring solutions align with business needs and long-term scalability.
Mentor and upskill fellow engineers on Applied AI best practices, fostering a strong culture of technical excellence and collaborative growth.
Contribute to the team's understanding of LLM capabilities, limitations, and best practices within the healthcare domain.
Participate in thorough design and code reviews, raising the bar for technical quality across the team.
Delivery & Impact
Own and deliver complex technical projects with autonomy and accountability, ensuring successful delivery aligned with business timelines.
Identify and help resolve technical bottlenecks and cross-team dependencies that impact delivery velocity or system reliability.
Balance speed and quality, making pragmatic decisions that enable rapid iteration while maintaining engineering excellence.
What You'll Bring
You are an experienced engineer who combines strong full-stack fundamentals with hands-on Applied AI experience. You're excited to build production AI systems in a fast-moving healthcare environment and to elevate the capabilities of the team around you.
Must-Haves
5+ years of professional experience in software engineering, with a strong foundation in service-oriented architectures and distributed systems.
Hands-on experience building and productionizing Applied AI/LLM features, including working with RAG architectures, vector databases, embedding models, and/or Agentic workflows.
Experience with observability and evaluation practices for production LLM systems (prompt tracking, quality metrics, cost monitoring)
Strong proficiency in Python, relational databases, and a major cloud platform (AWS preferred).
A deep understanding of modern service design principles, including RESTful and event-driven architectures.
Proven experience designing, building, and optimizing data-intensive applications.
A demonstrated history of mentoring engineers and driving technical best practices within a team.
A strong background in performance optimization, reliability engineering, and security best practices.
Nice-to-Haves
Experience building and deploying user-facing client applications using modern frameworks (e.g., React, Angular, Vue.js, TypeScript).
A background working in healthcare technology, fintech, or another highly regulated industry.
Familiarity with compliance and security frameworks such as HIPAA or SOC2.
This role might not be for you if:
You are primarily interested in academic AI research or fundamental model training, rather than the hands-on productization and deployment of AI features.
Your career preference is to specialize deeply in only one area of the stack (pure frontend or pure backend) and not apply expertise across a full-stack context.
You thrive most in a highly structured corporate environment with top-down decision-making and minimal ambiguity.
Our Values
Collaborate to Innovate: We believe the best solutions arise from intelligent teamwork. We trust the expertise of our teammates and pursue opportunities to learn and grow from each other. By embracing diverse perspectives and encouraging authenticity, we create and evangelize groundbreaking health solutions.
Trust Through Transparency: We prioritize transparency in all our interactions, ensuring that employees, patients, clinicians and partners have access to the information they need to make informed decisions. Integrity is at the core of how we operate, from building products to fostering relationships, and is crucial to our ability to communicate openly and gain trust.
Serious Impact, Big Heart: We go above and beyond with our efforts to empower proactive, patient-centered care — and we celebrate every step forward. Humor and positivity fuel our creativity, strengthen relationships, and remind us to acknowledge the journey as much as the destination.
We are an Equal Opportunity Employer on a mission to improve lives. Our strength comes from the diverse backgrounds, experiences, and perspectives of our team. We welcome all candidates and are committed to a fair, inclusive hiring process free from discrimination.
What We Offer
The expected offer for this role includes the following components:
Base Salary Range: $130,000 - $200,000

