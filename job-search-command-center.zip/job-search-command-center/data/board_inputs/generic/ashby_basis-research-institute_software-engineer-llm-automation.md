Company: Basis Research Institute
Title: Software Engineer, LLM & Automation
Location: New York, New York, United States
employment_type: CONTRACTOR
Source URL: https://jobs.ashbyhq.com/basis-research/1ff60bf9-64de-4d87-b801-3b91d9b93216/

JD Extract:
About Basis
Basis is a nonprofit applied AI research organization with two mutually reinforcing goals.
The first is to understand and build intelligence. This entails establishing the mathematical principles of reasoning, learning, decision-making, understanding, and explaining, and constructing software that embodies these principles.
The second is to advance society’s ability to solve intractable problems. This involves expanding the scale, complexity, and breadth of problems we can solve today and, more importantly, accelerating our ability to solve problems in the future.
To achieve these goals, we are building both a new technological foundation inspired by human reasoning, and a new type of collaborative organization that prioritizes human value.
About the Role
We’re seeking Software Engineers to develop scalable systems that integrate large language models (LLMs) with our everyday operational workflows. This role involves designing and deploying automated “pipelines” for tasks like recruiting, finance, and project management—often powered by GPT, Claude, or similar LLMs. We’re flexible on your arrangement: we’re hiring contractors , part-time , or full-time teammates.
Core Responsibilities
Architect and maintain automation pipelines combining internal tools with GPT/Claude and other LLMs
Integrate data across third-party APIs (e.g., ATS platforms, Slack, Google) into unified, automated workflows
Leverage structured generation (JSON schemas, function calling, etc.) to ensure robust, correct LLM outputs
Collaborate with Ops and R&D to identify high-impact automation opportunities
Write production-grade code, with emphasis on modularity, reliability, and error handling
Deploy, scale, and optimize your solutions in a secure, cloud-based environment
Document solutions for both technical and non-technical audiences, ensuring easy updates and maintenance
Qualifications and Attributes
We’re looking for individuals who:
Have experience programming in Julia and/or Python (3+ years of production-level coding, or equivalent)
Understand how to integrate LLMs using structured prompts, scaffolding frameworks (LangChain-like), or advanced text generation approaches
Can handle concurrency, scaling, and performance optimizations in real-world deployments
Are comfortable with complex API orchestration: dealing with rate limits, OAuth, error retries, etc.
Have good collaboration and communication skills, especially when gathering requirements from non-technical staff
Are flexible and creative problem solvers, comfortable with iterative, experimental development cycles
Embrace data-security best practices (e.g., handling PII, encryption, secrets management)
Are excited to learn quickly and adapt to new developments in the LLM/AI ecosystem
Technical Skills
Preferred (not all required):
Julia : Type-driven or multiple-dispatch approaches; performance tuning, HPC, or scientific computing workflows
Python : Building microservices with FastAPI, Flask, or other frameworks; advanced concurrency (async, multiprocessing)
LLM Tools & Frameworks : Familiarity with LangChain, open source LLM clients, or custom chain-of-thought integrations
Cloud Infrastructure : Docker/Kubernetes, CI/CD pipelines, AWS/GCP/Azure deployment patterns
Distributed Systems & Queues : Experience with concurrent processing, task queues (Celery, Sidekiq), or event-driven systems
Database Interaction : Ability to design schemas and queries in PostgreSQL or similar databases
Security & Privacy : Understanding of OAuth flows, secrets management, data encryption, and role-based access controls
Privacy Notice
By submitting your application, you grant Basis permission to use your materials for both hiring evaluation and recruitment-related research and development purposes. Your information may be processed in different countries, including the US. You retain copyright while providing Basis a license to use these materials for the stated purposes.
Read our full Global Data Privacy Notice here .
