Company: Concentrate AI
Title: AI Engineer
Location: United States, United States
employment_type: FULL_TIME
Source URL: https://jobs.ashbyhq.com/Concentrate%20AI/42e613b8-8532-44f8-ab0e-de18e6fbc2e3

JD Extract:
Concentrate AI provides a unified, OpenAI-compatible API to access, route, and manage LLMs. We save our customers time, cut costs, and reduce risk. We manage high-volume AI traffic and logs.
We’re seed-stage, well-funded, and in stealth. This role is fully remote.
The Role
Build, run, and debug LLM applications on top of Concentrate. You’ll work on production workloads (customer-facing and internal), stress test the platform, and share feedback and learnings with the product team.
Key Areas of Responsibility:
Build LLM-powered services, workflows, and applications using Concentrate
Integrate with real production applications and environments
Design reliable interactions with LLMs (OpenAI, Anthropic, Gemini, OSS), including prompts, tool calling, evals, and guardrails
Debug failures across models, APIs, and infrastructure
Write code, scripts, and small tools to test system behavior at scale
Reproduce bugs, isolate root causes, and clearly document findings
Drive improvements to APIs, defaults, and overall developer experience
What We’re Looking for
Hands-on experience integrating LLMs via APIs in production
Always building tools, scripts, side projects, or experiments to test ideas and learn fast
Strong Python; TypeScript is a plus
Comfortable with REST APIs, async systems, and production debugging
Curious about model behavior under load, failure, and edge cases
Familiarity with tool calling, agents, multi-step workflows, or MCPs
Strong code quality and technical judgment
Comfortable operating in early-stage environments with speed and ambiguity
Clear async communication (Slack, written updates, concise docs)
Fluent written and verbal English required for documentation, incident response, and technical and business presentations.
Bonus: active open-source contributor
Comp: Base + bonus + meaningful equity
Equal Opportunity & Fair Chance Notice
Concentrate AI is an affirmative action and equal opportunity employer. We are committed to providing equal employment opportunities and do not discriminate in recruiting, hiring, training, promotion, or other employment practices on the basis of race, color, sex, age, religion, national origin, ancestry, protected veteran status, disability, sexual orientation, gender identity or expression, genetic information, or any other status protected by applicable law.
Qualified applicants with arrest and conviction records will be considered in accordance with the San Francisco Fair Chance Ordinance and applicable state and local laws.
California Privacy Notice
California residents may contact privacy@concentrate.ai for additional information regarding how we collect, use, and disclose personal information during the job application process.
Recruitment Agency Notice
Concentrate AI does not accept unsolicited resumes from recruitment agencies and is not responsible for any fees related to unsolicited submissions.
