Company: UnitedHealth Group
Title: Sr AI or ML Engineer
Location: Remote Nationwide or Hybrid in NJ/MN/DC
employment_type: Full-time
Source URL: https://www.dice.com/jobs/q-%28%22AI%20Engineer%22%20OR%20%22Machine%20Learning%20Engineer%22%20OR%20%22-jobs

Senior AI or ML engineering role in healthcare with remote or hybrid flexibility. Public Dice search results indicate a healthcare-oriented AI engineering opportunity with machine learning, production deployment, and enterprise-scale delivery expectations. This role appears more senior than Deepak's current level, but the healthcare domain and likely AI platform or ML systems work make it directionally relevant.
