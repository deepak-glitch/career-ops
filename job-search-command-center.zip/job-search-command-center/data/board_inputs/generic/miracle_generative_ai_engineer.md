Company: Miracle Software Systems
Title: Generative AI Engineer
Location: Dearborn, MI
employment_type: Full-time
Source URL: https://www.dice.com/jobs/q-%28%22AI%20Engineer%22%20OR%20%22Machine%20Learning%20Engineer%22%20OR%20%22-jobs

Generative AI engineering role highlighted in public Dice results. The snippet points to LLMs, prompt engineering, workflow orchestration, RAG systems, multi-agent systems, Docker, Python, LangChain, Hugging Face, and LlamaIndex. This is a good match for Deepak's applied AI and agentic systems profile, though the domain fit is weaker and the job appears less healthcare-focused.
