Company: Ravenna
Title: AI Engineer
Location: Seattle, Washington, United States
employment_type: FULL_TIME
Source URL: https://jobs.ashbyhq.com/ravenna/fdefabaf-0665-407d-a7ac-22b7ee67afaa

JD Extract:
About the Role
At Ravenna, we are looking for experienced engineers with a passion for AI and a strong track record of building and shipping production systems. Our team is combining the latest advances in large language models with proven machine learning techniques to build modern, intelligent product experiences.
This role requires strong engineering fundamentals and a deep curiosity about how AI systems work in practice. You will design, build, and operate LLM powered systems that are reliable, scalable, and deeply integrated into real product workflows.
You will work across the stack. This includes designing AI systems, building backend infrastructure, implementing product features, and iterating quickly based on evaluation and real user feedback. We care deeply about strong engineering practices and expect our AI engineers to think carefully about system design, observability, performance, and reliability.
If you are excited about applying cutting edge AI to disrupt large and established markets, we want to talk to you.
Responsibilities
Build production AI systems
Design and implement systems that integrate LLMs into real product workflows. This includes prompt pipelines, tool integration, structured outputs, and systems that combine models with traditional software components.
Design reliable LLM architectures
Develop robust systems that account for model limitations and failure modes. Build safeguards, retries, evaluation loops, and observability into LLM powered features so they behave reliably in production.
Develop evaluation and experimentation frameworks
Create evaluation datasets and tooling that allow the team to measure model performance, iterate on system design, and prevent regressions as models and prompts evolve.
Build retrieval and knowledge systems
Design and optimize retrieval pipelines that power LLM applications. This includes chunking strategies, indexing approaches, vector search, and improving the quality and speed of knowledge retrieval.
Ship high quality product features
Collaborate with product, design, and engineering teammates to build polished features that leverage AI in ways that feel natural and valuable to users.
Maintain strong engineering standards
Write clean, maintainable, well tested code. Contribute to system architecture, code reviews, and engineering processes that ensure the platform remains reliable and scalable.
About You
Strong engineering fundamentals
You are a strong software engineer first. You have at least five years of experience building production systems and are comfortable designing complex systems that are reliable, maintainable, and scalable.
You think carefully about architecture, testing, observability, performance, and operational reliability.
LLM systems experience
You have built systems around large language models in production environments. You understand that successful AI products require thoughtful system design, not just calling an API.
You have experience designing prompts, managing context, orchestrating tool usage, and improving the reliability of model outputs.
Evaluation mindset
You care deeply about measuring quality. You have experience building evaluation frameworks, designing datasets, and using experiments to guide improvements to prompts, models, and system architecture.
Retrieval and embedding systems
You have experience with retrieval augmented generation systems and understand how retrieval quality affects model performance.
You are comfortable working with embeddings, vector databases, and semantic search, and you understand how these approaches differ from traditional search and indexing systems.
LLM fundamentals
You understand how modern language models work at a conceptual level and can speak about transformers, attention mechanisms, and the tradeoffs between different model architectures.
AI system intuition
You understand the strengths and weaknesses of LLMs in practice. You think about hallucinations, prompt sensitivity, context limits, latency, and cost when designing systems.
Experimentation and iteration
You are comfortable running experiments across prompts, models, and system designs. You use evaluation data and real world feedback to guide improvements.
Benefits
Competitive Salary
We believe great people should be compensated well. While we are an early stage company, we offer competitive salaries and aim to pay top of market for exceptional talent.
We are building an ambitious company and know that attracting great people requires strong compensation.
Meaningful Equity
We hire people who want to help build Ravenna from the ground up. Equity ensures that when the company succeeds, the people who helped build it share in that success.
Early team members have the opportunity to make a real impact on both the product and the future of the company.
Choose Your Setup
Great work requires great tools. At Ravenna you can choose the hardware and setup that helps you do your best work.
Most of the team uses high performance Mac laptops, but you have the flexibility to select the tools and environment that fit your workflow.
Flexible Time Off
Doing great work requires time to recharge. We offer flexible paid time off so you can take the time you need to rest and stay at your best.
We trust our team to manage their time responsibly while delivering meaningful results.
