Company: WorkOS
Title: Software Engineer, Applied AI
Location: Remote - United States
employment_type: Full-time
Source URL: https://www.indeed.com/viewjob?jk=9b505f98eaaa04c3

Applied AI engineering role focused on building production AI capabilities inside a developer platform. The description emphasizes LLM application development, retrieval, agent workflows, tool calling, API integrations, structured outputs, and observability. Strong Python or backend engineering, product ownership, developer tooling, and scalable cloud-native systems are important. The role is less healthcare-specific but strongly aligned with applied AI platform work.
