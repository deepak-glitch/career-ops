Company: Linkedin
Title: Imported Role
Location: Unknown
employment_type: Unknown
Source URL: https://www.linkedin.com/jobs/view/applied-ai-engineer-at-zapier-4354297404

JD Extract:
Zapier hiring Applied AI Engineer in EMEA | LinkedIn Skip to main content LinkedIn Applied AI Engineer in Kent, OH Expand search This button displays the currently selected search type. When expanded it provides a list of search options that will switch the search inputs to match the current selection.
Jobs
People
Learning
Clear text Clear text
Clear text
Clear text Clear text Sign in Join now
Applied AI Engineer Zapier EMEA
Applied AI Engineer
Zapier EMEA 1 month ago Be among the first 25 applicants
See who Zapier has hired for this role
No longer accepting applications
Report this job
AI at Zapier
At Zapier, we build and use automation every day to make work more efficient, creative, and human. So if you’re using AI tools while applying here - that’s great! We just ask that you use them responsibly and transparently .
Check out our guidance on How to Collaborate with AI During Zapier’s Hiring Process , including how to use AI tools like ChatGPT, Claude, Gemini, or others during our hiring process - and when not to.
Hi there!
Zapier is hiring for an Applied AI Engineer to help us build the future of automation with AI at its core. If you care about shipping real products, solving hard problems with large language models, and creating tools that help others build faster—this is your kind of role.
We’re hiring acrossteams, each with their own flavor of AI work. You’ll work on things like shared libraries, evaluation systems, orchestration patterns, or user-facing features—depending on the team. What they all have in common: you’ll ship to production, own meaningful problems, and make an impact across the company.
About You
Even though our job description may seem like we're looking for a specific candidate, the role inevitably ends up tailored to the person who applies and joins. Regardless of how well you feel you fit our description, we encourage you to apply if you meet these criteria:
You have 5+ years of experience in software engineering, with at least 3 of those years dedicated to building distributed, scalable cloud based web applications. You possess strong communication skills, problem-solving abilities, and a drive to deliver outstanding customer experiences for both external users and internal stakeholders.
You have at least 1 year of experience working with large language models (LLMs) to perform complex tasks in production environments. You experimented with build user facing leveraging agent architectures.
You’re familiar with underlying technologies like transformer networks, attention mechanisms, and how they contribute to models’ abilities to generate coherent responses, generate function calls, and perform other language tasks.
You have likely deployed evaluation frameworks for LLMs, with an understanding on performance, reliability, and bias assessment.
You likely have experience with Retrieval-Augmented Generation (RAG) systems and understand how to optimize knowledge retrieval for improved model accuracy and speed. You likely have experience with different indexing and chunking strategies based on the system’s data and goals, as well as semantic search and vector databases, and how they differ from traditional retrieval methods and databases.
You have experience of working through the full lifecycle of building, testing, deploying, and scaling LLM architectures.
You can identify and document trade-offs made during the development process. You also have experience building with cloud infrastructure technologies.
You love shipping to customers. You’ll be on a team focused on understanding customers' needs and translating those needs from specifications into functional, production-ready code. You know how to balance speed versus quality to support the features we build for our customers.
You embody our values. At Zapier, our values are at the heart of how we work together and how we think about our customers. In our remote setting, they help develop trust and ensure we work and collaborate to democratize automation.
Things You’ll Do
You understand that AI-based applications thrive on data-driven feedback loops, which will be central to any system you develop. These loops will capture and instrument user data, synthesize core use cases, and implement/test strategies with LLMs to enhance performance.
You will be responsible for integrating LLMs into software products at Zapier, which will include setting up the necessary infrastructure to ensure performance, scalability, and reliability.
You will work mostly in Python or TypeScript. Experience isn’t strictly required, but it is a big plus. Comfort with typed languages and modern backend practices is a must.
You will build tooling and infrastructure that enables teams to iterate on AI products faster, without sacrificing safety or reliability.
You will improve the state of cost observability across all teams, and work with individual teams to optimize spend for their products.
You will monitor the performance and health of AI systems, proactively detecting and addressing issues such as system failures and performance degradation.
You will collaborate with Data and cross-functional teams to refine and deploy LLM-based features.
If you’re interested in advancing your career at a fast-growing, profitable, impact-driven company, then read on…
Our Commitment to Applicants
Culture and Values at Zapier
Zapier Guide to Remote Work
Zapier Code of Conduct
Diversity and Inclusivity at Zapier
Difference between an Applied AI Engineer and an ML Engineer at Zapier:
How do we discern between other AI-forward engineering roles like ML Engineers and Applied AI Engineers? Both roles benefit from backend engineering skills and experience with LLMs.
ML engineers are expected to have more experience building data pipelines as well as experience utilizing other types of ML models beyond LLMs.
AI engineers are expected to have more full stack engineering experience, which would typically include frontend experience, and may only have experience working with LLMs.
How To Apply
At Zapier, we believe that diverse perspectives and experiences make us better, which is why we have a non-standard application process designed to promote inclusion and equity. We're looking for the best fit for each of our roles, regardless of the type of companies in your background, so we encourage you to apply even if your skills and experiences don’t exactly match the job description. All we ask is that you answer a few in-depth questions in our application

