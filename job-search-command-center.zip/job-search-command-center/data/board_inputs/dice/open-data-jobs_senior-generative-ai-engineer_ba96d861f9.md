Company: OPEN Data Jobs
Title: Senior Generative AI Engineer
Location: Unknown
employment_type: FULL_TIME
posted_at: 2026-03-16T18:43:09.000Z
Source URL: https://www.dice.com/job-detail/b2222bde-732d-4c1e-af78-08ba96d861f9

JD Extract:
Description
Our client is seeking a Senior Generative AI Engineer to drive internal initiatives and provide AI engineering support for a major federal agency. The role centers on developing cloud-native generative AI solutions and intelligent data pipelines on AWS, spanning intelligent document processing, computer vision, and related AI / ML domains, and allows for a remote work arrangement.
The ideal candidate is energized and motivated with an extreme commitment to delivery and transformational change through the use of AI. They will think about generative AI in two dimensions: as a tool that makes them and their team dramatically faster, and as a core component of the intelligent systems they build. They understand that deploying an LLM inside a production workflow is a fundamentally different engineering challenge than using one to write a function, and they have done both. They take initiative without being asked and want ownership of the firm's trajectory, not just their deliverables.
Our client is a Benefit corporation - legally committed to creating measurable social value alongside business performance. They offer mission-driven, technically challenging work on complex federal initiatives, paired with direct client access, real ownership of your work product, and a culture that rewards initiative.
Responsibilities
Client Delivery:
Design and deploy production-grade Agentic AI systems where LLMs serve as operational components to reason, explain, and make decisions within live workflows
Architect intelligent pipelines combining classical tools (OCR, fuzzy matching, structured query) with LLM-based validation, confidence scoring, fallback logic, and automated logging for auditability and continuous improvement
Translate ambiguous mission requirements into well-scoped AI system designs; apply prompt and context engineering, RAG, semantic search, and fine-tuning as appropriate; leverage AWS services including Bedrock, Textract, Lambda, and Step Functions
Use generative AI tooling to accelerate the full development lifecycle: requirements analysis, code generation, test coverage, documentation, and deployment scaffolding
Document and quality-assure all project work prior to client delivery; attend meetings with agency staff, vendors, and external stakeholders as needed
Firm Development:
Lead or contribute to business development, internal tool-building, mentorship, or publication to strengthen the firm's AI capabilities and market position
Requirements
Core Technologies:
AWS Certification required: Certified AI Practitioner, or relevant AWS Associate, Specialist, or Professional-level certification
Hands-on proficiency with AWS tools such as Amazon Bedrock, Textract, Step Functions, Lambda, Glue, CloudFormation, CDK, Cognito and related AWS services
Python fluency including LangChain and AWS Strands; experience with vector databases and embedding workflows
Experience with Model Context Protocol (MCP) to connect LLMs to external tools, APIs, and data sources; ability to design and implement MCP servers and clients in production architectures
Advanced SQL, cloud-native data pipeline management, and ETL workflows
Domain Expertise & Professional Skills:
Expert knowledge of LLM behavior, confidence calibration, evaluation, and responsible AI principles. Knowledge includes explainability, auditability, and governance in regulated environments
Experience with DevSecOps and MLOps: GitHub, CloudFormation, and related tools for version control, CI/CD, pipeline deployments, system and model monitoring, and drift detection
Domain knowledge of federal data environments, government IT modernization, or public sector AI adoption
Excellent written and oral communication skills; proven collaborator in professional or academic settings
Professional Experience:
Bachelor's required, advanced degree preferred; Computer Science, Data Science, AI, Applied Mathematics, Statistics, or related quantitative field strongly preferred
8+ years in software development, ML engineering, or data science; background in computer science or related technical and/or quantitative fields
Multi-modal AI experience (vision, document understanding, structured extraction)
Prior consulting, or client-services experience strongly preferred
Open-source contributions or published GenAI research preferred
Familiarity with OMB AI guidance and the NIST AI Risk Management Framework preferred
U.S. citizenship; ability to obtain a Public Trust suitability determination required
Benefits
Our client offers a comprehensive and competitive benefits package, including:
Full health coverage (medical, dental, and vision) with 100% of employee premiums covered
Life and disability insurance, fully covered by the company
401(k) retirement plan with 100% match on contributions up to 4% of salary with immediate vesting
Unlimited Paid Time Off (PTO) to encourage work-life balance
Remote location acceptable, but greater Washington, DC area preferred; all work conducted within USA
Sponsored AWS certification training
