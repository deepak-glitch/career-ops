Company: Job Boards
Title: Imported Role
Location: Unknown
employment_type: Unknown
Source URL: https://job-boards.greenhouse.io/automatticcareers/jobs/7558576

JD Extract:
Job Application for Applied AI Engineer at Automattic Careers
Applied AI Engineer Remote Apply
Location: Global (Remote or in-person in NYC)
About This Opportunity
We’re looking for exceptional AI engineers who’ve shipped breakthrough products that millions actually use. The kind of people who don’t just integrate APIs, they build features users love.
You’ll work with Automattic’s ecosystem, spanning WordPress.com , WooCommerce , Tumblr , Beeper , Mesh (formerly Clay) , and more. If you’re in NYC, you’ll collaborate in-person with our AI team. If you’re distributed, you’ll work the way Automattic has for 20 years: asynchronously, transparently, with a focus on impact over hours.
This is about working on fascinating problems at scale with the backing of a profitable, mission-driven company. Whether you’re embedding with Other Bets teams, helping existing products leverage AI, or exploring new opportunities with our data and distribution, you’ll have the resources and reach to build things that matter to millions.
Why This Role Matters
Shape how AI transforms products used by hundreds of millions of people across the planet, from helping creators tell better stories to empowering merchants to compete effectively. You’ll tackle fascinating challenges across our entire ecosystem—with the backing of a profitable, mission-driven company.
Whether you're working in-person in NYC or distributed globally, you’ll have the autonomy to focus on high-impact work without the typical constraints of startups (fundraising pressure, runway anxiety) or large tech companies (bureaucracy, slow decision-making).
What You’ll Do
Ship user-facing AI features across Automattic’s product ecosystem; from site building tools to ecommerce recommendations to messaging experiences.
Build and iterate rapidly on AI-powered products that directly impact millions of users.
Collaborate with PMs, designers, and engineers (in-person in NYC or distributed globally) in a fast-paced environment optimized for innovation.
Experiment and scale successful AI innovations from prototype to production across multiple products.
Embed with teams to work on products such as WordPress.com , WooCommerce, Jetpack, Mesh, Beeper, Pocket Casts, etc.
Stay current with AI developments that unlock new user experiences.
You’ll Thrive Here If You
Have shipped AI features that users actually use. Production experience is valued over theoretical knowledge.
Are exceptionally talented. You’re the person other great engineers want to work with.
Are strong across the stack OR deeply expert in your domain. We value both breadth and depth.
Move fast without breaking things. Prototype quickly while building for scale.
Think product-first. You know great AI is invisible to users; it just makes their experience better.
Work well in distributed teams or love in-person collaboration if you’re NYC-based.
Are drawn to working with other exceptional people rather than just seeking comfortable work environments.
Technical Experience We Value
Production experience with LLMs (APIs or custom implementations) at meaningful scale.
Strong full-stack development (we use PHP, TypeScript, and React, primarily).
Building AI-powered user interfaces that perform well at scale.
Machine learning fundamentals and staying current with rapid field developments.
Track record of technical leadership or influence on high-performing teams.
Bonus Points
Developed consumer AI products that scaled to a significant numbers of users.
Experience with WordPress, ecommerce,, or messaging platforms.
Open source contributions showing your thinking.
Previous startup experience as a founder or early engineer.
Based in NYC or willing to relocate (strong preference, but not required).
Salary range: $70,000 to $170,000 USD . Please note that salary ranges are global, regardless of location, and we pay in local currency.
We are searching for high-caliber candidates with the skills and qualities to have a net positive for Automattic. Pay will reflect the potential contribution and the impact you can bring, which may, in some cases, go beyond the range stated.
We’re pleased to offer a straightforward, competitive base salary, providing financial clarity without complex variable components. This isn’t your typical work-from-home job: we are a fully-remote company with an open vacation policy. To see a full list of benefits by country, consult our Benefits Page . And check out these links to learn more about How We Hire and What We Expect from Ourselves . #LI-DNI
About Automattic
Now in our 20th year , we’re the people behind WordPress.com , WooCommerce , Beeper , Tumblr , Simplenote , Jetpack , Longreads , Day One , PocketCasts , and more. We believe in making the web a better place.
We’re a distributed company with more than 1500 Automatticians in nearly every corner of the globe, speaking over a hundred different languages. Enriched by this diversity, we’re united by a singular mission: to democratize publishing, commerce, and messaging so anyone with a story can tell it, anyone with a product can sell it, and everyone can manage their communications from a single source. In short, we help maintain a balance in society, creating and continually refining powerful tools people can use to compete fairly—regardless of income, gender, politics, language, or where they live in the world.
We believe in Open Source , and the vast majority of our work is available under the GPL . Automattic is a Most Loved Company , an Equal Opportunity employer, and Disability Confident Committed . ( Here’s what that might mean for you .) If you need disability-related accommodations during the application or interview process, please fill out this form . We are committed to ensuring an accessible hiring process for all candidates. Learn more about our Employee Resource Groups .
You can track your application status and more at MyGreenhouse .
To learn about how we handle your data, please review our Privacy Policy .
All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, or status as a protected veteran. View the “Know Your Rights: Workplace Discrimination is Illegal” poster here . Automattic participates in the E-Verify program in certain locations, as required by law .
Create a Job Alert
Interested in building your career at Automattic Careers? Get future opportunities sent straight to your email

