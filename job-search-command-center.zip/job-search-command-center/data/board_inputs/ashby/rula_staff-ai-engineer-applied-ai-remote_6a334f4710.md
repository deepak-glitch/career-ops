Company: Rula
Title: Staff AI Engineer - Applied AI (Remote)
Location: Los Angeles, California , United States
employment_type: FULL_TIME
posted_at: 2026-03-31
Source URL: https://jobs.ashbyhq.com/rula/d477da0d-6d23-4166-8afd-6a6a334f4710

JD Extract:
We believe that mental health is just as important as physical health. We recognize that mental health issues can be complex and multifaceted, and we are dedicated to treating the whole person, not just the symptoms.
We aim to create a world where mental health is no longer stigmatized or marginalized, but rather is embraced as an integral part of one's overall well-being.
We believe that by providing quality care that is both evidence-based and compassionate, we can empower individuals to take charge of their mental health and achieve their full potential. We are passionate about making a positive impact on the lives of those struggling with mental health issues and we strive to be a force for positive change in the field of mental healthcare.
Rula is a remote-first company. We currently hire in most U.S. states, with the exception of Hawaii.
About the Role
We’re hiring a Staff AI Engineer to lead some of Rula’s most important applied AI investments as we scale. You’ll own technical direction for high-impact AI products, work across teams to turn big ideas into shipped systems, and help raise the bar for how we build, evaluate, and operate AI in production. This role sits at the center of product innovation and engineering execution, with the chance to influence both what we build and how we build it. It’s a strong fit for someone who loves operating in fast-moving environments, wants to drive outsized impact, and is excited to help define the future of AI at Rula.
Required Qualifications
8+ years of AI/ML development (AI solution design, model design, training / finetuning, deployment and quality upkeep), with track record of product success (i.e. not just in an academic or research environment)
5+ years of deep experience in Python and 2+ years with at least one backend language (preferably JavaScript, TypeScript, Java, or Go)
Hands-on experience with foundation models (OpenAI, Anthropic, Bedrock, Gemini, etc.)
Experience designing evaluation pipelines for human alignment, factual accuracy, or model interpretability.
Strong expertise in LLM integration patterns (RAG, tool/function calling, agents, memory routing, etc.), AI orchestration frameworks (eg. LangChain, LlamaIndex, DSPy, Haystack), and vector databases (eg. Pinecone, Weaviate, FAISS, Milvus).
Deep understanding of AIOps, data pipelines, evaluation, and observability systems for continuous model improvement.
Strong and effective communication skills.
Bachelor’s degree or above in Machine Learning, or related field.
Preferred Qualifications
5+ years of experience with public cloud (AWS, GCP, etc.), 2+ years designing and scaling distributed systems.
Experience delivering secure and compliant AI solutions in regulated environments (HIPAA, GDPR, etc.)
Familiarity with human-in-the-loop systems and clinical decision support frameworks.
Contributions to open-source AI frameworks or applied research in NLP, healthcare AI, or GenAI safety.
Experience working in a highly regulated industry such as finance or healthcare
Experience contributing to early-stage team growth (0 → 1)
We're serious about your well-being! As part of our team, full-time employees receive:
100% remote work environment: Working hours to support a healthy work-life balance, ensuring you can meet both professional and personal commitments (must be based in United States, currently not hiring in Hawaii)
Attractive pay and benefits : Full transparency of pay ranges regardless of where you live in the United States
Comprehensive health benefits : Medical, dental, vision, life, disability, and FSA/HSA
401(k) plan access : Start saving for your future
Generous time-off policies : Including 2 company-wide shutdown weeks each year for self-care (for most employees)
Paid parental leave : Available for all parents, including birthing, non-birthing, adopting, and fostering
Employee Assistance Program (EAP) : Support for your mental and physical health
New hire home office stipend : Set up your workspace for success
Quarterly department stipend : Fun team-building activities or in-person gatherings
Wellness events and lunch & learns : Explore a variety of engaging topics
Community and employee resource groups : Participate in groups that celebrate employee identity and lived experiences, fostering a sense of community and belonging for all
Our team
We believe that diversity, equity, and inclusion are fundamental to our mission of making mental healthcare work for everyone. We are dedicated to having a culture of inclusion that will support our employees in feeling safe, seen, heard, and valued.
