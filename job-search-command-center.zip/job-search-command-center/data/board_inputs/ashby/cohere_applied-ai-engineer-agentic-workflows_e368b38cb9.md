Company: Cohere
Title: Applied AI Engineer – Agentic Workflows
Location: San Francisco, California, United States
employment_type: FULL_TIME
posted_at: 2026-01-06
Source URL: https://jobs.ashbyhq.com/cohere/1fa01a03-9253-4f62-8f10-0fe368b38cb9

JD Extract:
Who are we?
Our mission is to scale intelligence to serve humanity. We’re training and deploying frontier models for developers and enterprises who are building AI systems to power magical experiences like content generation, semantic search, RAG, and agents. We believe that our work is instrumental to the widespread adoption of AI.
We obsess over what we build. Each one of us is responsible for contributing to increasing the capabilities of our models and the value they drive for our customers. We like to work hard and move fast to do what’s best for our customers.
Cohere is a team of researchers, engineers, designers, and more, who are passionate about their craft. Each person is one of the best in the world at what they do. We believe that a diverse range of perspectives is a requirement for building great products.
Join us on our mission and shape the future!
Who are we?
Our mission is to scale intelligence to serve humanity. We’re training and deploying frontier models for developers and enterprises who are building AI systems to power magical experiences like content generation, semantic search, RAG, and Agents. We believe that our work is instrumental to the widespread adoption of AI.
We obsess over what we build. Each one of us is responsible for contributing to increasing the capabilities of our models and the value they drive for our customers. We like to work hard and move fast to do what’s best for our customers.
Cohere is a team of researchers, engineers, designers, and more, who are passionate about their craft. Each person is one of the best in the world at what they do. We believe that a diverse range of perspectives is a requirement for building great products.
Join us on our mission and shape the future!
Why this role?
We’re a fast-growing startup building production-grade AI agents for enterprise customers at scale. We’re looking for Software Engineers with Applied AI experience who can own the design, build, and deployment of agentic workflows powered by Large Language Models (LLMs) —from early prototypes to production-grade AI agents, to deliver concrete business value in enterprise workflows.
In this role, you’ll work closely with customers on real-world business problems, often building first-of-their-kind agent workflows that integrate LLMs with tools, APIs, and data sources. While our pace is startup-fast, the bar is enterprise-high: agents must be reliable, observable, safe, and auditable from day one.
You’ll collaborate closely with customers, product, and platform teams, and help shape how agentic systems are built, evaluated, and deployed at scale.
What You’ll Do
Customer-Facing Technical Impact
Work closely with enterprise customers to translate high-value, ambiguous business problems into well-framed agentic problems with clear success criteria and evaluation methodologies.
Provide technical leadership across the full development and evaluation lifecycle, including post-deployment iteration, for agentic workflows.
Contribute to shared frameworks and patterns that enable consistent delivery across customers.
Agent Design, Build and Production launches
Lead the design, build, and delivery of LLM-powered agents that reason, plan, and act across tools and data sources with enterprise-grade reliability and performance.
Balance rapid iteration with enterprise requirements, evolving prototypes into stable, reusable solutions.
Define and apply evaluation and quality standards to measure success, failures, and regressions.
Debug real-world agent behavior and systematically improve prompts, workflows, tools, and guardrails.
Team Mentorship & Organizational Impact
Mentor engineers across distributed teams.
Drive clarity in ambiguous situations, build alignment, and raise engineering quality across the organization.
Required Skills & Experience
Technical Foundations & Applied AI
Production Engineering: Substantial experience building, shipping, and maintaining production-grade software (Python/TypeScript). You understand how to write clean, testable, observable and scalable code.
Agentic Architectures: Hands-on experience building agents that plan and execute multi-step tasks (ReAct, Plan-and-Execute) and interact with external APIs/tools.
The LLM Stack: Deep familiarity with Frontier Models (GPT, Claude, Gemini), RAG, vector databases (Pinecone, Weaviate, etc.), and orchestration frameworks (LangGraph, CrewAI, or custom state machines).
Rigorous Evaluation: Proven ability to move beyond "trial and error" by building robust evaluation frameworks to measure agent accuracy, safety, and latency.
Leadership & Impact
Stakeholder Mastery: Experience leading technical discussions with enterprise customers to translate ambiguous business needs into concrete technical specs.
Experience mentoring distributed teams and setting the architectural standards for AI/Agentic systems.
Additional Requirements
Strong written and verbal communication skills.
Ability and interest to travel up to 25%, flexible.
Why Join Us
Build production-grade AI agents used in real enterprise workflows.
Operate at scale while retaining end-to-end ownership.
Work on hard problems in agent design, evaluation, and reliability.
Shape shared platforms and standards, not just individual features.
Move fast with a high bar for quality, safety, and reliability.
If some of the above doesn’t line up perfectly with your experience, we still encourage you to apply!
We value and celebrate diversity and strive to create an inclusive work environment for all. We welcome applicants from all backgrounds and are committed to providing equal opportunities. Should you require any accommodations during the recruitment process, please submit an Accommodations Request Form , and we will work together to meet your needs.
Full-Time Employees at Cohere enjoy these Perks:
🤝 An open and inclusive culture and work environment
🧑‍💻 Work closely with a team on the cutting edge of AI research
🍽 Weekly lunch stipend, in-office lunches & snacks
🦷 Full health and dental benefits, including a separate budget to take care of your mental health
🐣 100% Parental Leave top-up for up to 6 months
🎨 Personal enrichment benefits towards arts and culture, fitness and well-being, quality time, and workspace improvement
🏙 Remote-flexible, offices in Toronto, New York, San Francisco, London and Paris, as well as a co-working stipend
✈️ 6 weeks of vacation (30 working days!)
