Company: N-Power Medicine
Title: Senior Large Language Model (LLM) Operations Engineer
Location: Remote
employment_type: Remote
posted_at: 2025-10-21
Source URL: https://jobs.lever.co/npowermedicine/ae7fa790-ff1a-42fd-b037-9abb1b70dacf

JD Extract:
About N-Power Medicine
N-Power Medicine aims to establish a new paradigm in drug development by reinventing the ‘how’ and transforming clinical trials through better integration with clinical practice, ensuring broader participation by physicians and patients. We are building an exceptional multi-disciplinary team with diverse expertise spanning healthcare, engineering, technology and regulatory, and with people who share our core value of Empowering Community through generosity, curiosity and humility. We are working with urgency to bring better therapies to patients faster.
Position Overview
N-Power Medicine seeks a Senior LLM Operations Engineer to execute our technical strategy for scaling AI innovation in clinical variable abstraction and note generation. You will be responsible for architecting, building, and owning the production systems, infrastructure, and development paradigms that enable our AI-powered products. You will own the technical direction for our MLOps and LLM Ops roadmap, ensuring robust, scalable, and automated deployment of our machine learning solutions.You 'll act as a key technical leader, enabling the AI & Data Science team to rapidly iterate and deploy high-impact solutions while upholding rigorous ethical and quality standards. This role offers the chance to solve complex infrastructure and automation challenges, shape the company's long-term AI operational strategy, and deliver significant healthcare impact by building the factory for our AI models.The ideal candidate is a recognized technical expert who excels at building scalable systems, driving automation, and tackling complex system design through ambiguity. Exceptional communication and strategic thinking are critical for success. This position is remote within the United States.
Role Objectives and Responsibilities
-Architect and spearhead the development of cutting-edge, scalable AI infrastructure, including novel human-in-the-loop (HITL) paradigms, ensuring our systems learn effectively from feedback.
-Lead the technical design and implementation of core MLOps components and systems for our LLMs—including CI/CD, monitoring, and automated feedback loops—ensuring robustness, scalability, and adherence to software engineering best practices.
-Define and shape solutions for complex automation and deployment challenges, enabling the strategic application of our cutting-edge AI.
-Drive technical alignment and integration with AI Data Science and Software Engineering teams, ensuring the seamless transition of AI solutions from research into production environments and influencing architectural standards.
-Define and establish standards for the rigorous validation, monitoring, and lifecycle management of AI products, ensuring continuous accuracy improvement and reliability in production.
-Define, champion, and drive adoption of best practices for MLOps, including model/data versioning, experiment tracking, and reproducibility within the AI/ML domain; actively mentor others.
-Identify, champion, and integrate state-of-the-art MLOps technologies and frameworks, driving innovation and maintaining our technical edge in AI deployment.
-Provide expert guidance on applying safeguards and protections (HIPAA, privacy laws) to our model deployment and data handling pipelines; champion and uphold the highest compliance, quality, and security standards.
Education, Experience, Behavioral Competencies, & Skills
-3+ years of professional experience in an MLOps, DevOps, or Software Engineering role with a focus on machine learning systems.
-MSc/BSc graduate in engineering, computer science, or a relevant field, with extensive equivalent experience. A PhD is a plus.
-Deep, hands-on expertise in Python and proficiency in modern software development practices.
-Hands-on experience with a major cloud platform (AWS, GCP, or Azure).
-Strong experience with containerization and orchestration technologies (Docker, Kubernetes).
-Proven experience building and maintaining CI/CD pipelines for complex applications (e.g., GitHub Actions, Jenkins), particularly those that include data + model versioning.
-A proven track record of technical leadership and high-impact contributions in building and scaling production machine learning systems.
-Proven ability to independently define, architect, and lead solutions for complex, ambiguous infrastructure problems, clearly articulating business value.
-Demonstrated ability to lead the decomposition of large-scale systems and guide teams in delivering incremental solutions.
-Track record of designing sustainable, reusable, and high-quality code and influencing team/organizational standards.
-Exceptional written, verbal, and presentation skills; ability to influence stakeholders at all levels.
-Recognized technical leader, proactive, strategic thinker, and takes end-to-end ownership.
-Generous, Curious, and Humble.
Preferred Qualifications
-Direct experience productionizing Large Language Models (LLMs), including knowledge of prompting strategies, RAG, and fine-tuning.
-Deep expertise with the Databricks platform, including MLflow, Delta Tables, and Unity Catalog.
-Experience building data annotation and Human-in-the-Loop (HITL) systems from the ground up.
-Familiarity with vector databases (e.g., Pinecone, Chroma) and model serving frameworks (e.g., Ray Serve, Triton, and -Databricks/Mosaic).
-Experience working in a regulated environment, particularly with healthcare data (HIPAA).
Travel Requirements
Ability to travel, up to 10%, may be required
Pay Information
The expected salary range for this position is $165,000 and $205,000. Actual pay will be determined based on experience, qualifications, geographic location, and other job-related factors permitted by law. N-Power Medicine (NPM) offers equity at hire as well as a discretionary annual bonus which may be available based on Company performance. This position is eligible for company benefits.
More About Us:
We are a mission-driven, well-funded, rapidly growing company, eager to attract passionate professionals offering a highly attractive compensation package with a balanced and flexible work environment, competitive industry benefits as well as a 401K plan and other great company “perks.”
We are an Equal Opportunity Employer and value diversity at our company. We do not discriminate based upon race, religion, color, national origin, gender (including pregnancy, childbirth, or related medical conditions), sexual orientation, gender

