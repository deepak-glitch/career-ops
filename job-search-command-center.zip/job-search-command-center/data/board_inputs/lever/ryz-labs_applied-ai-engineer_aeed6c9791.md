Company: RYZ Labs
Title: Applied AI Engineer
Location: Argentina
employment_type: Full Time - Contract
posted_at: 2026-03-16
Source URL: https://jobs.lever.co/RyzLabs/f15d2e8b-31b6-4cff-837b-38aeed6c9791

JD Extract:
RYZ Labs is looking for an experienced Applied AI Engineer to join one of our clients’ teams, to build out the intelligent AI layer of the agentic travel experience. This is a senior role that will take cutting-edge techniques and state-of-the-art research and apply it to delightful, large-scale consumer experiences.
You will work on:
Atlas’ agentic AI layer
Prompting and orchestration
Multi-step, stateful agentic workflows
Tool-calling architectures with clear guardrails
Consent-aware long-term memory systems
Persona extraction and structured context modeling
Autonomous booking optimization logic
Real-time monitoring and autonomous intervention systems
Evaluation frameworks for model selection, quality, cost, safety, and determinism
Qualifications
We are looking for someone who has:
A Master’s Degree (or higher) in Computer Science or related technical field
5+ years experience in building systems integrated with deep learning models and LLMs
Shipped large-scale AI systems to real users
Experience building agentic systems with tool calling
The ability to translate research into reliable, safe, production-grade systems
Experience in building evaluation frameworks and harnesses for agentic workflows
We prefer candidates with experience with our technologies and architectural patterns, which include:
Frontier language models (commercial and open-weight)
Cloud and serverless infrastructure (AWS, Vercel, etc.)
Durable workflow engines (Temporal, etc.)
LLM observability/evaluation platforms (Braintrust, LangSmith, etc.)
Persistent memory systems
Relational and vector databases for durable state
AI runtimes with streaming and tool execution
\n
\n
About RYZ Labs:
RYZ Labs is a startup studio founded in 2021 by two lifelong entrepreneurs. The founders of RYZ have worked at some of the world's largest tech companies and some of the most iconic consumer brands. They have lived and worked in Argentina for many years and have decades of experience in Latam. What brought them together was their passion for the early phases of company creation and the idea of attracting the brightest talents in order to build industry-defining companies in a post-pandemic world.
Our teams are remote and distributed throughout the US and Latam. They use the latest cutting-edge cloud computing technologies to create scalable and resilient applications. We aim to provide diverse product solutions for different industries and plan to build a large number of startups in the upcoming years.
At RYZ, you will find yourself working with autonomy and efficiency, owning every step of your development. We provide an environment of opportunities, learning, growth, expansion, and challenging projects. You will deepen your experience while sharing and learning from a team of great professionals and specialists.
Our values and what to expect:
- Customer First Mentality - Every decision we make should be made through the lens of the customer.
- Bias for Action - urgency is critical, expect that the timeline to get something done is accelerated.
- Ownership - Step up if you see an opportunity to help, even if it's not your core responsibility.
- Humility and Respect - Be willing to learn, be vulnerable, and treat everyone who interacts with RYZ with respect.
- Frugality - being frugal and cost-conscious helps us do more with less
- Deliver Impact - get things done most efficiently.
- Raise our Standards - always be looking to improve our processes, our team, and our expectations. The status quo is not good enough and never should be.
